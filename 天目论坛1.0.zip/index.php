<?php
// 必须放在最顶部，在任何输出之前
require_once 'includes/config.php';
require_once 'includes/functions.php';
// 正常流程继续
require_once 'includes/auth.php';
// 获取请求参数
$categoryId = isset($_GET['category']) ? intval($_GET['category']) : null;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
// 获取数据
$postsData = getPosts($categoryId, $page, $perPage);
$posts = $postsData['posts'];
$totalPages = $postsData['pages'];
$currentPage = $postsData['current_page'];
$categories = getCategories();
$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $categoryId ? htmlspecialchars(getCategory($categoryId)['name']) : '论坛首页' ?> - <?= htmlspecialchars(getSettings()['site_title']) ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root
{
    --primary: #ff85a2; /* 粉色主色调 */
    --primary-light: #ffb6c1; /* 浅粉色 */
    --primary-dark: #e75480; /* 深粉色 */
    --secondary: #9b5de5; /* 紫色 */
    --accent: #00bbf9; /* 蓝色 */
    --light: #fff9fb; /* 浅粉色背景 */
    --dark: #4a4a4a; /* 深灰色 */
    --gray: #a0a0a0; /* 灰色 */
    --success: #00f5d4; /* 青色 */
    --danger: #f72585; /* 红色 */
    --warning: #ffd166; /* 黄色 */
    --border-radius: 16px;
    /* 更大的圆角 */
    --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15); /* 柔和阴影 */
    --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94); /* 平滑过渡 */
}
* {
margin: 0;
padding: 0;
box-sizing: border-box;
}
body {
font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
line-height: 1.6;
color: var(--dark);
background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
min-height: 100vh;
display: flex;
flex-direction: column;
}
a {
text-decoration: none;
color: inherit;
transition: var(--transition);
}
.container {
width: 100%;
max-width: 1200px;
margin: 0 auto;
padding: 0 1.5rem;
}
/* 头部样式 - 动漫风格 */
header {
background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
color: white;
padding: 1rem 0;
box-shadow: var(--box-shadow);
position: sticky;
top: 0;
z-index: 100;
border-bottom: 3px solid rgba(255, 255, 255, 0.2);
}
.header-content {
display: flex;
justify-content: space-between;
align-items: center;
gap: 1.5rem;
}
.logo {
display: flex;
align-items: center;
gap: 0.75rem;
font-size: 1.5rem;
font-weight: 600;
text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}
.logo i {
font-size: 1.75rem;
color: #fff;
background: rgba(255, 255, 255, 0.2);
padding: 0.5rem;
border-radius: 50%;
}
nav ul {
display: flex;
gap: 0.5rem;
list-style: none;
}
nav ul li a {
display: flex;
align-items: center;
gap: 0.5rem;
padding: 0.5rem 1rem;
border-radius: 50px;
transition: var(--transition);
background: rgba(255, 255, 255, 0.1);
backdrop-filter: blur(10px);
border: 1px solid rgba(255, 255, 255, 0.2);
}
nav ul li a:hover {
background-color: rgba(255, 255, 255, 0.25);
transform: translateY(-2px);
}
nav ul li a i {
font-size: 1.1rem;
}
.search-box {
flex: 1;
max-width: 400px;
}
.search-box form {
display: flex;
gap: 0.5rem;
}
.search-box input {
flex: 1;
padding: 0.75rem 1.25rem;
border: none;
border-radius: 50px;
font-size: 0.95rem;
background: rgba(255, 255, 255, 0.9);
box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
}
.search-box button {
padding: 0.75rem 1.25rem;
background-color: var(--accent);
color: white;
border: none;
border-radius: 50px;
cursor: pointer;
display: flex;
align-items: center;
gap: 0.5rem;
box-shadow: 0 4px 10px rgba(0, 187, 249, 0.3);
}
.search-box button:hover {
background-color: #0099cc;
transform: translateY(-2px);
}
/* 主体内容 */
main {
flex: 1;
padding: 2rem 0;
}
/* 论坛头部 */
.forum-header {
display: flex;
justify-content: space-between;
align-items: center;
margin-bottom: 2rem;
padding-bottom: 1rem;
border-bottom: 2px solid var(--primary-light);
}
.forum-header h2 {
display: flex;
align-items: center;
gap: 0.75rem;
font-size: 1.75rem;
color: var(--dark);
background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
background-clip: text;
}
/* 按钮样式 */
.btn {
display: inline-flex;
align-items: center;
justify-content: center;
gap: 0.5rem;
padding: 0.75rem 1.5rem;
background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
color: white;
border: none;
border-radius: 50px;
font-weight: 500;
cursor: pointer;
transition: var(--transition);
box-shadow: 0 6px 15px rgba(155, 93, 229, 0.3);
position: relative;
overflow: hidden;
}
.btn:hover {
transform: translateY(-3px);
box-shadow: 0 10px 20px rgba(155, 93, 229, 0.4);
}
.btn:active {
transform: translateY(0);
}
.btn i {
font-size: 1.1rem;
}
/* 帖子列表 - 动漫风格网格 */
.posts-list {
display: grid;
grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
gap: 1.5rem;
}
.post-card {
background-color: white;
border-radius: var(--border-radius);
overflow: hidden;
box-shadow: var(--box-shadow);
transition: var(--transition);
display: flex;
flex-direction: column;
border: 1px solid rgba(255, 133, 162, 0.1);
position: relative;
cursor: pointer;
}
.post-card::before {
content: '';
position: absolute;
top: 0;
left: 0;
right: 0;
height: 4px;
background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 50%, var(--accent) 100%);
}
.post-card:hover {
transform: translateY(-8px);
box-shadow: 0 15px 30px rgba(255, 133, 162, 0.2);
}
.post-image-container {
height: 200px;
overflow: hidden;
position: relative;
}
.post-image {
width: 100%;
height: 100%;
object-fit: cover;
transition: var(--transition);
}
.post-card:hover .post-image {
transform: scale(1.08);
}
.post-content {
padding: 1.5rem;
flex: 1;
display: flex;
flex-direction: column;
}
.post-meta {
display: flex;
flex-wrap: wrap;
gap: 0.75rem;
margin-bottom: 1rem;
font-size: 0.85rem;
color: var(--gray);
}
.post-category {
background: linear-gradient(135deg, var(--primary-light) 0%, var(--primary) 100%);
color: white;
padding: 0.25rem 0.75rem;
border-radius: 50px;
font-weight: 500;
box-shadow: 0 2px 5px rgba(255, 133, 162, 0.3);
}
.post-author, .post-date {
display: flex;
align-items: center;
gap: 0.25rem;
}
.post-title {
font-size: 1.25rem;
margin-bottom: 0.75rem;
line-height: 1.4;
color: var(--dark);
font-weight: 600;
}
.post-excerpt {
color: var(--gray);
margin-bottom: 1rem;
line-height: 1.6;
flex: 1;
font-size: 0.95rem;
}
.post-stats {
display: flex;
gap: 1.5rem;
padding-top: 1rem;
border-top: 1px solid #f0f0f0;
font-size: 0.85rem;
color: var(--gray);
}
.post-stats span {
display: flex;
align-items: center;
gap: 0.25rem;
}
/* 无内容提示 */
.no-posts {
background-color: white;
padding: 3rem;
text-align: center;
border-radius: var(--border-radius);
box-shadow: var(--box-shadow);
grid-column: 1 / -1;
border: 1px solid rgba(255, 133, 162, 0.1);
}
.no-posts i {
font-size: 3rem;
color: var(--primary);
margin-bottom: 1rem;
}
.no-posts p {
color: var(--gray);
margin-bottom: 1.5rem;
font-size: 1.1rem;
}
/* 分页 */
.pagination {
display: flex;
justify-content: center;
gap: 0.5rem;
margin-top: 3rem;
flex-wrap: wrap;
}
.pagination a {
padding: 0.75rem 1.25rem;
background-color: white;
border: 1px solid #e0e0e0;
border-radius: var(--border-radius);
color: var(--primary);
transition: var(--transition);
display: flex;
align-items: center;
gap: 0.5rem;
box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
}
.pagination a.active {
background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
color: white;
border-color: transparent;
}
.pagination a:hover:not(.active) {
background-color: #f8f9fa;
transform: translateY(-2px);
}
/* 页脚 */
footer {
background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
color: white;
text-align: center;
padding: 2rem 0;
margin-top: 3rem;
border-top: 3px solid rgba(255, 255, 255, 0.2);
}
footer p {
opacity: 0.9;
text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
}
/* 底部导航栏 - 模仿图片样式 */
.bottom-nav {
position: fixed;
bottom: 0;
left: 0;
right: 0;
background: rgba(255, 255, 255, 0.95);
backdrop-filter: blur(10px);
border-top: 1px solid rgba(255, 133, 162, 0.2);
padding: 0.75rem 0;
display: none;
z-index: 1000;
box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.05);
}
.nav-items {
display: flex;
justify-content: space-around;
align-items: center;
max-width: 500px;
margin: 0 auto;
}
.nav-item {
display: flex;
flex-direction: column;
align-items: center;
gap: 0.25rem;
padding: 0.5rem;
border-radius: 50px;
transition: var(--transition);
color: var(--gray);
}
.nav-item.active {
color: var(--primary);
}
.nav-item i {
font-size: 1.25rem;
background: rgba(255, 133, 162, 0.1);
width: 2.5rem;
height: 2.5rem;
display: flex;
align-items: center;
justify-content: center;
border-radius: 50%;
transition: var(--transition);
}
.nav-item.active i {
background: var(--primary);
color: white;
box-shadow: 0 4px 10px rgba(255, 133, 162, 0.3);
}
.nav-item span {
font-size: 0.75rem;
font-weight: 500;
}
/* 移动端菜单按钮 */
.mobile-menu-btn {
display: none;
background: none;
border: none;
color: white;
font-size: 1.5rem;
cursor: pointer;
}
/* 响应式设计 - 平板 */
@media (max-width: 992px) {
.posts-list {
grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
}
.post-image-container {
height: 180px;
}
}
/* 响应式设计 - 手机 */
@media (max-width: 768px) {
.header-content {
flex-direction: row;
align-items: center;
flex-wrap: wrap;
}
.logo {
order: 1;
flex: 1;
min-width: 0;
overflow: hidden;
text-overflow: ellipsis;
white-space: nowrap;
}
.mobile-menu-btn {
display: block;
order: 2;
}
nav {
order: 4;
width: 100%;
display: none;
margin-top: 1rem;
}
nav.active {
display: block;
}
nav ul {
flex-direction: column;
gap: 0.5rem;
}
.search-box {
order: 3;
width: 100%;
margin-top: 1rem;
display: none;
}
.search-box.active {
display: block;
}
.forum-header {
flex-direction: column;
align-items: flex-start;
gap: 1rem;
}
.posts-list {
grid-template-columns: 1fr;
margin-bottom: 4rem; /* 为底部导航留出空间 */
}
.post-image-container {
height: 160px;
}
.post-content {
padding: 1.25rem;
}
.post-title {
font-size: 1.1rem;
}
.post-excerpt {
font-size: 0.9rem;
}
.pagination a {
padding: 0.5rem 1rem;
font-size: 0.9rem;
}
/* 显示底部导航 */
.bottom-nav {
display: block;
}
}
/* 小屏幕手机优化 */
@media (max-width: 480px)
{
    .container
    {
        padding: 0 1rem;
    }
    .post-image-container
    {
        height: 140px;
    }
    .post-meta
    {
        gap: 0.5rem;
        font-size: 0.8rem;
    }
    .post-stats
    {
        gap: 1rem;
        font-size: 0.8rem;
    }
    .no-posts
    {
        padding: 2rem 1rem;
    }
    .no-posts i
    {
        font-size: 2.5rem;
    }
    .no-posts p
    {
        font-size: 1rem;
    }
}
</style>
</head>
<body>
<header>
<div class="container">
<div class="header-content">
<a href="index.php" class="logo">
<i class="bi bi-chat-square-heart"></i>
<span><?= htmlspecialchars(getSettings()['site_title']) ?></span>
</a>
<button class="mobile-menu-btn" id="mobileMenuBtn">
<i class="bi bi-list"></i>
</button>
<nav id="mainNav">
<ul>
<li><a href="index.php"><i class="bi bi-house"></i> 首页</a></li>
<?php foreach ($categories as $category): ?>
<li><a href="index.php?category=<?= $category['id'] ?>"><i class="bi bi-collection"></i> <?= htmlspecialchars($category['name']) ?></a></li>
<?php endforeach;
?>
<?php if (isLoggedIn()): ?>
<li><a href="create_post.php"><i class="bi bi-plus-circle"></i> 发帖</a></li>
<li><a href="profile.php"><i class="bi bi-person"></i> 个人中心</a></li>
<?php if ($currentUser['is_admin']): ?>
<li><a href="admin/"><i class="bi bi-gear"></i> 管理</a></li>
<?php endif;
?>
<li><a href="logout.php"><i class="bi bi-box-arrow-right"></i> 退出</a></li>
<?php else: ?>
<li><a href="login.php"><i class="bi bi-box-arrow-in-right"></i> 登录</a></li>
<li><a href="register.php"><i class="bi bi-person-plus"></i> 注册</a></li>
<?php endif;
?>
</ul>
</nav>
<div class="search-box" id="searchBox">
<form action="search.php" method="get">
<input type="text" name="q" placeholder="搜索帖子..." value="<?= isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '' ?>">
<button type="submit"><i class="bi bi-search"></i></button>
</form>
</div>
</div>
</div>
</header>
<main class="container">
<div class="forum-header">
<h2>
<?php if ($categoryId): ?>
<i class="bi bi-collection"></i> <?= htmlspecialchars(getCategory($categoryId)['name']) ?>
<?php else: ?>
<i class="bi bi-house"></i> 最新帖子
<?php endif;
?>
</h2>
<?php if (isLoggedIn()): ?>
<a href="create_post.php" class="btn"><i class="bi bi-plus-circle"></i> 发表新帖</a>
<?php endif;
?>
</div>
<div class="posts-list">
<?php if (!empty($posts)): ?>
<?php foreach ($posts as $post): ?>
<?php
// 提取图片
preg_match('/\[img\](.*?)\[\/img\]/i', $post['content'], $imageMatches);
$coverImage = $imageMatches[1] ?? null;
// 生成摘要
$excerpt = strip_tags(str_replace(
['[img]', '[/img]', '[video]', '[/video]', '[code]', '[/code]'],
'',
$post['content']
));
$excerpt = mb_substr($excerpt, 0, 150) . (mb_strlen($excerpt) > 150 ? '...' : '');
?>
<div class="post-card" onclick="window.location.href='post.php?id=<?= $post['id'] ?>'">
<?php if ($coverImage): ?>
<div class="post-image-container">
<img src="<?= htmlspecialchars($coverImage) ?>" alt="帖子封面" class="post-image">
</div>
<?php endif;
?>
<div class="post-content">
<div class="post-meta">
<span class="post-category"><?= htmlspecialchars(getCategory($post['category_id'])['name']) ?></span>
<span class="post-author"><i class="bi bi-person"></i> <?= htmlspecialchars(getUser($post['user_id'])['username']) ?></span>
<span class="post-date"><i class="bi bi-clock"></i> <?= $post['created_at'] ?></span>
</div>
<h3 class="post-title"><?= htmlspecialchars($post['title']) ?></h3>
<div class="post-excerpt">
<?= htmlspecialchars($excerpt) ?>
</div>
<div class="post-stats">
<span><i class="bi bi-eye"></i> <?= $post['views'] ?> 浏览</span>
<span><i class="bi bi-heart"></i> <?= is_array($post['likes']) ? count($post['likes']) : 0 ?> 点赞</span>
<span><i class="bi bi-chat-left"></i> <?= is_array(getComments($post['id'])) ? count(getComments($post['id'])) : 0 ?> 评论</span>
</div>
</div>
</div>
<?php endforeach;
?>
<?php else: ?>
<div class="no-posts">
<i class="bi bi-chat-square"></i>
<p>暂无帖子，快来发表第一个帖子吧</p>
<?php if (isLoggedIn()): ?>
<a href="create_post.php" class="btn"><i class="bi bi-plus-circle"></i> 发表新帖</a>
<?php else: ?>
<a href="register.php" class="btn"><i class="bi bi-person-plus"></i> 注册账号</a>
<?php endif;
?>
</div>
<?php endif;
?>
</div>
<?php if ($totalPages > 1): ?>
<div class="pagination">
<?php if ($currentPage > 1): ?>
<a href="?<?= $categoryId ? 'category='.$categoryId.'&' : '' ?>page=<?= $currentPage - 1 ?>">
<i class="bi bi-chevron-left"></i> 上一页
</a>
<?php endif;
?>
<?php for ($i = 1;
$i <= $totalPages;
$i++): ?>
<a href="?<?= $categoryId ? 'category='.$categoryId.'&' : '' ?>page=<?= $i ?>" <?= $i == $currentPage ? 'class="active"' : '' ?>>
<?= $i ?>
</a>
<?php endfor;
?>
<?php if ($currentPage < $totalPages): ?>
<a href="?<?= $categoryId ? 'category='.$categoryId.'&' : '' ?>page=<?= $currentPage + 1 ?>">
下一页 <i class="bi bi-chevron-right"></i>
</a>
<?php endif;
?>
</div>
<?php endif;
?>
</main>
<!-- 底部导航栏 -->
<nav class="bottom-nav">
<div class="nav-items">
<a href="index.php" class="nav-item active">
<i class="bi bi-house"></i>
<span>主页</span>
</a>
<a href="categories.php" class="nav-item">
<i class="bi bi-compass"></i>
<span>发现</span>
</a>
<a href="create_post.php" class="nav-item">
<i class="bi bi-plus-circle"></i>
<span>发帖</span>
</a>
<a href="messages.php" class="nav-item">
<i class="bi bi-chat"></i>
<span>消息</span>
</a>
<a href="profile.php" class="nav-item">
<i class="bi bi-person"></i>
<span>我的</span>
</a>
</div>
</nav>
<footer>
<div class="container">
<p>Copyright © <?= date('Y') ?> <?= htmlspecialchars(getSettings()['site_title']) ?> - 分享快乐</p>
</div>
</footer>
<script>
// 移动端菜单切换
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const mainNav = document.getElementById('mainNav');
const searchBox = document.getElementById('searchBox');
mobileMenuBtn.addEventListener('click', function()
{
    mainNav.classList.toggle('active');
    searchBox.classList.toggle('active');
    // 切换图标
    const icon = this.querySelector('i');
    if (mainNav.classList.contains('active'))
    {
        icon.classList.remove('bi-list');
        icon.classList.add('bi-x');
    }
    else
    {
        icon.classList.remove('bi-x');
        icon.classList.add('bi-list');
    }
}
);
// 确保卡片内的链接点击不会冒泡
document.querySelectorAll('.post-card a').forEach(link =>
{
    link.addEventListener('click', function(e)
    {
        e.stopPropagation();
    }
    );
}
);
// 添加页面加载动画
document.addEventListener('DOMContentLoaded', function()
{
    document.body.style.opacity = '0';
    setTimeout(() =>
    {
        document.body.style.transition = 'opacity 0.3s ease';
        document.body.style.opacity = '1';
    }
    , 100);
    // 为卡片添加延迟动画
    const cards = document.querySelectorAll('.post-card');
    cards.forEach((card, index) =>
    {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        setTimeout(() =>
        {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }
        , 100 + index * 100);
    }
    );
}
);
// 根据屏幕宽度自动调整布局
function handleResponsive()
{
    if (window.innerWidth > 768)
    {
        mainNav.classList.remove('active');
        searchBox.classList.remove('active');
        const icon = mobileMenuBtn.querySelector('i');
        icon.classList.remove('bi-x');
        icon.classList.add('bi-list');
    }
}
window.addEventListener('resize', handleResponsive);
handleResponsive();
// 底部导航激活状态切换
document.querySelectorAll('.bottom-nav .nav-item').forEach(item =>
{
    item.addEventListener('click', function()
    {
        document.querySelectorAll('.bottom-nav .nav-item').forEach(i =>
        {
            i.classList.remove('active');
        }
        );
        this.classList.add('active');
    }
    );
}
);
</script>
</body>
</html>