<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

$currentUser = getCurrentUser();
$categories = getCategories();
$users = getUsers();
$posts = readData(POSTS_FILE);
$comments = readData(COMMENTS_FILE);

// 创建帖子ID到分类ID的映射
$postCategoryMap = [];
foreach ($posts as $post) {
    $postCategoryMap[$post['id']] = $post['category_id'];
}

// 计算板块热度
$categoryHeatmap = [];
foreach ($categories as $category) {
    $categoryPosts = array_filter($posts, function($post) use ($category) {
        return $post['category_id'] == $category['id'];
    });
    
    $totalViews = array_sum(array_column($categoryPosts, 'views'));
    $totalLikes = array_sum(array_map(function($post) {
        return count($post['likes']);
    }, $categoryPosts));
    
    // 修正评论数量计算 - 通过帖子ID映射到分类ID
    $totalComments = count(array_filter($comments, function($comment) use ($category, $postCategoryMap) {
        if (isset($postCategoryMap[$comment['post_id']])) {
            return $postCategoryMap[$comment['post_id']] == $category['id'];
        }
        return false;
    }));
    
    $categoryHeatmap[$category['id']] = [
        'views' => $totalViews,
        'likes' => $totalLikes,
        'comments' => $totalComments,
        'heat' => ($totalViews * 0.4) + ($totalLikes * 0.3) + ($totalComments * 0.3)
    ];
}

// 获取热门帖子
$hotPosts = array_slice($posts, 0, 5);
usort($hotPosts, function($a, $b) {
    $aScore = ($a['views'] * 0.5) + (count($a['likes']) * 0.3) + (count(getComments($a['id'])) * 0.2);
    $bScore = ($b['views'] * 0.5) + (count($b['likes']) * 0.3) + (count(getComments($b['id'])) * 0.2);
    return $bScore - $aScore;
});

// 获取活跃用户
$activeUsers = array_slice($users, 0, 8);
usort($activeUsers, function($a, $b) use ($posts, $comments) {
    $aPosts = count(array_filter($posts, function($post) use ($a) {
        return $post['user_id'] == $a['id'];
    }));
    $aComments = count(array_filter($comments, function($comment) use ($a) {
        return $comment['user_id'] == $a['id'];
    }));
    
    $bPosts = count(array_filter($posts, function($post) use ($b) {
        return $post['user_id'] == $b['id'];
    }));
    $bComments = count(array_filter($comments, function($comment) use ($b) {
        return $comment['user_id'] == $b['id'];
    }));
    
    $aScore = ($aPosts * 0.6) + ($aComments * 0.4);
    $bScore = ($bPosts * 0.6) + ($bComments * 0.4);
    
    return $bScore - $aScore;
});

// 获取在线用户
$onlineUsers = array_filter($users, function($user) {
    return isset($user['last_active']) && (time() - strtotime($user['last_active'])) < 300; // 5分钟内活跃
});
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>发现 - 天目官方论坛</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #ff85a2; /* 粉色主色调 */
            --primary-light: #ffb6c1; /* 浅粉色 */
            --primary-dark: #e75480; /* 深粉色 */
            --secondary: #9b5de5; /* 紫色 */
            --accent: #00bbf9; /* 蓝色 */
            --light: #fff9fb; /* 浅粉色背景 */
            --dark: #4a4a4a; /* 深灰色 */
            --gray: #a0a0a0; /* 灰色 */
            --success: #00f5d4; /* 青色 */
            --danger: #f72585; /* 红色 */
            --warning: #ffd166; /* 黄色 */
            --border-radius: 16px; /* 更大的圆角 */
            --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15); /* 柔和阴影 */
            --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94); /* 平滑过渡 */
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        a {
            text-decoration: none;
            color: inherit;
            transition: var(--transition);
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
        }
        
        /* 头部样式 - 天目官方风格 */
        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1.5rem;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .logo i {
            font-size: 1.75rem;
            color: #fff;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem;
            border-radius: 50%;
        }
        
        nav ul {
            display: flex;
            gap: 0.5rem;
            list-style: none;
        }
        
        nav ul li a {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        nav ul li a:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        
        nav ul li a i {
            font-size: 1.1rem;
        }
        
        .search-box {
            flex: 1;
            max-width: 400px;
        }
        
        .search-box form {
            display: flex;
            gap: 0.5rem;
        }
        
        .search-box input {
            flex: 1;
            padding: 0.75rem 1.25rem;
            border: none;
            border-radius: 50px;
            font-size: 0.95rem;
            background: rgba(255, 255, 255, 0.9);
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .search-box button {
            padding: 0.75rem 1.25rem;
            background-color: var(--accent);
            color: white;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 4px 10px rgba(0, 187, 249, 0.3);
        }
        
        .search-box button:hover {
            background-color: #0099cc;
            transform: translateY(-2px);
        }
        
        /* 主体内容 */
        main {
            flex: 1;
            padding: 2rem 0;
        }
        
        /* 发现页面标题 */
        .discover-header {
            text-align: center;
            margin-bottom: 2rem;
            padding: 1.5rem;
            background: linear-gradient(135deg, rgba(255, 133, 162, 0.1) 0%, rgba(155, 93, 229, 0.1) 100%);
            border-radius: var(--border-radius);
            position: relative;
            overflow: hidden;
        }
        
        .discover-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 50%, var(--accent) 100%);
        }
        
        .discover-header h1 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .discover-header p {
            color: var(--gray);
            max-width: 800px;
            margin: 0 auto;
            font-size: 1.1rem;
        }
        
        /* 统计卡片 */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background-color: white;
            padding: 1.5rem;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            text-align: center;
            position: relative;
            overflow: hidden;
            transition: var(--transition);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 100%);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 133, 162, 0.1);
            border-radius: 50%;
            margin: 0 auto 1rem;
            font-size: 1.5rem;
            color: var(--primary);
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .stat-label {
            color: var(--gray);
            font-size: 1rem;
        }
        
        /* 板块热度图 */
        .heatmap-section {
            background-color: white;
            padding: 2rem;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            margin-bottom: 2rem;
            position: relative;
        }
        
        .heatmap-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--accent) 0%, var(--success) 50%, var(--warning) 100%);
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .section-header h2 {
            font-size: 1.75rem;
            color: var(--dark);
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .heatmap-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }
        
        .heatmap-item {
            background-color: #f9fafb;
            padding: 1.5rem;
            border-radius: var(--border-radius);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            transition: var(--transition);
        }
        
        .heatmap-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        }
        
        .category-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .category-icon {
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border-radius: 50%;
            font-size: 1.25rem;
        }
        
        .category-info {
            flex: 1;
        }
        
        .category-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .category-stats {
            display: flex;
            gap: 1rem;
            font-size: 0.85rem;
            color: var(--gray);
        }
        
        .heat-bar {
            height: 10px;
            background-color: #e9ecef;
            border-radius: 5px;
            overflow: hidden;
            margin: 1rem 0;
        }
        
        .heat-level {
            height: 100%;
            background: linear-gradient(90deg, var(--warning) 0%, var(--danger) 100%);
            border-radius: 5px;
        }
        
        .heat-info {
            display: flex;
            justify-content: space-between;
            font-size: 0.9rem;
            color: var(--gray);
        }
        
        .heat-value {
            font-weight: 600;
            color: var(--danger);
        }
        
        .online-users {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
            flex-wrap: wrap;
        }
        
        .online-user {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--success);
            position: relative;
        }
        
        .user-avatar::after {
            content: '';
            position: absolute;
            bottom: 0;
            right: 0;
            width: 10px;
            height: 10px;
            background-color: var(--success);
            border-radius: 50%;
            border: 2px solid white;
        }
        
        .user-name {
            font-size: 0.75rem;
            margin-top: 0.25rem;
            text-align: center;
            max-width: 60px;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        /* 热门内容 */
        .hot-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .hot-section {
            background-color: white;
            padding: 1.5rem;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            position: relative;
        }
        
        .hot-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--warning) 0%, var(--danger) 100%);
        }
        
        .hot-posts {
            margin-top: 1rem;
        }
        
        .hot-post {
            display: flex;
            gap: 1rem;
            padding: 1rem 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .hot-post:last-child {
            border-bottom: none;
        }
        
        .post-thumb {
            width: 80px;
            height: 60px;
            border-radius: var(--border-radius);
            object-fit: cover;
            background-color: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--gray);
            font-size: 1.5rem;
        }
        
        .post-info {
            flex: 1;
        }
        
        .post-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .post-meta {
            display: flex;
            gap: 0.75rem;
            font-size: 0.85rem;
            color: var(--gray);
        }
        
        .active-users {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }
        
        .active-user {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }
        
        .user-rank {
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border-radius: 50%;
            font-size: 0.75rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .user-rank.top3 {
            background: linear-gradient(135deg, var(--warning) 0%, var(--danger) 100%);
        }
        
        .user-stats {
            font-size: 0.75rem;
            color: var(--gray);
            margin-top: 0.25rem;
        }
        
        /* 底部导航栏 */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 133, 162, 0.2);
            padding: 0.75rem 0;
            display: none;
            z-index: 1000;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .nav-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
            padding: 0.5rem;
            border-radius: 50px;
            transition: var(--transition);
            color: var(--gray);
        }
        
        .nav-item.active {
            color: var(--primary);
        }
        
        .nav-item i {
            font-size: 1.25rem;
            background: rgba(255, 133, 162, 0.1);
            width: 2.5rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .nav-item.active i {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 10px rgba(255, 133, 162, 0.3);
        }
        
        .nav-item span {
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        footer {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            text-align: center;
            padding: 1.5rem 0;
            margin-top: 3rem;
            border-top: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        footer p {
            opacity: 0.9;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        }
        
        /* 响应式设计 */
        @media (max-width: 992px) {
            .discover-header h1 {
                font-size: 2rem;
            }
            
            .heatmap-container {
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            }
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: row;
                align-items: center;
                flex-wrap: wrap;
            }
            
            .logo {
                order: 1;
                flex: 1;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            .mobile-menu-btn {
                display: block;
                order: 2;
            }
            
            nav {
                order: 4;
                width: 100%;
                display: none;
                margin-top: 1rem;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .search-box {
                order: 3;
                width: 100%;
                margin-top: 1rem;
                display: none;
            }
            
            .search-box.active {
                display: block;
            }
            
            .discover-header {
                padding: 1rem;
            }
            
            .discover-header h1 {
                font-size: 1.75rem;
            }
            
            .stats-cards {
                grid-template-columns: 1fr;
            }
            
            .hot-content {
                grid-template-columns: 1fr;
            }
            
            /* 显示底部导航 */
            .bottom-nav {
                display: block;
            }
            
            /* 为移动端留出底部空间 */
            main {
                margin-bottom: 4rem;
            }
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 0 1rem;
            }
            
            .stat-value {
                font-size: 2rem;
            }
            
            .heatmap-item {
                padding: 1rem;
            }
            
            .category-header {
                flex-direction: column;
                text-align: center;
            }
            
            .category-stats {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <a href="index.php" class="logo">
                    <i class="bi bi-chat-square-heart"></i>
                    <span>天目官方论坛</span>
                </a>
                
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="bi bi-list"></i>
                </button>
                
                <nav id="mainNav">
                    <ul>
                        <li><a href="index.php"><i class="bi bi-house"></i> 首页</a></li>
                        <li><a href="categories.php" class="active"><i class="bi bi-compass"></i> 发现</a></li>
                        <li><a href="create_post.php"><i class="bi bi-plus-circle"></i> 发帖</a></li>
                        <li><a href="profile.php"><i class="bi bi-person"></i> 个人中心</a></li>
                    </ul>
                </nav>
                
                <div class="search-box" id="searchBox">
                    <form action="search.php" method="get">
                        <input type="text" name="q" placeholder="搜索帖子...">
                        <button type="submit"><i class="bi bi-search"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="discover-header">
            <h1><i class="bi bi-compass"></i> 探索论坛</h1>
            <p>发现热门板块、活跃用户和精彩内容，参与社区讨论，分享你的见解</p>
        </div>
        
        <div class="stats-cards">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-grid"></i>
                </div>
                <div class="stat-value"><?= count($categories) ?></div>
                <div class="stat-label">论坛板块</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-file-text"></i>
                </div>
                <div class="stat-value"><?= count($posts) ?></div>
                <div class="stat-label">帖子总数</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-people"></i>
                </div>
                <div class="stat-value"><?= count($users) ?></div>
                <div class="stat-label">注册用户</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-lightning"></i>
                </div>
                <div class="stat-value"><?= count($onlineUsers) ?></div>
                <div class="stat-label">当前在线</div>
            </div>
        </div>
        
        <div class="heatmap-section">
            <div class="section-header">
                <h2><i class="bi bi-fire"></i> 板块热度图</h2>
            </div>
            
            <div class="heatmap-container">
                <?php foreach ($categories as $category): ?>
                    <?php 
                    $heat = $categoryHeatmap[$category['id']]['heat'] ?? 0;
                    $maxHeat = max(array_column($categoryHeatmap, 'heat'));
                    $heatPercent = $maxHeat > 0 ? ($heat / $maxHeat) * 100 : 0;
                    ?>
                    <div class="heatmap-item">
                        <div class="category-header">
                            <div class="category-icon">
                                <i class="bi bi-collection"></i>
                            </div>
                            <div class="category-info">
                                <div class="category-title"><?= $category['name'] ?></div>
                                <div class="category-stats">
                                    <span><i class="bi bi-eye"></i> <?= $categoryHeatmap[$category['id']]['views'] ?? 0 ?></span>
                                    <span><i class="bi bi-heart"></i> <?= $categoryHeatmap[$category['id']]['likes'] ?? 0 ?></span>
                                    <span><i class="bi bi-chat"></i> <?= $categoryHeatmap[$category['id']]['comments'] ?? 0 ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="heat-bar">
                            <div class="heat-level" style="width: <?= $heatPercent ?>%"></div>
                        </div>
                        
                        <div class="heat-info">
                            <span>热度指数</span>
                            <span class="heat-value"><?= number_format($heat, 1) ?></span>
                        </div>
                        
                        <div class="online-users">
                            <?php 
                            // 随机获取3-5个在线用户
                            $categoryOnlineUsers = array_slice($onlineUsers, 0, rand(3, 5));
                            foreach ($categoryOnlineUsers as $user): 
                            ?>
                                <div class="online-user">
                                    <img src="images/<?= $user['avatar'] ?? 'default.png' ?>" alt="<?= $user['username'] ?>" class="user-avatar">
                                    <div class="user-name"><?= $user['username'] ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="hot-content">
            <div class="hot-section">
                <div class="section-header">
                    <h2><i class="bi bi-fire"></i> 热门帖子</h2>
                </div>
                
                <div class="hot-posts">
                    <?php foreach ($hotPosts as $post): ?>
                        <div class="hot-post">
                            <div class="post-thumb">
                                <i class="bi bi-file-text"></i>
                            </div>
                            <div class="post-info">
                                <a href="post.php?id=<?= $post['id'] ?>" class="post-title"><?= $post['title'] ?></a>
                                <div class="post-meta">
                                    <span><i class="bi bi-eye"></i> <?= $post['views'] ?></span>
                                    <span><i class="bi bi-heart"></i> <?= count($post['likes']) ?></span>
                                    <span><i class="bi bi-chat"></i> <?= count(getComments($post['id'])) ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="hot-section">
                <div class="section-header">
                    <h2><i class="bi bi-star"></i> 活跃用户</h2>
                </div>
                
                <div class="active-users">
                    <?php foreach ($activeUsers as $index => $user): ?>
                        <div class="active-user">
                            <div class="user-rank <?= $index < 3 ? 'top3' : '' ?>"><?= $index + 1 ?></div>
                            <img src="images/<?= $user['avatar'] ?? 'default.png' ?>" alt="<?= $user['username'] ?>" class="user-avatar">
                            <div class="user-name"><?= $user['username'] ?></div>
                            <div class="user-stats">
                                <?php 
                                $userPosts = count(array_filter($posts, function($post) use ($user) {
                                    return $post['user_id'] == $user['id'];
                                }));
                                $userComments = count(array_filter($comments, function($comment) use ($user) {
                                    return $comment['user_id'] == $user['id'];
                                }));
                                ?>
                                <span><?= $userPosts ?>帖</span> · <span><?= $userComments ?>评</span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </main>
    
    <!-- 底部导航栏 -->
    <nav class="bottom-nav">
        <div class="nav-items">
            <a href="index.php" class="nav-item">
                <i class="bi bi-house"></i>
                <span>主页</span>
            </a>
            <a href="categories.php" class="nav-item active">
                <i class="bi bi-compass"></i>
                <span>发现</span>
            </a>
            <a href="create_post.php" class="nav-item">
                <i class="bi bi-plus-circle"></i>
                <span>添加</span>
            </a>
            <a href="messages.php" class="nav-item">
                <i class="bi bi-chat"></i>
                <span>消息</span>
            </a>
            <a href="profile.php" class="nav-item">
                <i class="bi bi-person"></i>
                <span>我的</span>
            </a>
        </div>
    </nav>

    <footer>
        <div class="container">
            <p>Copyright © 2025 天目官方论坛 - 分享快乐</p>
        </div>
    </footer>

    <script>
        // 移动端菜单切换
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        const searchBox = document.getElementById('searchBox');
        
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            searchBox.classList.toggle('active');
            
            // 切换图标
            const icon = this.querySelector('i');
            if (mainNav.classList.contains('active')) {
                icon.classList.remove('bi-list');
                icon.classList.add('bi-x');
            } else {
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        });
        
        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            document.body.style.opacity = '0';
            setTimeout(() => {
                document.body.style.transition = 'opacity 0.3s ease';
                document.body.style.opacity = '1';
            }, 100);
            
            // 为卡片添加延迟动画
            const cards = document.querySelectorAll('.heatmap-item, .stat-card, .hot-post');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 100 + index * 100);
            });
        });
    </script>
</body>
</html>