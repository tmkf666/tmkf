<?php
require_once 'functions.php';

/**
 * 用户注册
 */
function registerUser($data) {
    $users = readData(USERS_FILE);
    
    // 检查用户名是否已存在
    foreach ($users as $user) {
        if ($user['username'] == $data['username']) {
            return ['success' => false, 'message' => '用户名已存在'];
        }
    }
    
    // 生成新ID
    $ids = array_column($users, 'id');
    $newId = $ids ? max($ids) + 1 : 1;
    
    $user = [
        'id' => $newId,
        'username' => $data['username'],
        'password' => password_hash($data['password'], PASSWORD_DEFAULT),
        'email' => $data['email'],
        'created_at' => date('Y-m-d H:i:s'),
        'avatar' => 'default.png',
        'is_admin' => false,
        'is_banned' => false,
        'bio' => '' // 添加个人简介字段
    ];
    
    $users[] = $user;
    writeData(USERS_FILE, $users);
    
    return ['success' => true, 'user_id' => $newId];
}

/**
 * 用户登录
 */
function loginUser($username, $password) {
    $users = readData(USERS_FILE);
    foreach ($users as $user) {
        if ($user['username'] == $username) {
            if ($user['is_banned']) {
                return ['success' => false, 'message' => '账号已被封禁'];
            }
            
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['is_admin'] = $user['is_admin'] ?? false;
                return ['success' => true];
            }
            break;
        }
    }
    return ['success' => false, 'message' => '用户名或密码错误'];
}

/**
 * 用户登出
 */
function logoutUser() {
    session_unset();
    session_destroy();
}

/**
 * 检查用户是否登录
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * 获取当前用户ID
 */
function getCurrentUserId() {
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
}

/**
 * 获取当前用户信息
 */
function getCurrentUser() {
    if (isLoggedIn()) {
        return getUser(getCurrentUserId());
    }
    return null;
}

/**
 * 封禁用户
 */
function banUser($userId) {
    $users = readData(USERS_FILE);
    foreach ($users as &$user) {
        if ($user['id'] == $userId) {
            $user['is_banned'] = true;
            break;
        }
    }
    writeData(USERS_FILE, $users);
}

/**
 * 解封用户
 */
function unbanUser($userId) {
    $users = readData(USERS_FILE);
    foreach ($users as &$user) {
        if ($user['id'] == $userId) {
            $user['is_banned'] = false;
            break;
        }
    }
    writeData(USERS_FILE, $users);
}

/**
 * 设置管理员
 */
function setAdmin($userId, $isAdmin) {
    $users = readData(USERS_FILE);
    foreach ($users as &$user) {
        if ($user['id'] == $userId) {
            $user['is_admin'] = $isAdmin;
            break;
        }
    }
    writeData(USERS_FILE, $users);
}