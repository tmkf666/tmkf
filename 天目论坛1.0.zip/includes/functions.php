<?php
// 防止文件重复包含
if (defined('TM_FORUM_FUNCTIONS_LOADED')) {
    return;
}
define('TM_FORUM_FUNCTIONS_LOADED', true);

// 安全启动会话 - 修复重复会话问题
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 定义常量 - 添加存在性检查
if (!defined('ROOT_PATH')) define('ROOT_PATH', dirname(__DIR__));
if (!defined('DATA_DIR')) define('DATA_DIR', ROOT_PATH . '/tm');
if (!defined('UPLOAD_DIR')) define('UPLOAD_DIR', ROOT_PATH . '/images');

// 数据库文件 - 添加存在性检查
if (!defined('USERS_FILE')) define('USERS_FILE', DATA_DIR . '/users.txt');
if (!defined('POSTS_FILE')) define('POSTS_FILE', DATA_DIR . '/posts.txt');
if (!defined('COMMENTS_FILE')) define('COMMENTS_FILE', DATA_DIR . '/comments.txt');
if (!defined('CATEGORIES_FILE')) define('CATEGORIES_FILE', DATA_DIR . '/categories.txt');
if (!defined('SETTINGS_FILE')) define('SETTINGS_FILE', DATA_DIR . '/settings.txt');
if (!defined('LOGIN_ATTEMPTS_FILE')) define('LOGIN_ATTEMPTS_FILE', DATA_DIR . '/login_attempts.txt');
if (!defined('REGISTRATIONS_FILE')) define('REGISTRATIONS_FILE', DATA_DIR . '/registrations.dat');
if (!defined('ACTION_LOGS_FILE')) define('ACTION_LOGS_FILE', DATA_DIR . '/action_logs.dat');
if (!defined('BADGES_FILE')) define('BADGES_FILE', DATA_DIR . '/badges.dat');
if (!defined('USER_BADGES_FILE')) define('USER_BADGES_FILE', DATA_DIR . '/user_badges.dat');
if (!defined('BADGE_APPLICATIONS_FILE')) define('BADGE_APPLICATIONS_FILE', DATA_DIR . '/badge_applications.dat');

// 初始化板块
if (!file_exists(CATEGORIES_FILE)) {
    $categories = [
        ['id' => 1, 'name' => '科技数码', 'slug' => 'tech'],
        ['id' => 2, 'name' => '生活分享', 'slug' => 'life'],
        ['id' => 3, 'name' => '学习交流', 'slug' => 'study']
    ];
    file_put_contents(CATEGORIES_FILE, serialize($categories));
}

// 初始化系统设置
if (!file_exists(SETTINGS_FILE)) {
    $defaultSettings = [
        'site_title' => '我的论坛',
        'site_description' => '欢迎来到我们的社区论坛',
        'posts_per_page' => 10,
        'comments_per_page' => 15,
        'allow_registrations' => 1,
        'default_user_role' => 'member',
        'require_email_verification' => 0,
        'max_login_attempts' => 5,
        'login_ban_time' => 30,
        'password_min_length' => 8,
        'password_complexity' => 'medium',
        'enable_2fa' => 0,
        
        // 维护设置 - 使用嵌套数组结构
        'maintenance' => [
            'enabled' => false,
            'message' => '网站正在维护中，请稍后再访问',
            'allowed_ips' => [],
            'start_time' => null,
            'end_time' => null
        ],
        
        // 头衔系统设置
        'badge_settings' => [
            'max_badge_length' => 20,
            'min_badge_length' => 2,
            'max_applications_per_user' => 3,
            'cooldown_period' => 30 // 天
        ]
    ];
    file_put_contents(SETTINGS_FILE, serialize($defaultSettings));
}

// 错误报告
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 确保目录存在
if (!file_exists(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
}
if (!file_exists(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

/**
 * 读取数据文件
 */
if (!function_exists('readData')) {
    function readData($file) {
        if (!file_exists($file)) {
            return [];
        }
        $content = file_get_contents($file);
        return unserialize($content);
    }
}

/**
 * 写入数据文件
 */
if (!function_exists('writeData')) {
    function writeData($file, $data) {
        file_put_contents($file, serialize($data));
    }
}

/**
 * 获取系统设置
 */
if (!function_exists('getSettings')) {
    function getSettings() {
        $settings = readData(SETTINGS_FILE);
        
        // 确保维护设置存在
        if (!isset($settings['maintenance'])) {
            $settings['maintenance'] = [
                'enabled' => false,
                'message' => '网站正在维护中，请稍后再访问',
                'allowed_ips' => [],
                'start_time' => null,
                'end_time' => null
            ];
        }
        
        // 确保头衔设置存在
        if (!isset($settings['badge_settings'])) {
            $settings['badge_settings'] = [
                'max_badge_length' => 20,
                'min_badge_length' => 2,
                'max_applications_per_user' => 3,
                'cooldown_period' => 30
            ];
        }
        
        return $settings;
    }
}

/**
 * 获取维护设置
 */
if (!function_exists('getMaintenanceSettings')) {
    function getMaintenanceSettings() {
        $settings = getSettings();
        return $settings['maintenance'];
    }
}

/**
 * 更新系统设置
 */
if (!function_exists('updateSettings')) {
    function updateSettings($newSettings) {
        writeData(SETTINGS_FILE, $newSettings);
    }
}

/**
 * 更新维护设置
 */
if (!function_exists('updateMaintenanceSettings')) {
    function updateMaintenanceSettings($newMaintenanceSettings) {
        $settings = getSettings();
        $settings['maintenance'] = $newMaintenanceSettings;
        updateSettings($settings);
    }
}

/**
 * 检查是否处于维护模式
 */
if (!function_exists('isMaintenanceMode')) {
    function isMaintenanceMode() {
        $maintenance = getMaintenanceSettings();
        
        if ($maintenance['enabled']) {
            $userIP = $_SERVER['REMOTE_ADDR'];
            $allowedIPs = $maintenance['allowed_ips'] ?? [];
            
            // 管理员或允许的IP可以访问
            if (isAdmin($_SESSION['user_id'] ?? 0) || in_array($userIP, $allowedIPs)) {
                return false;
            }
            
            return true;
        }
        return false;
    }
}

/**
 * 检查密码复杂度
 */
if (!function_exists('checkPasswordComplexity')) {
    function checkPasswordComplexity($password) {
        $settings = getSettings();
        $minLength = $settings['password_min_length'] ?? 8;
        $complexity = $settings['password_complexity'] ?? 'medium';
        
        if (strlen($password) < $minLength) {
            return false;
        }
        
        switch ($complexity) {
            case 'high':
                if (!preg_match('/[A-Za-z]/', $password) || 
                    !preg_match('/[0-9]/', $password) || 
                    !preg_match('/[^A-Za-z0-9]/', $password)) {
                    return false;
                }
                break;
            case 'medium':
                if (!preg_match('/[A-Za-z]/', $password) || 
                    !preg_match('/[0-9]/', $password)) {
                    return false;
                }
                break;
            case 'low':
                break;
        }
        
        return true;
    }
}

/**
 * 检查是否达到登录尝试限制
 */
if (!function_exists('isLoginAttemptsExceeded')) {
    function isLoginAttemptsExceeded($username) {
        $settings = getSettings();
        $maxAttempts = $settings['max_login_attempts'] ?? 5;
        $banTime = $settings['login_ban_time'] ?? 30;
        
        $loginAttempts = readData(LOGIN_ATTEMPTS_FILE);
        $userAttempts = $loginAttempts[$username] ?? [];
        
        $validAttempts = array_filter($userAttempts, function($timestamp) use ($banTime) {
            return time() - $timestamp < $banTime * 60;
        });
        
        $loginAttempts[$username] = $validAttempts;
        writeData(LOGIN_ATTEMPTS_FILE, $loginAttempts);
        
        return count($validAttempts) >= $maxAttempts;
    }
}

/**
 * 记录登录尝试
 */
if (!function_exists('recordLoginAttempt')) {
    function recordLoginAttempt($username) {
        $loginAttempts = readData(LOGIN_ATTEMPTS_FILE);
        
        if (!isset($loginAttempts[$username])) {
            $loginAttempts[$username] = [];
        }
        
        $loginAttempts[$username][] = time();
        writeData(LOGIN_ATTEMPTS_FILE, $loginAttempts);
    }
}

/**
 * 清除登录尝试记录
 */
if (!function_exists('clearLoginAttempts')) {
    function clearLoginAttempts($username) {
        $loginAttempts = readData(LOGIN_ATTEMPTS_FILE);
        
        if (isset($loginAttempts[$username])) {
            unset($loginAttempts[$username]);
            writeData(LOGIN_ATTEMPTS_FILE, $loginAttempts);
        }
    }
}

/**
 * 检查是否需要邮箱验证
 */
if (!function_exists('requireEmailVerification')) {
    function requireEmailVerification() {
        $settings = getSettings();
        return isset($settings['require_email_verification']) && $settings['require_email_verification'];
    }
}

/**
 * 检查是否启用双重认证
 */
if (!function_exists('is2FAEnabled')) {
    function is2FAEnabled() {
        $settings = getSettings();
        return isset($settings['enable_2fa']) && $settings['enable_2fa'];
    }
}

/**
 * 获取默认用户角色
 */
if (!function_exists('getDefaultUserRole')) {
    function getDefaultUserRole() {
        $settings = getSettings();
        return $settings['default_user_role'] ?? 'member';
    }
}

/**
 * 获取所有板块
 */
if (!function_exists('getCategories')) {
    function getCategories() {
        return readData(CATEGORIES_FILE);
    }
}

/**
 * 获取板块信息
 */
if (!function_exists('getCategory')) {
    function getCategory($id) {
        $categories = getCategories();
        foreach ($categories as $category) {
            if ($category['id'] == $id) {
                return $category;
            }
        }
        return null;
    }
}

/**
 * 获取板块slug
 */
if (!function_exists('getCategorySlug')) {
    function getCategorySlug($id) {
        $category = getCategory($id);
        return $category ? $category['slug'] : '';
    }
}

/**
 * 获取所有用户
 */
if (!function_exists('getUsers')) {
    function getUsers() {
        $users = readData(USERS_FILE);
        
        // 确保每个用户都有bio字段
        foreach ($users as &$user) {
            if (!isset($user['bio'])) {
                $user['bio'] = '';
            }
        }
        
        return $users;
    }
}

/**
 * 获取用户信息
 */
if (!function_exists('getUser')) {
    function getUser($id) {
        $users = getUsers();
        foreach ($users as $user) {
            if ($user['id'] == $id) {
                // 确保有bio字段
                if (!isset($user['bio'])) {
                    $user['bio'] = '';
                }
                return $user;
            }
        }
        return null;
    }
}

/**
 * 通过用户名获取用户信息
 */
if (!function_exists('getUserByUsername')) {
    function getUserByUsername($username) {
        $users = getUsers();
        foreach ($users as $user) {
            if ($user['username'] == $username) {
                // 确保有bio字段
                if (!isset($user['bio'])) {
                    $user['bio'] = '';
                }
                return $user;
            }
        }
        return null;
    }
}

/**
 * 更新用户信息
 */
if (!function_exists('updateUser')) {
    function updateUser($userId, $data) {
        $users = readData(USERS_FILE);
        
        foreach ($users as &$user) {
            if ($user['id'] == $userId) {
                // 更新用户信息
                $user['username'] = $data['username'];
                $user['email'] = $data['email'];
                
                // 更新个人简介
                if (isset($data['bio'])) {
                    $user['bio'] = $data['bio'];
                }
                
                // 更新密码（如果提供了新密码）
                if (!empty($data['password'])) {
                    $user['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
                }
                
                break;
            }
        }
        
        writeData(USERS_FILE, $users);
    }
}

/**
 * 获取所有帖子
 */
if (!function_exists('getPosts')) {
    function getPosts($categoryId = null, $page = 1, $perPage = 10) {
        $posts = readData(POSTS_FILE);
        
        if ($categoryId) {
            $posts = array_filter($posts, function($post) use ($categoryId) {
                return $post['category_id'] == $categoryId;
            });
        }
        
        $total = count($posts);
        $offset = ($page - 1) * $perPage;
        $posts = array_slice($posts, $offset, $perPage);
        
        return [
            'posts' => $posts,
            'total' => $total,
            'pages' => ceil($total / $perPage),
            'current_page' => $page
        ];
    }
}

/**
 * 获取单个帖子
 */
if (!function_exists('getPost')) {
    function getPost($id) {
        $posts = readData(POSTS_FILE);
        foreach ($posts as $post) {
            if ($post['id'] == $id) {
                return $post;
            }
        }
        return null;
    }
}

/**
 * 获取帖子评论
 */
if (!function_exists('getComments')) {
    function getComments($postId, $includeHidden = false) {
        $comments = readData(COMMENTS_FILE);
        return array_filter($comments, function($comment) use ($postId, $includeHidden) {
            $matchesPost = $comment['post_id'] == $postId;
            $isHidden = isset($comment['is_hidden']) && $comment['is_hidden'];
            return $matchesPost && ($includeHidden || !$isHidden);
        });
    }
}

/**
 * 创建帖子
 */
if (!function_exists('createPost')) {
    function createPost($data) {
        // 检查操作频率
        $ip = $_SERVER['REMOTE_ADDR'];
        if (isActionFrequent('create_post', $ip, 5, 60)) {
            logSuspiciousAction('create_post', $ip);
            return ['error' => '操作过于频繁，请稍后再试'];
        }
        
        $posts = readData(POSTS_FILE);
        
        $ids = array_column($posts, 'id');
        $newId = $ids ? max($ids) + 1 : 1;
        
        $post = [
            'id' => $newId,
            'title' => $data['title'],
            'content' => $data['content'],
            'category_id' => $data['category_id'],
            'user_id' => $data['user_id'],
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
            'views' => 0,
            'likes' => []
        ];
        
        $posts[] = $post;
        writeData(POSTS_FILE, $posts);
        
        return $newId;
    }
}

/**
 * 更新帖子
 */
if (!function_exists('updatePost')) {
    function updatePost($id, $data) {
        // 检查操作频率
        $ip = $_SERVER['REMOTE_ADDR'];
        if (isActionFrequent('update_post', $ip, 5, 60)) {
            logSuspiciousAction('update_post', $ip);
            return ['error' => '操作过于频繁，请稍后再试'];
        }
        
        $posts = readData(POSTS_FILE);
        foreach ($posts as &$post) {
            if ($post['id'] == $id) {
                $post['title'] = $data['title'];
                $post['content'] = $data['content'];
                $post['category_id'] = $data['category_id'];
                $post['updated_at'] = date('Y-m-d H:i:s');
                break;
            }
        }
        writeData(POSTS_FILE, $posts);
    }
}

/**
 * 删除帖子
 */
if (!function_exists('deletePost')) {
    function deletePost($id) {
        // 检查操作频率
        $ip = $_SERVER['REMOTE_ADDR'];
        if (isActionFrequent('delete_post', $ip, 3, 60)) {
            logSuspiciousAction('delete_post', $ip);
            return ['error' => '操作过于频繁，请稍后再试'];
        }
        
        $posts = readData(POSTS_FILE);
        $posts = array_filter($posts, function($post) use ($id) {
            return $post['id'] != $id;
        });
        writeData(POSTS_FILE, $posts);
        
        $comments = readData(COMMENTS_FILE);
        $comments = array_filter($comments, function($comment) use ($id) {
            return $comment['post_id'] != $id;
        });
        writeData(COMMENTS_FILE, $comments);
    }
}

/**
 * 添加评论
 */
if (!function_exists('addComment')) {
    function addComment($data) {
        // 检查操作频率
        $ip = $_SERVER['REMOTE_ADDR'];
        if (isActionFrequent('add_comment', $ip, 10, 60)) {
            logSuspiciousAction('add_comment', $ip);
            return ['error' => '操作过于频繁，请稍后再试'];
        }
        
        $comments = readData(COMMENTS_FILE);
        
        $ids = array_column($comments, 'id');
        $newId = $ids ? max($ids) + 1 : 1;
        
        $comment = [
            'id' => $newId,
            'post_id' => $data['post_id'],
            'user_id' => $data['user_id'],
            'content' => $data['content'],
            'created_at' => date('Y-m-d H:i:s'),
            'is_hidden' => false,
            'replies' => []
        ];
        
        if (isset($data['parent_id'])) {
            foreach ($comments as &$c) {
                if ($c['id'] == $data['parent_id']) {
                    $comment['parent_id'] = $data['parent_id'];
                    $c['replies'][] = $newId;
                    break;
                }
            }
        }
        
        $comments[] = $comment;
        writeData(COMMENTS_FILE, $comments);
        
        return $newId;
    }
}

/**
 * 点赞帖子
 */
if (!function_exists('likePost')) {
    function likePost($postId, $userId) {
        // 检查操作频率
        $ip = $_SERVER['REMOTE_ADDR'];
        if (isActionFrequent('like_post', $ip, 20, 60)) {
            logSuspiciousAction('like_post', $ip);
            return ['error' => '操作过于频繁，请稍后再试'];
        }
        
        $posts = readData(POSTS_FILE);
        foreach ($posts as &$post) {
            if ($post['id'] == $postId) {
                if (!in_array($userId, $post['likes'])) {
                    $post['likes'][] = $userId;
                }
                break;
            }
        }
        writeData(POSTS_FILE, $posts);
    }
}

/**
 * 取消点赞
 */
if (!function_exists('unlikePost')) {
    function unlikePost($postId, $userId) {
        // 检查操作频率
        $ip = $_SERVER['REMOTE_ADDR'];
        if (isActionFrequent('unlike_post', $ip, 20, 60)) {
            logSuspiciousAction('unlike_post', $ip);
            return ['error' => '操作过于频繁，请稍后再试'];
        }
        
        $posts = readData(POSTS_FILE);
        foreach ($posts as &$post) {
            if ($post['id'] == $postId) {
                $post['likes'] = array_diff($post['likes'], [$userId]);
                break;
            }
        }
        writeData(POSTS_FILE, $posts);
    }
}

/**
 * 增加帖子浏览量
 */
if (!function_exists('incrementPostViews')) {
    function incrementPostViews($postId) {
        $posts = readData(POSTS_FILE);
        foreach ($posts as &$post) {
            if ($post['id'] == $postId) {
                $post['views']++;
                break;
            }
        }
        writeData(POSTS_FILE, $posts);
    }
}

/**
 * 搜索帖子
 */
if (!function_exists('searchPosts')) {
    function searchPosts($query, $page = 1, $perPage = 10) {
        $posts = readData(POSTS_FILE);
        
        $results = array_filter($posts, function($post) use ($query) {
            return stripos($post['title'], $query) !== false || 
                   stripos($post['content'], $query) !== false;
        });
        
        $total = count($results);
        $offset = ($page - 1) * $perPage;
        $results = array_slice($results, $offset, $perPage);
        
        return [
            'results' => $results,
            'total' => $total,
            'pages' => ceil($total / $perPage),
            'current_page' => $page
        ];
    }
}

/**
 * 处理提及 (@username)
 */
if (!function_exists('processMentions')) {
    function processMentions($text) {
        return preg_replace('/@(\w+)/', '<a href="/profile.php?username=$1">@$1</a>', $text);
    }
}

/**
 * 上传头像
 */
if (!function_exists('uploadAvatar')) {
    function uploadAvatar($file, $userId) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($ext, $allowed)) {
            return ['success' => false, 'message' => '只允许上传 JPG, PNG 或 GIF 图片'];
        }
        
        if ($file['size'] > 500000) {
            return ['success' => false, 'message' => '图片大小不能超过 500KB'];
        }
        
        // 生成唯一的文件名
        $filename = 'avatar_' . $userId . '_' . time() . '.' . $ext;
        $destination = UPLOAD_DIR . '/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $destination)) {
            $users = readData(USERS_FILE);
            foreach ($users as &$user) {
                if ($user['id'] == $userId) {
                    // 删除旧头像（如果存在）
                    if (!empty($user['avatar']) && file_exists(UPLOAD_DIR . '/' . $user['avatar'])) {
                        unlink(UPLOAD_DIR . '/' . $user['avatar']);
                    }
                    
                    $user['avatar'] = $filename;
                    break;
                }
            }
            writeData(USERS_FILE, $users);
            
            return ['success' => true, 'filename' => $filename];
        }
        
        return ['success' => false, 'message' => '上传失败'];
    }
}

/**
 * 获取用户帖子
 */
if (!function_exists('getUserPosts')) {
    function getUserPosts($userId, $page = 1, $perPage = 10) {
        $posts = readData(POSTS_FILE);
        $posts = array_filter($posts, function($post) use ($userId) {
            return $post['user_id'] == $userId;
        });
        
        $total = count($posts);
        $offset = ($page - 1) * $perPage;
        $posts = array_slice($posts, $offset, $perPage);
        
        return [
            'posts' => $posts,
            'total' => $total,
            'pages' => ceil($total / $perPage),
            'current_page' => $page
        ];
    }
}

/**
 * 检查用户是否是管理员
 */
if (!function_exists('isAdmin')) {
    function isAdmin($userId) {
        $user = getUser($userId);
        return $user && isset($user['is_admin']) && $user['is_admin'];
    }
}

/**
 * 获取用户收藏的帖子
 */
if (!function_exists('getUserFavorites')) {
    function getUserFavorites($userId) {
        $users = readData(USERS_FILE);
        foreach ($users as $user) {
            if ($user['id'] == $userId && isset($user['favorites'])) {
                return $user['favorites'];
            }
        }
        return [];
    }
}

/**
 * 收藏帖子
 */
if (!function_exists('addFavorite')) {
    function addFavorite($userId, $postId) {
        // 检查操作频率
        $ip = $_SERVER['REMOTE_ADDR'];
        if (isActionFrequent('add_favorite', $ip, 15, 60)) {
            logSuspiciousAction('add_favorite', $ip);
            return ['error' => '操作过于频繁，请稍后再试'];
        }
        
        $users = readData(USERS_FILE);
        foreach ($users as &$user) {
            if ($user['id'] == $userId) {
                if (!isset($user['favorites'])) {
                    $user['favorites'] = [];
                }
                if (!in_array($postId, $user['favorites'])) {
                    $user['favorites'][] = $postId;
                }
                break;
            }
        }
        writeData(USERS_FILE, $users);
    }
}

/**
 * 取消收藏
 */
if (!function_exists('removeFavorite')) {
    function removeFavorite($userId, $postId) {
        // 检查操作频率
        $ip = $_SERVER['REMOTE_ADDR'];
        if (isActionFrequent('remove_favorite', $ip, 15, 60)) {
            logSuspiciousAction('remove_favorite', $ip);
            return ['error' => '操作过于频繁，请稍后再试'];
        }
        
        $users = readData(USERS_FILE);
        foreach ($users as &$user) {
            if ($user['id'] == $userId && isset($user['favorites'])) {
                $user['favorites'] = array_diff($user['favorites'], [$postId]);
                break;
            }
        }
        writeData(USERS_FILE, $users);
    }
}

/*************************** 评论管理功能 ***************************/

/**
 * 隐藏评论
 */
if (!function_exists('hideComment')) {
    function hideComment($commentId) {
        // 检查操作频率
        $ip = $_SERVER['REMOTE_ADDR'];
        if (isActionFrequent('hide_comment', $ip, 5, 60)) {
            logSuspiciousAction('hide_comment', $ip);
            return ['error' => '操作过于频繁，请稍后再试'];
        }
        
        $comments = readData(COMMENTS_FILE);
        $updated = false;
        
        foreach ($comments as &$comment) {
            if ($comment['id'] == $commentId) {
                $comment['is_hidden'] = true;
                $updated = true;
                break;
            }
        }
        
        if ($updated) {
            writeData(COMMENTS_FILE, $comments);
        }
        return $updated;
    }
}

/**
 * 显示评论
 */
if (!function_exists('showComment')) {
    function showComment($commentId) {
        // 检查操作频率
        $ip = $_SERVER['REMOTE_ADDR'];
        if (isActionFrequent('show_comment', $ip, 5, 60)) {
            logSuspiciousAction('show_comment', $ip);
            return ['error' => '操作过于频繁，请稍后再试'];
        }
        
        $comments = readData(COMMENTS_FILE);
        $updated = false;
        
        foreach ($comments as &$comment) {
            if ($comment['id'] == $commentId) {
                $comment['is_hidden'] = false;
                $updated = true;
                break;
            }
        }
        
        if ($updated) {
            writeData(COMMENTS_FILE, $comments);
        }
        return $updated;
    }
}

/**
 * 删除评论
 */
if (!function_exists('deleteComment')) {
    function deleteComment($commentId) {
        // 检查操作频率
        $ip = $_SERVER['REMOTE_ADDR'];
        if (isActionFrequent('delete_comment', $ip, 3, 60)) {
            logSuspiciousAction('delete_comment', $ip);
            return ['error' => '操作过于频繁，请稍后再试'];
        }
        
        $comments = readData(COMMENTS_FILE);
        $newComments = [];
        $deleted = false;
        
        foreach ($comments as $comment) {
            if ($comment['id'] != $commentId) {
                $newComments[] = $comment;
            } else {
                $deleted = true;
            }
        }
        
        if ($deleted) {
            writeData(COMMENTS_FILE, $newComments);
        }
        return $deleted;
    }
}

/**
 * 批量操作评论
 */
if (!function_exists('bulkCommentAction')) {
    function bulkCommentAction($commentIds, $action) {
        // 极简版实现
        $results = [];
        
        foreach ($commentIds as $commentId) {
            switch ($action) {
                case 'hide':
                    $results[$commentId] = hideComment($commentId);
                    break;
                case 'show':
                    $results[$commentId] = showComment($commentId);
                    break;
                case 'delete':
                    $results[$commentId] = deleteComment($commentId);
                    break;
                default:
                    $results[$commentId] = false;
            }
        }
        
        return $results;
    }
}

/**
 * 获取所有评论（带分页）
 */
if (!function_exists('getAllComments')) {
    function getAllComments($page = 1, $perPage = 15, $search = '') {
        $comments = readData(COMMENTS_FILE);
        
        if (!empty($search)) {
            $filteredComments = [];
            foreach ($comments as $comment) {
                $contentMatch = stripos($comment['content'], $search) !== false;
                $authorMatch = false;
                
                $user = getUser($comment['user_id']);
                if ($user && stripos($user['username'], $search) !== false) {
                    $authorMatch = true;
                }
                
                if ($contentMatch || $authorMatch) {
                    $filteredComments[] = $comment;
                }
            }
            $comments = $filteredComments;
        }
        
        $total = count($comments);
        $offset = ($page - 1) * $perPage;
        $comments = array_slice($comments, $offset, $perPage);
        
        return [
            'comments' => $comments,
            'total' => $total,
            'pages' => ceil($total / $perPage),
            'current_page' => $page
        ];
    }
}

/**
 * 获取评论作者用户名
 */
if (!function_exists('getCommentAuthor')) {
    function getCommentAuthor($comment) {
        $user = getUser($comment['user_id']);
        return $user ? $user['username'] : '未知用户';
    }
}

/**
 * 获取评论所属帖子标题
 */
if (!function_exists('getCommentPostTitle')) {
    function getCommentPostTitle($comment) {
        $post = getPost($comment['post_id']);
        return $post ? $post['title'] : '帖子已删除';
    }
}

/*************************** 新增功能 ***************************/

/**
 * 检查IP是否在24小时内注册过
 */
if (!function_exists('canRegisterToday')) {
    function canRegisterToday($ip) {
        $registrations = readData(REGISTRATIONS_FILE);
        $now = time();
        $oneDay = 86400; // 24小时秒数
        
        if (isset($registrations[$ip])) {
            $lastRegistration = $registrations[$ip];
            return ($now - $lastRegistration) > $oneDay;
        }
        
        return true;
    }
}

/**
 * 记录注册IP和时间
 */
if (!function_exists('recordRegistration')) {
    function recordRegistration($ip) {
        $registrations = readData(REGISTRATIONS_FILE);
        $registrations[$ip] = time();
        writeData(REGISTRATIONS_FILE, $registrations);
    }
}

/**
 * 检查操作是否过于频繁
 */
if (!function_exists('isActionFrequent')) {
    function isActionFrequent($actionType, $ip, $threshold, $timeWindow) {
        $actionLogs = readData(ACTION_LOGS_FILE);
        $now = time();
        
        // 初始化日志结构
        if (!isset($actionLogs[$ip])) {
            $actionLogs[$ip] = [];
        }
        
        if (!isset($actionLogs[$ip][$actionType])) {
            $actionLogs[$ip][$actionType] = [];
        }
        
        // 过滤过期记录
        $actionLogs[$ip][$actionType] = array_filter(
            $actionLogs[$ip][$actionType],
            function($timestamp) use ($now, $timeWindow) {
                return ($now - $timestamp) < $timeWindow;
            }
        );
        
        // 添加当前操作记录
        $actionLogs[$ip][$actionType][] = $now;
        writeData(ACTION_LOGS_FILE, $actionLogs);
        
        // 检查是否超过阈值
        return count($actionLogs[$ip][$actionType]) > $threshold;
    }
}

/**
 * 记录可疑操作（包含地理位置信息）
 */
if (!function_exists('logSuspiciousAction')) {
    function logSuspiciousAction($actionType, $ip) {
        $logs = readData(ACTION_LOGS_FILE);
        
        // 获取地理位置信息
        $geoInfo = getGeolocation($ip);
        
        // 创建日志条目
        $logEntry = [
            'ip' => $ip,
            'action' => $actionType,
            'timestamp' => time(),
            'geo' => $geoInfo
        ];
        
        // 添加到日志
        if (!isset($logs['suspicious'])) {
            $logs['suspicious'] = [];
        }
        
        $logs['suspicious'][] = $logEntry;
        writeData(ACTION_LOGS_FILE, $logs);
    }
}

if (!function_exists('getAllPosts')) {
    function getAllPosts() {
        $postsFile = POSTS_FILE;
        
        if (!file_exists($postsFile)) {
            return [];
        }
        
        $postsData = file_get_contents($postsFile);
        return unserialize($postsData);
    }
}

/**
 * 获取IP的地理位置信息
 */
if (!function_exists('getGeolocation')) {
    function getGeolocation($ip) {
        // 使用IP地址获取地理位置信息
        // 注意：实际应用中应使用第三方API（如ip-api.com）
        // 这里使用模拟数据
        
        $geoData = [
            'ip' => $ip,
            'country' => '未知',
            'region' => '未知',
            'city' => '未知',
            'lat' => 0,
            'lon' => 0
        ];
        
        // 如果是本地IP，使用默认值
        if ($ip === '127.0.0.1' || $ip === '::1') {
            return $geoData;
        }
        
        // 模拟API调用
        $url = "http://ip-api.com/json/{$ip}";
        $response = @file_get_contents($url);
        
        if ($response) {
            $data = json_decode($response, true);
            if ($data && $data['status'] === 'success') {
                $geoData = [
                    'ip' => $ip,
                    'country' => $data['country'] ?? '未知',
                    'region' => $data['regionName'] ?? '未知',
                    'city' => $data['city'] ?? '未知',
                    'lat' => $data['lat'] ?? 0,
                    'lon' => $data['lon'] ?? 0
                ];
            }
        }
        
        return $geoData;
    }
}

/*************************** 头衔系统功能 ***************************/

/**
 * 获取所有头衔
 */
if (!function_exists('getBadges')) {
    function getBadges() {
        $badgesFile = BADGES_FILE;
        if (!file_exists($badgesFile)) {
            return [];
        }
        return readData($badgesFile);
    }
}

/**
 * 获取用户头衔
 */
if (!function_exists('getUserBadges')) {
    function getUserBadges($userId) {
        $userBadgesFile = USER_BADGES_FILE;
        if (!file_exists($userBadgesFile)) {
            return [];
        }
        
        $userBadges = readData($userBadgesFile);
        return isset($userBadges[$userId]) ? $userBadges[$userId] : [];
    }
}

/**
 * 申请头衔
 */
if (!function_exists('applyForBadge')) {
    function applyForBadge($userId, $badgeName, $reason) {
        $settings = getSettings();
        $badgeSettings = $settings['badge_settings'] ?? [];
        $maxLength = $badgeSettings['max_badge_length'] ?? 20;
        $minLength = $badgeSettings['min_badge_length'] ?? 2;
        $maxApplications = $badgeSettings['max_applications_per_user'] ?? 3;
        $cooldownPeriod = $badgeSettings['cooldown_period'] ?? 30;
        
        // 验证头衔名称
        if (strlen($badgeName) < $minLength || strlen($badgeName) > $maxLength) {
            return ['error' => "头衔名称长度必须在{$minLength}-{$maxLength}个字符之间"];
        }
        
        // 检查用户是否有过多的待处理申请
        $applications = getUserBadgeApplications($userId);
        $pendingCount = count(array_filter($applications, function($app) {
            return $app['status'] === 'pending';
        }));
        
        if ($pendingCount >= $maxApplications) {
            return ['error' => "您已经有{$pendingCount}个待处理的头衔申请，请等待处理完成后再提交新的申请"];
        }
        
        // 检查冷却期
        $lastApplication = end($applications);
        if ($lastApplication && $lastApplication['status'] === 'rejected') {
            $lastRejectedTime = strtotime($lastApplication['processed_at']);
            $cooldownEnd = $lastRejectedTime + ($cooldownPeriod * 86400);
            
            if (time() < $cooldownEnd) {
                $remainingDays = ceil(($cooldownEnd - time()) / 86400);
                return ['error' => "您的上一个申请被拒绝，请等待{$remainingDays}天后再提交新的申请"];
            }
        }
        
        $applicationsFile = BADGE_APPLICATIONS_FILE;
        $applications = readData($applicationsFile);
        
        $applicationId = uniqid();
        
        $applications[$applicationId] = [
            'id' => $applicationId,
            'user_id' => $userId,
            'badge_name' => $badgeName,
            'reason' => $reason,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s'),
            'processed_at' => null,
            'processed_by' => null
        ];
        
        writeData($applicationsFile, $applications);
        return ['success' => true, 'application_id' => $applicationId];
    }
}

/**
 * 处理头衔申请
 */
if (!function_exists('processBadgeApplication')) {
    function processBadgeApplication($applicationId, $status, $adminId) {
        $applicationsFile = BADGE_APPLICATIONS_FILE;
        $applications = readData($applicationsFile);
        
        if (!isset($applications[$applicationId])) {
            return ['error' => '申请不存在'];
        }
        
        $application = $applications[$applicationId];
        
        // 只能处理待处理的申请
        if ($application['status'] !== 'pending') {
            return ['error' => '该申请已被处理'];
        }
        
        $application['status'] = $status;
        $application['processed_at'] = date('Y-m-d H:i:s');
        $application['processed_by'] = $adminId;
        
        $applications[$applicationId] = $application;
        writeData($applicationsFile, $applications);
        
        // 如果批准，将头衔添加到用户
        if ($status === 'approved') {
            $userBadgesFile = USER_BADGES_FILE;
            $userBadges = readData($userBadgesFile);
            
            if (!isset($userBadges[$application['user_id']])) {
                $userBadges[$application['user_id']] = [];
            }
            
            $userBadges[$application['user_id']][] = [
                'name' => $application['badge_name'],
                'granted_at' => date('Y-m-d H:i:s'),
                'granted_by' => $adminId
            ];
            
            writeData($userBadgesFile, $userBadges);
        }
        
        return ['success' => true];
    }
}

/**
 * 获取用户的头衔申请
 */
if (!function_exists('getUserBadgeApplications')) {
    function getUserBadgeApplications($userId) {
        $applicationsFile = BADGE_APPLICATIONS_FILE;
        if (!file_exists($applicationsFile)) {
            return [];
        }
        
        $applications = readData($applicationsFile);
        return array_filter($applications, function($app) use ($userId) {
            return $app['user_id'] == $userId;
        });
    }
}

/**
 * 获取所有待处理的头衔申请
 */
if (!function_exists('getPendingBadgeApplications')) {
    function getPendingBadgeApplications() {
        $applicationsFile = BADGE_APPLICATIONS_FILE;
        if (!file_exists($applicationsFile)) {
            return [];
        }
        
        $applications = readData($applicationsFile);
        return array_filter($applications, function($app) {
            return $app['status'] == 'pending';
        });
    }
}

/**
 * 检查用户是否可以申请头衔
 */
if (!function_exists('canUserApplyForBadge')) {
    function canUserApplyForBadge($userId) {
        $settings = getSettings();
        $badgeSettings = $settings['badge_settings'] ?? [];
        $maxApplications = $badgeSettings['max_applications_per_user'] ?? 3;
        $cooldownPeriod = $badgeSettings['cooldown_period'] ?? 30;
        
        $applications = getUserBadgeApplications($userId);
        $pendingCount = count(array_filter($applications, function($app) {
            return $app['status'] === 'pending';
        }));
        
        // 检查待处理申请数量
        if ($pendingCount >= $maxApplications) {
            return ['can_apply' => false, 'reason' => '您已经有太多待处理的申请'];
        }
        
        // 检查冷却期
        $lastApplication = end($applications);
        if ($lastApplication && $lastApplication['status'] === 'rejected') {
            $lastRejectedTime = strtotime($lastApplication['processed_at']);
            $cooldownEnd = $lastRejectedTime + ($cooldownPeriod * 86400);
            
            if (time() < $cooldownEnd) {
                $remainingDays = ceil(($cooldownEnd - time()) / 86400);
                return ['can_apply' => false, 'reason' => "您的上一个申请被拒绝，请等待{$remainingDays}天后再提交新的申请"];
            }
        }
        
        return ['can_apply' => true];
    }
}
?>
