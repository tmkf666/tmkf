<?php
// 开启会话
session_start();

// 定义常量
define('ROOT_PATH', dirname(__DIR__));
define('DATA_DIR', ROOT_PATH . '/tm');
define('UPLOAD_DIR', ROOT_PATH . '/images');

// 数据库文件
define('USERS_FILE', DATA_DIR . '/users.txt');
define('POSTS_FILE', DATA_DIR . '/posts.txt');
define('COMMENTS_FILE', DATA_DIR . '/comments.txt');
define('CATEGORIES_FILE', DATA_DIR . '/categories.txt');
define('SETTINGS_FILE', DATA_DIR . '/settings.txt');
define('LOGIN_ATTEMPTS_FILE', DATA_DIR . '/login_attempts.txt');
define('REGISTRATIONS_FILE', DATA_DIR . '/registrations.dat');
define('ACTION_LOGS_FILE', DATA_DIR . '/action_logs.dat');

// 初始化板块
if (!file_exists(CATEGORIES_FILE)) {
    $categories = [
        ['id' => 1, 'name' => '科技数码', 'slug' => 'tech'],
        ['id' => 2, 'name' => '生活分享', 'slug' => 'life'],
        ['id' => 3, 'name' => '学习交流', 'slug' => 'study']
    ];
    file_put_contents(CATEGORIES_FILE, serialize($categories));
}

// 初始化系统设置
if (!file_exists(SETTINGS_FILE)) {
    $defaultSettings = [
        'site_title' => '我的论坛',
        'site_description' => '欢迎来到我们的社区论坛',
        'posts_per_page' => 10,
        'comments_per_page' => 15,
        'allow_registrations' => 1,
        'default_user_role' => 'member',
        'require_email_verification' => 0,
        'max_login_attempts' => 5,
        'login_ban_time' => 30,
        'password_min_length' => 8,
        'password_complexity' => 'medium',
        'enable_2fa' => 0,
        
        // 维护设置 - 使用嵌套数组结构
        'maintenance' => [
            'enabled' => false,
            'message' => '网站正在维护中，请稍后再访问',
            'allowed_ips' => [],
            'start_time' => null,
            'end_time' => null
        ]
    ];
    file_put_contents(SETTINGS_FILE, serialize($defaultSettings));
}

// 错误报告
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 确保目录存在
if (!file_exists(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
}
if (!file_exists(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}
?>
