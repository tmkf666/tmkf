<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

// 检查用户是否登录
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$currentUser = getCurrentUser();
$postId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$post = getPost($postId);

// 检查帖子是否存在和用户权限
if (!$post || ($post['user_id'] != $currentUser['id'] && !$currentUser['is_admin'])) {
    header('HTTP/1.0 404 Not Found');
    exit('无权删除此帖子');
}

// 删除帖子
deletePost($postId);

// 重定向到首页或用户个人中心
$redirect = $currentUser['is_admin'] ? 'admin/posts.php' : 'profile.php';
header("Location: $redirect");
exit;
?>