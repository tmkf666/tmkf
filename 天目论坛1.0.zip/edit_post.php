<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

// 检查用户是否登录
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$currentUser = getCurrentUser();
$postId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$post = getPost($postId);

// 检查帖子是否存在和用户权限
if (!$post || ($post['user_id'] != $currentUser['id'] && !$currentUser['is_admin'])) {
    header('HTTP/1.0 404 Not Found');
    exit('无权编辑此帖子');
}

$error = '';
$success = '';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $categoryId = intval($_POST['category_id']);
    
    // 验证输入
    if (empty($title) || empty($content)) {
        $error = '请填写标题和内容';
    } elseif (strlen($title) > 100) {
        $error = '标题不能超过100个字符';
    } else {
        // 处理内容中的媒体
        $content = processMediaContent($content);
        
        // 更新帖子
        updatePost($postId, [
            'title' => $title,
            'content' => $content,
            'category_id' => $categoryId
        ]);
        
        $success = '帖子更新成功！正在跳转...';
        header("Refresh: 2; url=post.php?id=$postId");
    }
}

$categories = getCategories();

/**
 * 处理内容中的媒体（图片/视频）
 */
function processMediaContent($content) {
    // 处理视频链接
    $content = preg_replace_callback(
        '/\[video\](.*?)\[\/video\]/i',
        function($matches) {
            $url = $matches[1];
            if (filter_var($url, FILTER_VALIDATE_URL)) {
                return '<div class="video-container"><iframe src="'.htmlspecialchars($url).'" frameborder="0" allowfullscreen></iframe></div>';
            }
            return '';
        },
        $content
    );
    
    // 处理图片链接
    $content = preg_replace_callback(
        '/\[img\](.*?)\[\/img\]/i',
        function($matches) {
            $url = $matches[1];
            if (filter_var($url, FILTER_VALIDATE_URL)) {
                return '<img src="'.htmlspecialchars($url).'" alt="用户图片" class="user-image">';
            }
            return '';
        },
        $content
    );
    
    return $content;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>编辑帖子 - 天目官方论坛</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #ff85a2; /* 粉色主色调 */
            --primary-light: #ffb6c1; /* 浅粉色 */
            --primary-dark: #e75480; /* 深粉色 */
            --secondary: #9b5de5; /* 紫色 */
            --accent: #00bbf9; /* 蓝色 */
            --light: #fff9fb; /* 浅粉色背景 */
            --dark: #4a4a4a; /* 深灰色 */
            --gray: #a0a0a0; /* 灰色 */
            --success: #00f5d4; /* 青色 */
            --danger: #f72585; /* 红色 */
            --warning: #ffd166; /* 黄色 */
            --border-radius: 16px; /* 更大的圆角 */
            --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15); /* 柔和阴影 */
            --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94); /* 平滑过渡 */
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        a {
            text-decoration: none;
            color: inherit;
            transition: var(--transition);
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
        }
        
        /* 头部样式 - 天目官方风格 */
        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1.5rem;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .logo i {
            font-size: 1.75rem;
            color: #fff;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem;
            border-radius: 50%;
        }
        
        nav ul {
            display: flex;
            gap: 0.5rem;
            list-style: none;
        }
        
        nav ul li a {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        nav ul li a:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        
        nav ul li a i {
            font-size: 1.1rem;
        }
        
        .search-box {
            flex: 1;
            max-width: 400px;
        }
        
        .search-box form {
            display: flex;
            gap: 0.5rem;
        }
        
        .search-box input {
            flex: 1;
            padding: 0.75rem 1.25rem;
            border: none;
            border-radius: 50px;
            font-size: 0.95rem;
            background: rgba(255, 255, 255, 0.9);
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .search-box button {
            padding: 0.75rem 1.25rem;
            background-color: var(--accent);
            color: white;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 4px 10px rgba(0, 187, 249, 0.3);
        }
        
        .search-box button:hover {
            background-color: #0099cc;
            transform: translateY(-2px);
        }
        
        /* 主体内容 */
        main {
            flex: 1;
            padding: 2rem 0;
        }
        
        /* 编辑帖子区域 */
        .edit-post {
            background-color: white;
            padding: 30px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            margin-bottom: 30px;
            position: relative;
            border: 1px solid rgba(255, 133, 162, 0.1);
        }
        
        .edit-post::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 50%, var(--accent) 100%);
        }
        
        .edit-post h2 {
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 1.8rem;
            color: var(--dark);
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--dark);
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 0.75rem 1.25rem;
            border: 1px solid #e0e0e0;
            border-radius: var(--border-radius);
            font-family: inherit;
            font-size: 1rem;
            transition: var(--transition);
            background-color: white;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 133, 162, 0.2);
        }
        
        .form-group textarea {
            min-height: 300px;
            resize: vertical;
            line-height: 1.6;
        }
        
        /* 按钮样式 */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border: none;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.3);
            position: relative;
            overflow: hidden;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(155, 93, 229, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn i {
            font-size: 1.1rem;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, var(--danger) 0%, #e75480 100%);
        }
        
        .btn-danger:hover {
            background: linear-gradient(135deg, #e75480 0%, #c53a6c 100%);
        }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .alert.error {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--danger);
            border-left: 4px solid var(--danger);
        }
        
        .alert.success {
            background-color: rgba(0, 245, 212, 0.1);
            color: var(--success);
            border-left: 4px solid var(--success);
        }
        
        .editor-toolbar {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
        }
        
        .editor-btn {
            padding: 0.5rem 1rem;
            background-color: #f8f9fa;
            border: 1px solid #e0e0e0;
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .editor-btn:hover {
            background-color: #e9ecef;
            transform: translateY(-2px);
        }
        
        .editor-btn i {
            font-size: 1rem;
        }
        
        .form-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
        }
        
        /* 底部导航栏 */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 133, 162, 0.2);
            padding: 0.75rem 0;
            display: none;
            z-index: 1000;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .nav-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
            padding: 0.5rem;
            border-radius: 50px;
            transition: var(--transition);
            color: var(--gray);
        }
        
        .nav-item.active {
            color: var(--primary);
        }
        
        .nav-item i {
            font-size: 1.25rem;
            background: rgba(255, 133, 162, 0.1);
            width: 2.5rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .nav-item.active i {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 10px rgba(255, 133, 162, 0.3);
        }
        
        .nav-item span {
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        footer {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            text-align: center;
            padding: 1.5rem 0;
            margin-top: 3rem;
            border-top: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        footer p {
            opacity: 0.9;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        }
        
        /* 响应式设计 */
        @media (max-width: 992px) {
            .edit-post {
                padding: 1.5rem;
            }
            
            .form-group textarea {
                min-height: 200px;
            }
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: row;
                align-items: center;
                flex-wrap: wrap;
            }
            
            .logo {
                order: 1;
                flex: 1;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            .mobile-menu-btn {
                display: block;
                order: 2;
            }
            
            nav {
                order: 4;
                width: 100%;
                display: none;
                margin-top: 1rem;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .search-box {
                order: 3;
                width: 100%;
                margin-top: 1rem;
                display: none;
            }
            
            .search-box.active {
                display: block;
            }
            
            .edit-post h2 {
                font-size: 1.5rem;
            }
            
            .form-actions {
                flex-direction: column;
                gap: 0.75rem;
            }
            
            .btn {
                width: 100%;
            }
            
            /* 显示底部导航 */
            .bottom-nav {
                display: block;
            }
            
            /* 为移动端留出底部空间 */
            main {
                margin-bottom: 4rem;
            }
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 0 1rem;
            }
            
            .edit-post {
                padding: 1.25rem;
            }
            
            .editor-toolbar {
                gap: 0.25rem;
            }
            
            .editor-btn {
                padding: 0.5rem;
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <a href="index.php" class="logo">
                    <i class="bi bi-chat-square-heart"></i>
                    <span>天目官方论坛</span>
                </a>
                
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="bi bi-list"></i>
                </button>
                
                <nav id="mainNav">
                    <ul>
                        <li><a href="index.php"><i class="bi bi-house"></i> 首页</a></li>
                        <li><a href="categories.php"><i class="bi bi-compass"></i> 发现</a></li>
                        <li><a href="create_post.php"><i class="bi bi-plus-circle"></i> 发帖</a></li>
                        <li><a href="profile.php"><i class="bi bi-person"></i> 个人中心</a></li>
                    </ul>
                </nav>
                
                <div class="search-box" id="searchBox">
                    <form action="search.php" method="get">
                        <input type="text" name="q" placeholder="搜索帖子..." value="<?= isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '' ?>">
                        <button type="submit"><i class="bi bi-search"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="edit-post">
            <h2><i class="bi bi-pencil-square"></i> 编辑帖子</h2>
            
            <?php if ($error): ?>
                <div class="alert error">
                    <i class="bi bi-exclamation-circle"></i> <?= $error ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert success">
                    <i class="bi bi-check-circle"></i> <?= $success ?>
                </div>
            <?php else: ?>
                <form action="edit_post.php?id=<?= $postId ?>" method="post">
                    <div class="form-group">
                        <label for="title">标题</label>
                        <input type="text" id="title" name="title" maxlength="100" value="<?= htmlspecialchars($post['title']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="category_id">板块</label>
                        <select id="category_id" name="category_id" required>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['id'] ?>" <?= $category['id'] == $post['category_id'] ? 'selected' : '' ?>>
                                    <?= $category['name'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="content">内容</label>
                        
                        <!-- 编辑器工具栏 -->
                        <div class="editor-toolbar">
                            <button type="button" class="editor-btn" onclick="insertText('bold', '**加粗文字**')" title="加粗"><i class="bi bi-type-bold"></i></button>
                            <button type="button" class="editor-btn" onclick="insertText('italic', '*斜体文字*')" title="斜体"><i class="bi bi-type-italic"></i></button>
                            <button type="button" class="editor-btn" onclick="insertText('heading', '### 标题')" title="标题"><i class="bi bi-type-h3"></i></button>
                            <button type="button" class="editor-btn" onclick="insertText('link', '[链接文字](https://)')" title="链接"><i class="bi bi-link"></i></button>
                            <button type="button" class="editor-btn" onclick="insertText('image', '[img]图片链接[/img]')" title="插入图片"><i class="bi bi-image"></i></button>
                            <button type="button" class="editor-btn" onclick="insertText('video', '[video]视频链接[/video]')" title="插入视频"><i class="bi bi-film"></i></button>
                            <button type="button" class="editor-btn" onclick="insertText('quote', '> 引用内容')" title="引用"><i class="bi bi-quote"></i></button>
                            <button type="button" class="editor-btn" onclick="insertText('code', '```代码块```')" title="代码"><i class="bi bi-code"></i></button>
                            <button type="button" class="editor-btn" onclick="insertText('list', '- 列表项')" title="列表"><i class="bi bi-list-ul"></i></button>
                        </div>
                        
                        <textarea id="content" name="content" rows="15" required><?= htmlspecialchars($post['content']) ?></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn"><i class="bi bi-save"></i> 保存更改</button>
                        <a href="post.php?id=<?= $postId ?>" class="btn btn-danger"><i class="bi bi-x-circle"></i> 取消</a>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </main>
    
    <!-- 底部导航栏 -->
    <nav class="bottom-nav">
        <div class="nav-items">
            <a href="index.php" class="nav-item">
                <i class="bi bi-house"></i>
                <span>主页</span>
            </a>
            <a href="discover.php" class="nav-item">
                <i class="bi bi-compass"></i>
                <span>发现</span>
            </a>
            <a href="create_post.php" class="nav-item">
                <i class="bi bi-plus-circle"></i>
                <span>添加</span>
            </a>
            <a href="search.php" class="nav-item">
                <i class="bi bi-search"></i>
                <span>搜索</span>
            </a>
            <a href="profile.php" class="nav-item">
                <i class="bi bi-person"></i>
                <span>我的</span>
            </a>
        </div>
    </nav>

    <footer>
        <div class="container">
            <p>Copyright © 2025 天目官方论坛 - 分享快乐</p>
        </div>
    </footer>

    <script>
        // 移动端菜单切换
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        const searchBox = document.getElementById('searchBox');
        
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            searchBox.classList.toggle('active');
            
            // 切换图标
            const icon = this.querySelector('i');
            if (mainNav.classList.contains('active')) {
                icon.classList.remove('bi-list');
                icon.classList.add('bi-x');
            } else {
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        });
        
        // 编辑器功能
        function insertText(type, text) {
            const textarea = document.getElementById('content');
            const startPos = textarea.selectionStart;
            const endPos = textarea.selectionEnd;
            const selectedText = textarea.value.substring(startPos, endPos);
            let newText = '';
            
            switch (type) {
                case 'bold':
                    newText = selectedText ? `**${selectedText}**` : '**加粗文字**';
                    break;
                case 'italic':
                    newText = selectedText ? `*${selectedText}*` : '*斜体文字*';
                    break;
                case 'heading':
                    newText = selectedText ? `### ${selectedText}` : '### 标题';
                    break;
                case 'link':
                    newText = selectedText ? `[${selectedText}](https://)` : '[链接文字](https://)';
                    break;
                case 'image':
                    newText = selectedText ? `[img]${selectedText}[/img]` : '[img]图片链接[/img]';
                    break;
                case 'video':
                    newText = selectedText ? `[video]${selectedText}[/video]` : '[video]视频链接[/video]';
                    break;
                case 'quote':
                    newText = selectedText ? `> ${selectedText}` : '> 引用内容';
                    break;
                case 'code':
                    newText = selectedText ? `\`\`\`\n${selectedText}\n\`\`\`` : '```代码块```';
                    break;
                case 'list':
                    newText = selectedText ? `- ${selectedText}` : '- 列表项';
                    break;
                default:
                    newText = text;
            }
            
            textarea.value = textarea.value.substring(0, startPos) + newText + textarea.value.substring(endPos);
            textarea.focus();
            textarea.setSelectionRange(startPos, startPos + newText.length);
        }
        
        // 自动调整文本区域高度
        const textarea = document.getElementById('content');
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
        
        // 初始化时调整高度
        textarea.style.height = 'auto';
        textarea.style.height = (textarea.scrollHeight) + 'px';
    </script>
</body>
</html>