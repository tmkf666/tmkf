<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

$postId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$post = getPost($postId);

if (!$post) {
    header('HTTP/1.0 404 Not Found');
    exit('帖子不存在');
}

// 增加浏览量
incrementPostViews($postId);
$comments = getComments($postId);
$currentUser = getCurrentUser();
$isLiked = $currentUser && in_array($currentUser['id'], $post['likes'] ?? []);
$isFavorite = $currentUser && in_array($postId, getUserFavorites($currentUser['id']));

// 获取发帖者信息
$postAuthor = getUser($post['user_id'] ?? 0);

// 处理评论提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isLoggedIn()) {
    $content = trim($_POST['content'] ?? '');
    $parentId = isset($_POST['parent_id']) ? intval($_POST['parent_id']) : null;
    
    if (!empty($content)) {
        addComment([
            'post_id' => $postId,
            'user_id' => $currentUser['id'],
            'content' => processMentions($content),
            'parent_id' => $parentId
        ]);
        
        // 重定向以避免重复提交
        header("Location: post.php?id=$postId");
        exit;
    }
}

// 处理点赞/取消点赞
if (isset($_GET['action']) && isLoggedIn()) {
    if ($_GET['action'] == 'like') {
        likePost($postId, $currentUser['id']);
    } elseif ($_GET['action'] == 'unlike') {
        unlikePost($postId, $currentUser['id']);
    }
    header("Location: post.php?id=$postId");
    exit;
}

// 处理收藏/取消收藏
if (isset($_GET['fav_action']) && isLoggedIn()) {
    if ($_GET['fav_action'] == 'add') {
        addFavorite($currentUser['id'], $postId);
    } elseif ($_GET['fav_action'] == 'remove') {
        removeFavorite($currentUser['id'], $postId);
    }
    header("Location: post.php?id=$postId");
    exit;
}

// 处理评论点赞
if (isset($_GET['like_comment']) && isLoggedIn()) {
    $commentId = intval($_GET['like_comment']);
    likeComment($commentId, $currentUser['id']);
    header("Location: post.php?id=$postId#comment-$commentId");
    exit;
}

/**
 * 格式化帖子内容 - 处理媒体和格式
 */
function formatPostContent($content) {
    if (empty($content)) return '';
    
    // 处理视频
    $content = preg_replace_callback(
        '/\\[video\](.*?)\\[\/video\]/i',
        function($matches) {
            $url = $matches[1] ?? '';
            if (filter_var($url, FILTER_VALIDATE_URL)) {
                return '<div class="video-container"><iframe src="'.htmlspecialchars($url).'" frameborder="0" allowfullscreen></iframe></div>';
            }
            return '';
        },
        $content
    );
    
    // 处理图片
    $content = preg_replace_callback(
        '/\\[img\](.*?)\\[\/img\]/i',
        function($matches) {
            $url = $matches[1] ?? '';
            if (filter_var($url, FILTER_VALIDATE_URL)) {
                return '<img src="'.htmlspecialchars($url).'" alt="用户图片" class="user-image">';
            }
            return '';
        },
        $content
    );
    
    // 处理链接
    $content = preg_replace('/\\[url=(.*?)\](.*?)\\[\/url\]/i', '<a href="$1" target="_blank">$2</a>', $content);
    // 处理粗体
    $content = preg_replace('/\\[b\](.*?)\\[\/b\]/i', '<strong>$1</strong>', $content);
    // 处理斜体
    $content = preg_replace('/\\[i\](.*?)\\[\/i\]/i', '<em>$1</em>', $content);
    // 处理代码块
    $content = preg_replace('/\\[code\](.*?)\\[\/code\]/i', '<pre><code>$1</code></pre>', $content);
    // 处理引用
    $content = preg_replace('/\\[quote\](.*?)\\[\/quote\]/i', '<blockquote>$1</blockquote>', $content);
    // 处理换行
    $content = nl2br($content);
    
    return $content;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($post['title'] ?? '') ?> - <?= htmlspecialchars(getSettings()['site_title']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #ff85a2; /* 粉色主色调 */
            --primary-light: #ffb6c1; /* 浅粉色 */
            --primary-dark: #e75480; /* 深粉色 */
            --secondary: #9b5de5; /* 紫色 */
            --accent: #00bbf9; /* 蓝色 */
            --light: #fff9fb; /* 浅粉色背景 */
            --dark: #4a4a4a; /* 深灰色 */
            --gray: #a0a0a0; /* 灰色 */
            --success: #00f5d4; /* 青色 */
            --danger: #f72585; /* 红色 */
            --warning: #ffd166; /* 黄色 */
            --border-radius: 16px;
            --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15);
            --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        a {
            text-decoration: none;
            color: inherit;
            transition: var(--transition);
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
        }
        
        /* 头部样式 - 与首页一致 */
        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1.5rem;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .logo i {
            font-size: 1.75rem;
            color: #fff;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem;
            border-radius: 50%;
        }
        
        nav ul {
            display: flex;
            gap: 0.5rem;
            list-style: none;
        }
        
        nav ul li a {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        nav ul li a:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        
        nav ul li a i {
            font-size: 1.1rem;
        }
        
        .search-box {
            flex: 1;
            max-width: 400px;
        }
        
        .search-box form {
            display: flex;
            gap: 0.5rem;
        }
        
        .search-box input {
            flex: 1;
            padding: 0.75rem 1.25rem;
            border: none;
            border-radius: 50px;
            font-size: 0.95rem;
            background: rgba(255, 255, 255, 0.9);
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .search-box button {
            padding: 0.75rem 1.25rem;
            background-color: var(--accent);
            color: white;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 4px 10px rgba(0, 187, 249, 0.3);
        }
        
        .search-box button:hover {
            background-color: #0099cc;
            transform: translateY(-2px);
        }
        
        main {
            flex: 1;
            padding: 2rem 0;
        }
        
        /* 帖子详情区域优化 */
        .post-detail {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 2.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--box-shadow);
            border: 1px solid rgba(255, 133, 162, 0.1);
            position: relative;
            overflow: hidden;
            transition: var(--transition);
            animation: fadeInUp 0.6s ease;
        }
        
        .post-detail:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 35px rgba(0, 0, 0, 0.12);
        }
        
        .post-detail::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 50%, var(--accent) 100%);
        }
        
        .post-header {
            margin-bottom: 1.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid rgba(255, 182, 193, 0.3);
            position: relative;
        }
        
        .post-title {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: var(--dark);
            line-height: 1.3;
            position: relative;
            padding-bottom: 1rem;
        }
        
        .post-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 3px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            border-radius: 3px;
        }
        
        .post-title-highlight {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .author-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
            position: relative;
            padding: 1rem 0;
        }
        
        .author-avatar {
            width: 65px;
            height: 65px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid white;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            transition: var(--transition);
        }
        
        .author-avatar:hover {
            transform: scale(1.1);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .author-details {
            flex: 1;
        }
        
        .author-name {
            font-weight: 600;
            font-size: 1.25rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 0.25rem;
            position: relative;
            display: inline-block;
        }
        
        .author-badges {
            display: flex;
            gap: 0.5rem;
            margin-top: 0.75rem;
        }
        
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            padding: 0.35rem 0.9rem;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 500;
            color: black;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .badge.admin {
            background: linear-gradient(135deg, var(--success) 0%, #38a169 100%);
        }
        
        .badge.author {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
        }
        
        .badge.vip {
            background: linear-gradient(135deg, var(--warning) 0%, #dd6b20 100%);
        }
        
        .post-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            font-size: 0.95rem;
            color: var(--gray);
            margin-top: 1rem;
        }
        
        .post-meta span {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(155, 93, 229, 0.08);
            padding: 0.6rem 1.2rem;
            border-radius: 50px;
            transition: var(--transition);
        }
        
        .post-meta span:hover {
            background: rgba(155, 93, 229, 0.15);
            transform: translateY(-2px);
        }
        
        .post-content {
            line-height: 1.8;
            margin-bottom: 1.5rem;
            font-size: 1.15rem;
            color: #4a5568;
            position: relative;
            padding: 1.5rem 0;
        }
        
        .post-content p {
            margin-bottom: 1.5rem;
        }
        
        .post-content img.user-image {
            max-width: 100%;
            height: auto;
            border-radius: 12px;
            margin: 1.5rem 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: var(--transition);
            cursor: zoom-in;
        }
        
        .post-content img.user-image:hover {
            transform: scale(1.02);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .post-content .video-container {
            position: relative;
            padding-bottom: 56.25%;
            height: 0;
            overflow: hidden;
            border-radius: 12px;
            margin: 1.5rem 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: var(--transition);
        }
        
        .post-content .video-container:hover {
            transform: scale(1.02);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .post-content .video-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: none;
        }
        
        .post-actions {
            display: flex;
            gap: 1rem;
            border-top: 1px solid rgba(255, 182, 193, 0.3);
            padding-top: 1.5rem;
            flex-wrap: wrap;
        }
        
        /* 按钮样式优化 - 与首页一致 */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border: none;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.3);
            position: relative;
            overflow: hidden;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(155, 93, 229, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn i {
            font-size: 1.1rem;
        }
        
        .btn-like {
            background: linear-gradient(135deg, var(--success) 0%, #38a169 100%);
        }
        
        .btn-fav {
            background: linear-gradient(135deg, var(--warning) 0%, #dd6b20 100%);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, var(--danger) 0%, #c53030 100%);
        }
        
        .btn-secondary {
            background: linear-gradient(135deg, var(--secondary) 0%, #5a56b9 100%);
        }
        
        /* 评论区优化 */
        .comments-section {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 2.5rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--box-shadow);
            border: 1px solid rgba(255, 133, 162, 0.1);
            position: relative;
            overflow: hidden;
        }
        
        .comments-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--accent) 0%, var(--secondary) 50%, var(--primary) 100%);
        }
        
        .comments-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid rgba(255, 182, 193, 0.3);
        }
        
        .comments-header h3 {
            margin: 0;
            font-size: 1.75rem;
            color: var(--dark);
            font-weight: 700;
        }
        
        .comment-sort {
            display: flex;
            gap: 0.75rem;
            align-items: center;
        }
        
        .comment-sort select {
            padding: 0.6rem 1rem;
            border: 1px solid rgba(255, 182, 193, 0.3);
            border-radius: var(--border-radius);
            background-color: white;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
            font-family: inherit;
            transition: var(--transition);
        }
        
        .comment-sort select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 133, 162, 0.2);
        }
        
        .comment-form {
            margin-bottom: 1.5rem;
            padding: 1.75rem;
            background-color: #f9fafb;
            border-radius: var(--border-radius);
            box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.03);
            border: 1px solid rgba(255, 182, 193, 0.3);
        }
        
        .comment-form textarea {
            width: 100%;
            padding: 1.25rem;
            border: 1px solid rgba(255, 182, 193, 0.3);
            border-radius: var(--border-radius);
            font-family: inherit;
            font-size: 1rem;
            min-height: 120px;
            resize: vertical;
            margin-bottom: 1.25rem;
            transition: var(--transition);
            background-color: white;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .comment-form textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 133, 162, 0.2);
        }
        
        .comment-tools {
            display: flex;
            gap: 0.75rem;
            margin-bottom: 1.25rem;
            flex-wrap: wrap;
        }
        
        .tool-btn {
            background: white;
            border: 1px solid rgba(255, 182, 193, 0.3);
            border-radius: 20px;
            padding: 0.6rem 1.25rem;
            font-size: 0.9rem;
            color: var(--gray);
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            position: relative;
            overflow: hidden;
        }
        
        .tool-btn:hover {
            background-color: #f0f0f0;
            color: var(--dark);
            transform: translateY(-2px);
            border-color: var(--primary);
        }
        
        .login-to-comment {
            padding: 1.75rem;
            background-color: #f8f9fa;
            border-radius: var(--border-radius);
            text-align: center;
            margin-bottom: 1.5rem;
            box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.03);
            border: 1px solid rgba(255, 182, 193, 0.3);
        }
        
        .login-to-comment a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }
        
        .login-to-comment a:hover {
            text-decoration: underline;
        }
        
        .comments-list {
            margin-top: 1.5rem;
        }
        
        .comment-item {
            padding: 1.75rem;
            border-bottom: 1px solid rgba(255, 182, 193, 0.3);
            transition: var(--transition);
            border-radius: var(--border-radius);
            margin-bottom: 1.25rem;
            background-color: #fdfdfd;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            position: relative;
            animation: fadeInUp 0.4s ease forwards;
            opacity: 0;
        }
        
        .comment-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 3px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary), var(--secondary));
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .comment-item:hover::before {
            opacity: 1;
        }
        
        .comment-item:hover {
            background-color: #f9fafb;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.08);
            transform: translateY(-3px);
        }
        
        .comment-item:last-child {
            border-bottom: none;
        }
        
        .comment-author {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.25rem;
        }
        
        .comment-author img {
            width: 55px;
            height: 55px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid white;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            transition: var(--transition);
        }
        
        .comment-author img:hover {
            transform: rotate(5deg) scale(1.1);
        }
        
        .author-info {
            display: flex;
            flex-direction: column;
        }
        
        .author-name {
            font-weight: 600;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.1rem;
        }
        
        .comment-badges {
            display: flex;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .comment-date {
            font-size: 0.85rem;
            color: var(--gray);
            margin-top: 0.25rem;
        }
        
        .comment-content {
            margin-bottom: 1.25rem;
            line-height: 1.7;
            padding-left: 67px;
            color: #4a5568;
        }
        
        .comment-actions {
            display: flex;
            gap: 1.25rem;
            padding-left: 67px;
        }
        
        .action-btn {
            background: none;
            border: none;
            color: var(--gray);
            font-size: 0.9rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: var(--transition);
            padding: 0.5rem;
            border-radius: 4px;
            font-weight: 500;
            position: relative;
        }
        
        .action-btn::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary);
            transition: width 0.3s ease;
        }
        
        .action-btn:hover::after {
            width: 100%;
        }
        
        .action-btn:hover {
            background-color: rgba(255, 133, 162, 0.1);
            color: var(--primary);
        }
        
        .action-btn.liked {
            color: var(--success);
        }
        
        .comment-replies {
            margin-left: 67px;
            padding-left: 1.5rem;
            border-left: 2px solid var(--primary-light);
            margin-top: 1.25rem;
        }
        
        .reply-item {
            padding: 1.25rem;
            background-color: #f9f9f9;
            border-radius: var(--border-radius);
            margin-bottom: 0.75rem;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: var(--transition);
        }
        
        .reply-item:hover {
            transform: translateX(10px);
        }
        
        .reply-item:last-child {
            margin-bottom: 0;
        }
        
        .no-comments {
            padding: 2.5rem;
            text-align: center;
            color: var(--gray);
        }
        
        .no-comments i {
            font-size: 3.5rem;
            margin-bottom: 1.25rem;
            opacity: 0.5;
            color: var(--primary);
        }
        
        .no-comments p {
            font-size: 1.1rem;
        }
        
        .hot-comment-badge {
            background: linear-gradient(135deg, #FF6B6B, #FFD93D);
            color: white;
            padding: 0.35rem 0.9rem;
            border-radius: 12px;
            font-size: 0.8rem;
            margin-left: 0.5rem;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .comment-stats {
            display: flex;
            gap: 1.25rem;
            font-size: 0.85rem;
            color: var(--gray);
            margin-top: 0.75rem;
        }
        
        /* 底部导航栏优化 - 与首页一致 */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(155, 93, 229, 0.15);
            padding: 0.75rem 0;
            display: none;
            z-index: 1000;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.05);
            transition: var(--transition);
        }
        
        .nav-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
            padding: 0.5rem;
            border-radius: 50px;
            transition: var(--transition);
            color: var(--gray);
            text-decoration: none;
        }
        
        .nav-item.active {
            color: var(--primary);
        }
        
        .nav-item i {
            font-size: 1.35rem;
            background: rgba(255, 133, 162, 0.1);
            width: 2.75rem;
            height: 2.75rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .nav-item:hover i {
            transform: translateY(-5px);
        }
        
        .nav-item.active i {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 12px rgba(255, 133, 162, 0.3);
        }
        
        .nav-item span {
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        /* 动画效果优化 */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes pulse {
            0% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
            100% {
                transform: scale(1);
            }
        }
        
        @keyframes float {
            0% {
                transform: translateY(0px);
            }
            50% {
                transform: translateY(-5px);
            }
            100% {
                transform: translateY(0px);
            }
        }
        
        .floating {
            animation: float 3s ease-in-out infinite;
        }
        
        .pulse {
            animation: pulse 0.6s ease;
        }
        
        /* 延迟加载评论动画 */
        .comment-item:nth-child(1) { animation-delay: 0.1s; }
        .comment-item:nth-child(2) { animation-delay: 0.2s; }
        .comment-item:nth-child(3) { animation-delay: 0.3s; }
        .comment-item:nth-child(4) { animation-delay: 0.4s; }
        .comment-item:nth-child(5) { animation-delay: 0.5s; }
        
        /* 响应式设计优化 */
        @media (max-width: 768px) {
            .container {
                padding: 0 1rem;
            }
            
            .header-content {
                flex-direction: row;
                align-items: center;
                flex-wrap: wrap;
            }
            
            .logo {
                order: 1;
                flex: 1;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            .mobile-menu-btn {
                display: block;
                order: 2;
            }
            
            nav {
                order: 4;
                width: 100%;
                display: none;
                margin-top: 1rem;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .search-box {
                order: 3;
                width: 100%;
                margin-top: 1rem;
                display: none;
            }
            
            .search-box.active {
                display: block;
            }
            
            .post-detail,
            .comments-section {
                padding: 1.5rem;
            }
            
            .post-title {
                font-size: 1.75rem;
            }
            
            .post-meta {
                gap: 0.5rem;
            }
            
            .post-meta span {
                font-size: 0.85rem;
                padding: 0.5rem 1rem;
            }
            
            .comment-content {
                padding-left: 0;
            }
            
            .comment-actions {
                padding-left: 0;
            }
            
            .comment-replies {
                margin-left: 1rem;
            }
            
            .comments-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.75rem;
            }
            
            .comment-sort {
                width: 100%;
                justify-content: flex-end;
            }
            
            /* 显示底部导航 */
            .bottom-nav {
                display: block;
            }
            
            /* 为移动端留出底部空间 */
            main {
                margin-bottom: 4.5rem;
            }
            
            /* 移动端优化 */
            .post-title {
                font-size: 1.8rem;
            }
            
            .author-info {
                flex-direction: column;
                text-align: center;
            }
            
            .author-details {
                margin-top: 1rem;
                text-align: center;
            }
            
            .post-meta {
                justify-content: center;
            }
            
            .post-actions {
                justify-content: center;
            }
            
            .btn {
                width: 100%;
                margin-bottom: 1rem;
            }
        }
        
        @media (max-width: 480px) {
            .post-actions {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .btn {
                width: 100%;
                margin-bottom: 0.75rem;
            }
            
            .post-title {
                font-size: 1.5rem;
            }
            
            .author-info {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .comment-form {
                padding: 1.25rem;
            }
            
            .comment-tools {
                gap: 0.5rem;
            }
            
            .tool-btn {
                padding: 0.5rem 1rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <a href="index.php" class="logo">
                    <i class="bi bi-chat-square-heart"></i>
                    <span><?= htmlspecialchars(getSettings()['site_title']) ?></span>
                </a>
                
                <nav id="mainNav">
                    <ul>
                        <li><a href="index.php"><i class="bi bi-house"></i> 首页</a></li>
                        <?php foreach (getCategories() as $category): ?>
                            <li><a href="index.php?category=<?= $category['id'] ?>"><i class="bi bi-collection"></i> <?= htmlspecialchars($category['name']) ?></a></li>
                        <?php endforeach; ?>
                        <?php if (isLoggedIn()): ?>
                            <li><a href="create_post.php"><i class="bi bi-plus-circle"></i> 发帖</a></li>
                            <li><a href="profile.php"><i class="bi bi-person"></i> 个人中心</a></li>
                            <?php if ($currentUser['is_admin'] ?? false): ?>
                                <li><a href="admin/"><i class="bi bi-gear"></i> 管理</a></li>
                            <?php endif; ?>
                            <li><a href="logout.php"><i class="bi bi-box-arrow-right"></i> 退出</a></li>
                        <?php else: ?>
                            <li><a href="login.php"><i class="bi bi-box-arrow-in-right"></i> 登录</a></li>
                            <li><a href="register.php"><i class="bi bi-person-plus"></i> 注册</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                
                <div class="search-box" id="searchBox">
                    <form action="search.php" method="get">
                        <input type="text" name="q" placeholder="搜索帖子..." value="<?= isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '' ?>">
                        <button type="submit"><i class="bi bi-search"></i> 搜索</button>
                    </form>
                </div>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="post-detail">
            <div class="post-header">
                <h1 class="post-title"><?= htmlspecialchars($post['title'] ?? '') ?></h1>
                
                <div class="author-info">
                    <img src="images/<?= $postAuthor['avatar'] ?? 'default.png' ?>" alt="<?= $postAuthor['username'] ?? '' ?>" class="author-avatar">
                    <div class="author-details">
                        <div class="author-name">
                            <?= htmlspecialchars($postAuthor['username'] ?? '') ?>
                            <?php if ($postAuthor['is_admin'] ?? false): ?>
                                <span class="badge admin"><i class="bi bi-shield-check"></i> 管理员</span>
                            <?php endif; ?>
                            <?php if (($postAuthor['id'] ?? 0) == ($post['user_id'] ?? 0)): ?>
                                <span class="badge author"><i class="bi bi-pen"></i> 作者</span>
                            <?php endif; ?>
                        </div>
                        <div class="author-badges">
                            <?php foreach (getUserBadges($postAuthor['id'] ?? 0) as $badge): ?>
                                <span class="badge"><?= htmlspecialchars($badge['name'] ?? '') ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                
                <div class="post-meta">
                    <span><i class="bi bi-tag"></i> <?= htmlspecialchars(getCategory($post['category_id'] ?? 0)['name'] ?? '') ?></span>
                    <span><i class="bi bi-clock"></i> <?= $post['created_at'] ?? '' ?></span>
                    <span><i class="bi bi-eye"></i> <?= $post['views'] ?? 0 ?> 浏览</span>
                    <span><i class="bi bi-heart"></i> <?= count($post['likes'] ?? []) ?> 点赞</span>
                    <span><i class="bi bi-chat-left"></i> <?= count($comments ?? []) ?> 评论</span>
                </div>
            </div>
            
            <div class="post-content">
                <?= formatPostContent($post['content'] ?? '') ?>
            </div>
            
            <div class="post-actions">
                <?php if (isLoggedIn()): ?>
                    <?php if ($isLiked): ?>
                        <a href="post.php?id=<?= $postId ?>&action=unlike" class="btn btn-like"><i class="bi bi-heart-fill"></i> 已点赞</a>
                    <?php else: ?>
                        <a href="post.php?id=<?= $postId ?>&action=like" class="btn"><i class="bi bi-heart"></i> 点赞</a>
                    <?php endif; ?>
                    
                    <?php if ($isFavorite): ?>
                        <a href="post.php?id=<?= $postId ?>&fav_action=remove" class="btn btn-fav"><i class="bi bi-bookmark-fill"></i> 已收藏</a>
                    <?php else: ?>
                        <a href="post.php?id=<?= $postId ?>&fav_action=add" class="btn"><i class="bi bi-bookmark"></i> 收藏</a>
                    <?php endif; ?>
                    
                    <a href="#" class="btn btn-secondary"><i class="bi bi-share"></i> 分享</a>
                    
                    <?php if (($currentUser['id'] ?? 0) == ($post['user_id'] ?? 0) || ($currentUser['is_admin'] ?? false)): ?>
                        <a href="edit_post.php?id=<?= $postId ?>" class="btn"><i class="bi bi-pencil"></i> 编辑</a>
                        <a href="delete_post.php?id=<?= $postId ?>" class="btn btn-danger" onclick="return confirm('确定要删除这篇帖子吗？')"><i class="bi bi-trash"></i> 删除</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="comments-section">
            <div class="comments-header">
                <h3><i class="bi bi-chat-left-text"></i> 评论 (<?= count($comments ?? []) ?>)</h3>
                <div class="comment-sort">
                    <span>排序方式：</span>
                    <select id="comment-sort">
                        <option value="newest">最新优先</option>
                        <option value="oldest">最早优先</option>
                        <option value="hottest">最热优先</option>
                    </select>
                </div>
            </div>
            
            <?php if (isLoggedIn()): ?>
                <form action="post.php?id=<?= $postId ?>" method="post" class="comment-form" id="comment-form">
                    <div class="comment-tools">
                        <button type="button" class="tool-btn" onclick="insertEmoji('😊')"><i class="bi bi-emoji-smile"></i> 表情</button>
                        <button type="button" class="tool-btn" onclick="insertEmoji('👍')"><i class="bi bi-hand-thumbs-up"></i> 点赞</button>
                        <button type="button" class="tool-btn" onclick="insertEmoji('❤️')"><i class="bi bi-heart"></i> 爱心</button>
                        <button type="button" class="tool-btn" onclick="insertEmoji('😂')"><i class="bi bi-emoji-laughing"></i> 大笑</button>
                    </div>
                    <textarea name="content" placeholder="分享你的想法...（支持@用户功能）" required id="comment-textarea"></textarea>
                    <input type="hidden" name="parent_id" id="parent_id">
                    <button type="submit" class="btn"><i class="bi bi-send"></i> 发布评论</button>
                </form>
            <?php else: ?>
                <p class="login-to-comment">请<a href="login.php">登录</a>后发表评论，加入讨论</p>
            <?php endif; ?>
            
            <div class="comments-list">
                <?php if (!empty($comments)): ?>
                    <?php foreach ($comments as $comment): ?>
                        <?php $commentAuthor = getUser($comment['user_id'] ?? 0); ?>
                        <div class="comment-item" id="comment-<?= $comment['id'] ?? '' ?>">
                            <div class="comment-author">
                                <img src="images/<?= $commentAuthor['avatar'] ?? 'default.png' ?>" alt="<?= $commentAuthor['username'] ?? '' ?>">
                                <div class="author-info">
                                    <div class="author-name">
                                        <?= htmlspecialchars($commentAuthor['username'] ?? '') ?>
                                        <?php if (($commentAuthor['id'] ?? 0) == ($postAuthor['id'] ?? 0)): ?>
                                            <span class="badge author"><i class="bi bi-pen"></i> 作者</span>
                                        <?php endif; ?>
                                        <?php if ($comment['is_hot'] ?? false): ?>
                                            <span class="hot-comment-badge"><i class="bi bi-fire"></i> 热门评论</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="comment-badges">
                                        <?php foreach (getUserBadges($commentAuthor['id'] ?? 0) as $badge): ?>
                                            <span class="badge"><?= htmlspecialchars($badge['name'] ?? '') ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                    <span class="comment-date"><i class="bi bi-clock"></i> <?= $comment['created_at'] ?? '' ?></span>
                                </div>
                            </div>
                            
                            <div class="comment-content">
                                <?= formatPostContent($comment['content'] ?? '') ?>
                            </div>
                            
                            <div class="comment-actions">
                                <button class="action-btn like-btn" data-comment-id="<?= $comment['id'] ?? '' ?>" onclick="likeComment(<?= $comment['id'] ?? '' ?>)">
                                    <i class="bi bi-hand-thumbs-up"></i> 点赞 (<span class="like-count"><?= count($comment['likes'] ?? []) ?></span>)
                                </button>
                                <?php if (isLoggedIn()): ?>
                                    <button class="action-btn reply-btn" onclick="setReply(<?= $comment['id'] ?? '' ?>, '<?= $commentAuthor['username'] ?? '' ?>')">
                                        <i class="bi bi-reply"></i> 回复
                                    </button>
                                <?php endif; ?>
                                <button class="action-btn">
                                    <i class="bi bi-flag"></i> 举报
                                </button>
                            </div>
                            
                            <?php if (!empty($comment['replies'])): ?>
                                <div class="comment-replies">
                                    <?php foreach ($comment['replies'] as $replyId): ?>
                                        <?php $reply = array_filter($comments, function($c) use ($replyId) { return ($c['id'] ?? 0) == $replyId; }); ?>
                                        <?php $reply = reset($reply); ?>
                                        <?php if ($reply): ?>
                                            <?php $replyAuthor = getUser($reply['user_id'] ?? 0); ?>
                                            <div class="reply-item" id="comment-<?= $reply['id'] ?? '' ?>">
                                                <div class="comment-author">
                                                    <img src="images/<?= $replyAuthor['avatar'] ?? 'default.png' ?>" alt="<?= $replyAuthor['username'] ?? '' ?>">
                                                    <div class="author-info">
                                                        <div class="author-name">
                                                            <?= htmlspecialchars($replyAuthor['username'] ?? '') ?>
                                                            <?php if (($replyAuthor['id'] ?? 0) == ($postAuthor['id'] ?? 0)): ?>
                                                                <span class="badge author"><i class="bi bi-pen"></i> 作者</span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="comment-badges">
                                                            <?php foreach (getUserBadges($replyAuthor['id'] ?? 0) as $badge): ?>
                                                                <span class="badge"><?= htmlspecialchars($badge['name'] ?? '') ?></span>
                                                            <?php endforeach; ?>
                                                        </div>
                                                        <span class="comment-date"><i class="bi bi-clock"></i> <?= $reply['created_at'] ?? '' ?></span>
                                                    </div>
                                                </div>
                                                
                                                <div class="comment-content">
                                                    <?= formatPostContent($reply['content'] ?? '') ?>
                                                </div>
                                                
                                                <div class="comment-actions">
                                                    <button class="action-btn like-btn" data-comment-id="<?= $reply['id'] ?? '' ?>" onclick="likeComment(<?= $reply['id'] ?? '' ?>)">
                                                        <i class="bi bi-hand-thumbs-up"></i> 点赞 (<span class="like-count"><?= count($reply['likes'] ?? []) ?></span>)
                                                    </button>
                                                    <?php if (isLoggedIn()): ?>
                                                        <button class="action-btn reply-btn" onclick="setReply(<?= $comment['id'] ?? '' ?>, '<?= $replyAuthor['username'] ?? '' ?>')">
                                                            <i class="bi bi-reply"></i> 回复
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="no-comments">
                        <i class="bi bi-chat-square"></i>
                        <p>暂无评论，快来发表第一条评论吧！</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>Copyright © <?= date('Y') ?> <?= htmlspecialchars(getSettings()['site_title']) ?> - 分享快乐</p>
        </div>
    </footer>

    <!-- 底部导航栏 -->
    <nav class="bottom-nav">
        <div class="nav-items">
            <a href="index.php" class="nav-item active">
                <i class="bi bi-house"></i>
                <span>主页</span>
            </a>
            <a href="categories.php" class="nav-item">
                <i class="bi bi-compass"></i>
                <span>发现</span>
            </a>
            <a href="create_post.php" class="nav-item">
                <i class="bi bi-plus-circle"></i>
                <span>添加</span>
            </a>
            <a href="messages.php" class="nav-item">
                <i class="bi bi-chat"></i>
                <span>消息</span>
            </a>
            <a href="profile.php" class="nav-item">
                <i class="bi bi-person"></i>
                <span>我的</span>
            </a>
        </div>
    </nav>

    <script>
        // 移动端菜单切换
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        const searchBox = document.getElementById('searchBox');
        
        if (mobileMenuBtn) {
            mobileMenuBtn.addEventListener('click', function() {
                mainNav.classList.toggle('active');
                searchBox.classList.toggle('active');
                // 切换图标
                const icon = this.querySelector('i');
                if (mainNav.classList.contains('active')) {
                    icon.classList.remove('bi-list');
                    icon.classList.add('bi-x');
                } else {
                    icon.classList.remove('bi-x');
                    icon.classList.add('bi-list');
                }
            });
        }
        
        // 设置回复功能
        function setReply(parentId, username) {
            const textarea = document.getElementById('comment-textarea');
            const mentionText = `@${username} `;
            
            // 如果已经@了，就不再添加
            if (!textarea.value.includes(mentionText)) {
                textarea.value = mentionText + textarea.value;
            }
            
            textarea.focus();
            document.getElementById('parent_id').value = parentId;
            
            // 平滑滚动到评论框
            const commentForm = document.getElementById('comment-form');
            commentForm.style.animation = 'pulse 0.6s ease';
            setTimeout(() => {
                commentForm.style.animation = '';
            }, 600);
            
            window.scrollTo({
                top: commentForm.offsetTop - 100,
                behavior: 'smooth'
            });
        }
        
        // 插入表情
        function insertEmoji(emoji) {
            const textarea = document.getElementById('comment-textarea');
            textarea.value += emoji;
            textarea.focus();
        }
        
        // 点赞评论
        function likeComment(commentId) {
            // 这里应该发送AJAX请求到服务器
            const likeBtn = document.querySelector(`.like-btn[data-comment-id="${commentId}"]`);
            const likeCount = likeBtn.querySelector('.like-count');
            
            if (!likeBtn.classList.contains('liked')) {
                likeBtn.classList.add('liked');
                likeBtn.innerHTML = `<i class="bi bi-hand-thumbs-up-fill"></i> 已点赞 (<span class="like-count">${parseInt(likeCount.textContent) + 1}</span>)`;
            } else {
                likeBtn.classList.remove('liked');
                likeBtn.innerHTML = `<i class="bi bi-hand-thumbs-up"></i> 点赞 (<span class="like-count">${parseInt(likeCount.textContent) - 1}</span>)`;
            }
        }
        
        // 页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            document.body.style.opacity = '0';
            setTimeout(() => {
                document.body.style.transition = 'opacity 0.3s ease';
                document.body.style.opacity = '1';
            }, 100);
            
            // 为卡片添加延迟动画
            const cards = document.querySelectorAll('.comment-item');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 100 + index * 100);
            });
        });
        
        // 响应式调整
        function handleResponsive() {
            if (window.innerWidth > 768) {
                mainNav.classList.remove('active');
                searchBox.classList.remove('active');
                const icon = mobileMenuBtn.querySelector('i');
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        }
        
        window.addEventListener('resize', handleResponsive);
        handleResponsive();
        
        // 底部导航激活状态切换
        document.querySelectorAll('.bottom-nav .nav-item').forEach(item => {
            item.addEventListener('click', function() {
                document.querySelectorAll('.bottom-nav .nav-item').forEach(i => {
                    i.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
    </script>
</body>
</html>