<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

// 检查用户是否登录
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$currentUser = getCurrentUser();
$username = isset($_GET['username']) ? $_GET['username'] : $currentUser['username'];
$user = getUserByUsername($username);

if (!$user) {
    header('HTTP/1.0 404 Not Found');
    exit('用户不存在');
}

$isCurrentUser = $user['id'] == $currentUser['id'];
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;

$postsData = getUserPosts($user['id'], $page, $perPage);
$posts = $postsData['posts'];
$totalPages = $postsData['pages'];
$currentPage = $postsData['current_page'];

$error = '';
$success = '';

// 处理头像上传
if ($isCurrentUser && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    $result = uploadAvatar($_FILES['avatar'], $user['id']);
    
    if ($result['success']) {
        $success = '头像上传成功';
        $user['avatar'] = $result['filename'];
        
        // 更新当前用户信息
        $currentUser['avatar'] = $result['filename'];
        $_SESSION['user'] = $currentUser;
    } else {
        $error = $result['message'];
    }
}

// 处理个人信息更新
if ($isCurrentUser && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $bio = trim($_POST['bio']); // 获取个人简介
    
    // 验证用户名
    if (empty($username)) {
        $error = '用户名不能为空';
    } elseif (strlen($username) < 3 || strlen($username) > 20) {
        $error = '用户名长度必须在3-20个字符之间';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $error = '用户名只能包含字母、数字和下划线';
    } else {
        // 检查用户名是否已被使用（除了当前用户）
        $existingUser = getUserByUsername($username);
        if ($existingUser && $existingUser['id'] != $user['id']) {
            $error = '用户名已被使用';
        }
    }
    
    // 验证个人简介长度
    if (strlen($bio) > 500) {
        $error = '个人简介不能超过500个字符';
    }
    
    if (empty($error)) {
        if (!empty($password) && $password !== $confirm_password) {
            $error = '两次输入的密码不一致';
        } else {
            $data = [
                'username' => $username,
                'email' => $email,
                'bio' => $bio // 添加个人简介
            ];
            if (!empty($password)) {
                $data['password'] = $password;
            }
            
            updateUser($user['id'], $data);
            $success = '个人信息已更新';
            
            // 更新当前用户信息
            if ($user['id'] == $currentUser['id']) {
                $_SESSION['user_id'] = $user['id'];
                $currentUser = getUser($user['id']);
                $user = $currentUser; // 更新当前页面的用户信息
            }
            
            // 如果用户名被修改，重定向到新的个人主页
            if ($user['username'] !== $username) {
                header('Location: profile.php?username=' . urlencode($username));
                exit;
            }
        }
    }
}

// 处理头衔申请提交
if ($isCurrentUser && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply_badge'])) {
    $badgeName = trim($_POST['badge_name']);
    $reason = trim($_POST['reason']);
    
    if (empty($badgeName)) {
        $error = '头衔名称不能为空';
    } elseif (strlen($badgeName) > 20) {
        $error = '头衔名称不能超过20个字符';
    } elseif (empty($reason)) {
        $error = '申请理由不能为空';
    } else {
        $result = applyForBadge($currentUser['id'], $badgeName, $reason);
        
        if (isset($result['error'])) {
            $error = $result['error'];
        } else {
            $success = '头衔申请已提交，等待管理员审核';
        }
    }
}

// 获取用户头衔和申请记录
$userBadges = getUserBadges($user['id']);
$badgeApplications = $isCurrentUser ? getUserBadgeApplications($user['id']) : [];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $user['username'] ?>的个人资料 - <?= htmlspecialchars(getSettings()['site_title']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #ff85a2; /* 粉色主色调 */
            --primary-light: #ffb6c1; /* 浅粉色 */
            --primary-dark: #e75480; /* 深粉色 */
            --secondary: #9b5de5; /* 紫色 */
            --accent: #00bbf9; /* 蓝色 */
            --light: #fff9fb; /* 浅粉色背景 */
            --dark: #4a4a4a; /* 深灰色 */
            --gray: #a0a0a0; /* 灰色 */
            --success: #00f5d4; /* 青色 */
            --danger: #f72585; /* 红色 */
            --warning: #ffd166; /* 黄色 */
            --border-radius: 16px; /* 更大的圆角 */
            --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15); /* 柔和阴影 */
            --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94); /* 平滑过渡 */
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .container {
            width: 100%;
            max-width: 1100px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        
        /* 头部样式 - 动漫风格 */
        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1.5rem;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .logo i {
            font-size: 1.75rem;
            color: #fff;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem;
            border-radius: 50%;
        }
        
        nav ul {
            display: flex;
            gap: 0.5rem;
            list-style: none;
        }
        
        nav ul li a {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        nav ul li a:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        
        nav ul li a i {
            font-size: 1.1rem;
        }
        
        .search-box {
            flex: 1;
            max-width: 400px;
        }
        
        .search-box form {
            display: flex;
            gap: 0.5rem;
        }
        
        .search-box input {
            flex: 1;
            padding: 0.75rem 1.25rem;
            border: none;
            border-radius: 50px;
            font-size: 0.95rem;
            background: rgba(255, 255, 255, 0.9);
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .search-box button {
            padding: 0.75rem 1.25rem;
            background-color: var(--accent);
            color: white;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 4px 10px rgba(0, 187, 249, 0.3);
        }
        
        .search-box button:hover {
            background-color: #0099cc;
            transform: translateY(-2px);
        }
        
        main {
            flex: 1;
            padding: 1.5rem 0;
        }
        
        /* 个人资料卡片 - 动漫风格 */
        .profile-card {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            border: 1px solid rgba(255, 133, 162, 0.1);
            position: relative;
        }
        
        .profile-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 50%, var(--accent) 100%);
        }
        
        .profile-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 2rem;
            display: flex;
            align-items: center;
            gap: 2rem;
        }
        
        .profile-avatar {
            position: relative;
        }
        
        .profile-avatar img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid rgba(255, 255, 255, 0.5);
            box-shadow: var(--box-shadow);
            transition: var(--transition);
        }
        
        .profile-avatar:hover img {
            transform: scale(1.05);
            border-color: rgba(255, 255, 255, 0.8);
        }
        
        .avatar-upload {
            position: absolute;
            bottom: 0;
            right: 0;
            background: white;
            border-radius: var(--border-radius);
            padding: 0.5rem;
            box-shadow: var(--box-shadow);
        }
        
        .avatar-upload input[type="file"] {
            display: none;
        }
        
        .avatar-upload label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border-radius: 50px;
            cursor: pointer;
            font-size: 0.8rem;
            transition: var(--transition);
            box-shadow: 0 4px 10px rgba(155, 93, 229, 0.3);
        }
        
        .avatar-upload label:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.4);
        }
        
        .profile-info {
            flex: 1;
        }
        
        .profile-info h2 {
            margin: 0 0 0.5rem;
            font-size: 2rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .profile-info p {
            margin: 0 0 1rem;
            opacity: 0.9;
            font-size: 1.1rem;
        }
        
        .profile-badges {
            display: flex;
            gap: 0.75rem;
        }
        
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.85rem;
            font-weight: 500;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .badge.admin {
            background: linear-gradient(135deg, var(--success) 0%, #00cc99 100%);
            color: white;
        }
        
        .badge.banned {
            background: linear-gradient(135deg, var(--danger) 0%, #e01a4f 100%);
            color: white;
        }
        
        /* 新增：个人简介区域 */
        .profile-bio {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin: 1.5rem 2rem 0;
            border: 1px solid rgba(255, 133, 162, 0.1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        
        .profile-bio h4 {
            margin-bottom: 1rem;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.25rem;
        }
        
        .profile-bio-content {
            line-height: 1.7;
            color: var(--dark);
            min-height: 100px;
            white-space: pre-wrap;
        }
        
        .profile-bio-content.empty {
            color: var(--gray);
            font-style: italic;
        }
        
        .profile-content {
            padding: 2rem;
        }
        
        .profile-tabs {
            display: flex;
            border-bottom: 2px solid #f0f0f0;
            margin-bottom: 1.5rem;
        }
        
        .profile-tabs a {
            padding: 1rem 1.5rem;
            text-decoration: none;
            color: var(--gray);
            border-bottom: 3px solid transparent;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-weight: 500;
        }
        
        .profile-tabs a.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
            background: rgba(255, 133, 162, 0.05);
            border-radius: var(--border-radius) var(--border-radius) 0 0;
        }
        
        .profile-tabs a:hover:not(.active) {
            color: var(--dark);
            background: rgba(255, 133, 162, 0.02);
        }
        
        .profile-posts {
            margin-bottom: 2rem;
        }
        
        .post-card {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 1rem;
            transition: var(--transition);
            cursor: pointer;
            border: 1px solid rgba(255, 133, 162, 0.1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: relative;
        }
        
        .post-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary) 0%, var(--secondary) 100%);
            border-radius: var(--border-radius) 0 0 var(--border-radius);
        }
        
        .post-card:hover {
            border-color: rgba(255, 133, 162, 0.3);
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(255, 133, 162, 0.15);
        }
        
        .post-title {
            margin: 0 0 0.75rem;
            font-size: 1.25rem;
        }
        
        .post-title a {
            color: var(--dark);
            text-decoration: none;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .post-title a:hover {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .post-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 1.5rem;
            font-size: 0.9rem;
            color: var(--gray);
        }
        
        .post-meta span {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .no-posts {
            background-color: white;
            padding: 3rem;
            text-align: center;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            border: 1px solid rgba(255, 133, 162, 0.1);
        }
        
        .no-posts i {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }
        
        .no-posts p {
            color: var(--gray);
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }
        
        .pagination a {
            padding: 0.75rem 1.25rem;
            background-color: white;
            border: 1px solid #e0e0e0;
            border-radius: var(--border-radius);
            color: var(--primary);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .pagination a.active {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border-color: transparent;
        }
        
        .pagination a:hover:not(.active) {
            background-color: #f8f9fa;
            transform: translateY(-2px);
        }
        
        .profile-settings {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-top: 2rem;
            border: 1px solid rgba(255, 133, 162, 0.1);
            box-shadow: var(--box-shadow);
        }
        
        .profile-settings h3 {
            margin: 0 0 1.5rem;
            font-size: 1.5rem;
            color: var(--dark);
            border-bottom: 2px solid var(--primary);
            padding-bottom: 0.75rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        /* 头衔系统样式 */
        .badge-system {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-top: 2rem;
            border: 1px solid rgba(255, 133, 162, 0.1);
            box-shadow: var(--box-shadow);
        }
        
        .badge-system h3 {
            margin: 0 0 1.5rem;
            font-size: 1.5rem;
            color: var(--dark);
            border-bottom: 2px solid var(--primary);
            padding-bottom: 0.75rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .badge-list {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }
        
        .badge-list .badge {
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.9rem;
            font-weight: 500;
            color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
        }
        
        .badge-application {
            margin-top: 2rem;
        }
        
        .badge-application h4 {
            margin-bottom: 1.5rem;
            font-size: 1.25rem;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .application-history {
            margin-top: 2rem;
        }
        
        .application-card {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: var(--border-radius);
            padding: 1.25rem;
            margin-bottom: 1rem;
            border-left: 4px solid;
        }
        
        .application-card.pending {
            border-left-color: var(--warning);
        }
        
        .application-card.approved {
            border-left-color: var(--success);
        }
        
        .application-card.rejected {
            border-left-color: var(--danger);
        }
        
        .application-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.75rem;
        }
        
        .badge-name {
            font-weight: 600;
            color: var(--dark);
        }
        
        .application-status {
            padding: 0.25rem 0.75rem;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        .application-status.pending {
            background-color: rgba(255, 209, 102, 0.2);
            color: #b78100;
        }
        
        .application-status.approved {
            background-color: rgba(0, 245, 212, 0.2);
            color: #00a38b;
        }
        
        .application-status.rejected {
            background-color: rgba(247, 37, 133, 0.2);
            color: #c2185b;
        }
        
        .application-reason {
            margin-bottom: 0.75rem;
            color: var(--dark);
        }
        
        .application-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            font-size: 0.85rem;
            color: var(--gray);
        }
        
        .application-meta span {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .no-applications {
            text-align: center;
            padding: 2rem;
            color: var(--gray);
        }
        
        .alert {
            padding: 1.25rem;
            margin-bottom: 1.5rem;
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            border-left: 4px solid;
        }
        
        .alert.error {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--danger);
            border-left-color: var(--danger);
        }
        
        .alert.success {
            background-color: rgba(0, 245, 212, 0.1);
            color: var(--success);
            border-left-color: var(--success);
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.75rem;
            font-weight: 600;
            color: var(--dark);
        }
        
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 1rem 1.25rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-family: inherit;
            font-size: 1rem;
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.8);
        }
        
        .form-group textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        .form-group input:focus, .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 133, 162, 0.2);
            background: white;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 1rem 2rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border: none;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            gap: 0.5rem;
            font-size: 1rem;
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.3);
            position: relative;
            overflow: hidden;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(155, 93, 229, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .username-change-notice {
            background-color: rgba(255, 215, 0, 0.1);
            border-left: 4px solid #ffd700;
            padding: 0.75rem 1rem;
            border-radius: 0 var(--border-radius) var(--border-radius) 0;
            margin-top: 0.5rem;
            font-size: 0.9rem;
            color: #b8860b;
        }
        
        .bio-counter {
            text-align: right;
            font-size: 0.9rem;
            color: var(--gray);
            margin-top: 0.5rem;
        }
        
        .bio-counter.warning {
            color: var(--danger);
        }
        
        footer {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            text-align: center;
            padding: 2rem 0;
            margin-top: 3rem;
            border-top: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        footer p {
            opacity: 0.9;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        }
        
        /* 底部导航栏 - 移动端 */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 133, 162, 0.2);
            padding: 0.75rem 0;
            display: none;
            z-index: 1000;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .nav-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
            padding: 0.5rem;
            border-radius: 50px;
            transition: var(--transition);
            color: var(--gray);
        }
        
        .nav-item.active {
            color: var(--primary);
        }
        
        .nav-item i {
            font-size: 1.25rem;
            background: rgba(255, 133, 162, 0.1);
            width: 2.5rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .nav-item.active i {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 10px rgba(255, 133, 162, 0.3);
        }
        
        .nav-item span {
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        /* 移动端菜单按钮 */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        /* 响应式设计 */
        @media (max-width: 992px) {
            .profile-header {
                flex-direction: column;
                text-align: center;
                gap: 1.5rem;
            }
            
            .profile-badges {
                justify-content: center;
            }
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: row;
                align-items: center;
                flex-wrap: wrap;
            }
            
            .logo {
                order: 1;
                flex: 1;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            .mobile-menu-btn {
                display: block;
                order: 2;
            }
            
            nav {
                order: 4;
                width: 100%;
                display: none;
                margin-top: 1rem;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .search-box {
                order: 3;
                width: 100%;
                margin-top: 1rem;
                display: none;
            }
            
            .search-box.active {
                display: block;
            }
            
            .profile-tabs {
                overflow-x: auto;
                white-space: nowrap;
                padding-bottom: 0.5rem;
            }
            
            .profile-info h2 {
                font-size: 1.5rem;
            }
            
            .post-meta {
                gap: 0.5rem;
            }
            
            .profile-content {
                padding: 1.5rem;
                margin-bottom: 4rem; /* 为底部导航留出空间 */
            }
            
            /* 显示底部导航 */
            .bottom-nav {
                display: block;
            }
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 0 1rem;
            }
            
            .profile-header {
                padding: 1.5rem;
            }
            
            .profile-avatar img {
                width: 100px;
                height: 100px;
            }
            
            .profile-content {
                padding: 1rem;
            }
            
            .profile-settings {
                padding: 1.5rem;
            }
            
            .post-card {
                padding: 1.25rem;
            }
            
            .post-title {
                font-size: 1.1rem;
            }
            
            .profile-bio {
                margin: 1rem;
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <a href="index.php" class="logo">
                    <i class="bi bi-chat-square-heart"></i>
                    <span><?= htmlspecialchars(getSettings()['site_title']) ?></span>
                </a>
                
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="bi bi-list"></i>
                </button>
                
                <nav id="mainNav">
                    <ul>
                        <li><a href="index.php"><i class="bi bi-house"></i> 首页</a></li>
                        <?php foreach (getCategories() as $category): ?>
                            <li><a href="index.php?category=<?= $category['id'] ?>"><i class="bi bi-collection"></i> <?= htmlspecialchars($category['name']) ?></a></li>
                        <?php endforeach; ?>
                        <?php if (isLoggedIn()): ?>
                            <li><a href="create_post.php"><i class="bi bi-plus-circle"></i> 发帖</a></li>
                            <li><a href="profile.php" class="active"><i class="bi bi-person"></i> 个人中心</a></li>
                            <?php if ($currentUser['is_admin']): ?>
                                <li><a href="admin/"><i class="bi bi-gear"></i> 管理</a></li>
                            <?php endif; ?>
                            <li><a href="logout.php"><i class="bi bi-box-arrow-right"></i> 退出</a></li>
                        <?php else: ?>
                            <li><a href="login.php"><i class="bi bi-box-arrow-in-right"></i> 登录</a></li>
                            <li><a href="register.php"><i class="bi bi-person-plus"></i> 注册</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                
                <div class="search-box" id="searchBox">
                    <form action="search.php" method="get">
                        <input type="text" name="q" placeholder="搜索帖子..." value="<?= isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '' ?>">
                        <button type="submit"><i class="bi bi-search"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="profile-card">
            <div class="profile-header">
                <div class="profile-avatar">
                    <img src="images/<?= $user['avatar'] ?>" alt="<?= $user['username'] ?>">
                    
                    <?php if ($isCurrentUser): ?>
                        <form action="profile.php?username=<?= $user['username'] ?>" method="post" enctype="multipart/form-data" class="avatar-upload">
                            <input type="file" name="avatar" id="avatar" accept="image/*">
                            <label for="avatar"><i class="bi bi-camera"></i> 更换头像</label>
                            <button type="submit" style="display:none">上传</button>
                        </form>
                    <?php endif; ?>
                </div>
                
                <div class="profile-info">
                    <h2><?= htmlspecialchars($user['username']) ?></h2>
                    <p><i class="bi bi-calendar"></i> 注册时间: <?= $user['created_at'] ?></p>
                    
                    <div class="profile-badges">
                        <?php if ($user['is_admin']): ?>
                            <span class="badge admin"><i class="bi bi-shield-check"></i> 管理员</span>
                        <?php endif; ?>
                        
                        <?php if ($user['is_banned']): ?>
                            <span class="badge banned"><i class="bi bi-slash-circle"></i> 已封禁</span>
                        <?php endif; ?>
                        
                        <?php foreach ($userBadges as $badge): ?>
                            <span class="badge" style="background: linear-gradient(135deg, #<?= substr(md5($badge['name']), 0, 6) ?> 0%, #<?= substr(md5($badge['name']), 6, 6) ?> 100%);">
                                <?= htmlspecialchars($badge['name']) ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
            <!-- 个人简介区域 -->
            <div class="profile-bio">
                <h4><i class="bi bi-person-lines-fill"></i> 个人简介</h4>
                <div class="profile-bio-content <?= empty($user['bio']) ? 'empty' : '' ?>">
                    <?= !empty($user['bio']) ? nl2br(htmlspecialchars($user['bio'])) : '这个人很懒，还没有写个人简介...' ?>
                </div>
            </div>
            
            <div class="profile-content">
                <div class="profile-tabs">
                    <a href="profile.php?username=<?= $user['username'] ?>" class="active"><i class="bi bi-file-text"></i> 帖子 (<?= $postsData['total'] ?>)</a>
                    <a href="profile.php?username=<?= $user['username'] ?>&tab=favorites"><i class="bi bi-bookmark"></i> 收藏</a>
                </div>
                
                <div class="profile-posts">
                    <?php if ($posts): ?>
                        <?php foreach ($posts as $post): ?>
                            <div class="post-card" onclick="window.location.href='post.php?id=<?= $post['id'] ?>'">
                                <h3 class="post-title">
                                    <a href="post.php?id=<?= $post['id'] ?>"><?= htmlspecialchars($post['title']) ?></a>
                                </h3>
                                <div class="post-meta">
                                    <span class="post-category"><i class="bi bi-tag"></i> <?= htmlspecialchars(getCategory($post['category_id'])['name']) ?></span>
                                    <span class="post-date"><i class="bi bi-clock"></i> <?= $post['created_at'] ?></span>
                                    <span class="post-views"><i class="bi bi-eye"></i> <?= $post['views'] ?></span>
                                    <span class="post-comments"><i class="bi bi-chat-left"></i> <?= count(getComments($post['id'])) ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-posts">
                            <i class="bi bi-file-text"></i>
                            <p>暂无帖子</p>
                            <?php if ($isCurrentUser): ?>
                                <a href="create_post.php" class="btn"><i class="bi bi-plus-circle"></i> 发表新帖</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($totalPages > 1): ?>
                        <div class="pagination">
                            <?php if ($currentPage > 1): ?>
                                <a href="?username=<?= $user['username'] ?>&page=<?= $currentPage - 1 ?>">
                                    <i class="bi bi-chevron-left"></i> 上一页
                                </a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <a href="?username=<?= $user['username'] ?>&page=<?= $i ?>" <?= $i == $currentPage ? 'class="active"' : '' ?>>
                                    <?= $i ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($currentPage < $totalPages): ?>
                                <a href="?username=<?= $user['username'] ?>&page=<?= $currentPage + 1 ?>">
                                    下一页 <i class="bi bi-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if ($isCurrentUser): ?>
                <div class="profile-settings">
                    <h3><i class="bi bi-gear"></i> 个人设置</h3>
                    
                    <?php if ($error): ?>
                        <div class="alert error">
                            <i class="bi bi-exclamation-circle"></i> <?= $error ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert success">
                            <i class="bi bi-check-circle"></i> <?= $success ?>
                        </div>
                    <?php endif; ?>
                    
                    <form action="profile.php" method="post">
                        <div class="form-group">
                            <label for="username">用户名</label>
                            <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
                            <div class="username-change-notice">
                                <i class="bi bi-info-circle"></i> 修改用户名后，您的个人主页链接将发生变化
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">电子邮箱</label>
                            <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                        </div>
                        
                        <!-- 个人简介编辑框 -->
                        <div class="form-group">
                            <label for="bio">个人简介 <span class="text-muted">(不超过500字)</span></label>
                            <textarea id="bio" name="bio" class="form-control" rows="4" placeholder="介绍一下你自己..."><?= htmlspecialchars($user['bio'] ?? '') ?></textarea>
                            <div class="bio-counter" id="bioCounter">已输入 <?= strlen($user['bio'] ?? '') ?>/500 字</div>
                        </div>
                        
                        <div class="form-group">
                            <label for="password">新密码 (留空则不修改)</label>
                            <input type="password" id="password" name="password" placeholder="输入新密码">
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">确认新密码</label>
                            <input type="password" id="confirm_password" name="confirm_password" placeholder="再次输入新密码">
                        </div>
                        
                        <button type="submit" class="btn">
                            <i class="bi bi-save"></i> 更新信息
                        </button>
                    </form>
                </div>
                
                <!-- 头衔申请系统 -->
                <div class="badge-system">
                    <h3><i class="bi bi-award"></i> 我的头衔</h3>
                    
                    <?php if ($userBadges): ?>
                        <div class="badge-list">
                            <?php foreach ($userBadges as $badge): ?>
                                <span class="badge" style="background: linear-gradient(135deg, #<?= substr(md5($badge['name']), 0, 6) ?> 0%, #<?= substr(md5($badge['name']), 6, 6) ?> 100%);">
                                    <?= htmlspecialchars($badge['name']) ?>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">暂无头衔</p>
                    <?php endif; ?>
                    
                    <div class="badge-application">
                        <h4><i class="bi bi-send"></i> 申请新头衔</h4>
                        
                        <form action="profile.php" method="post">
                            <div class="form-group">
                                <label for="badge_name">头衔名称</label>
                                <input type="text" id="badge_name" name="badge_name" placeholder="输入您想要的头衔名称" maxlength="20" required>
                                <small class="text-muted">最多20个字符，如"论坛元老"、"技术达人"等</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="reason">申请理由</label>
                                <textarea id="reason" name="reason" rows="3" placeholder="请说明为什么您应该获得这个头衔" required></textarea>
                            </div>
                            
                            <button type="submit" name="apply_badge" class="btn">
                                <i class="bi bi-send"></i> 提交申请
                            </button>
                        </form>
                        
                        <?php if ($badgeApplications): ?>
                            <div class="application-history">
                                <h5><i class="bi bi-clock-history"></i> 申请记录</h5>
                                
                                <div class="applications">
                                    <?php foreach ($badgeApplications as $app): ?>
                                        <div class="application-card <?= $app['status'] ?>">
                                            <div class="application-header">
                                                <span class="badge-name"><?= htmlspecialchars($app['badge_name']) ?></span>
                                                <span class="application-status <?= $app['status'] ?>">
                                                    <?= $app['status'] === 'pending' ? '审核中' : ($app['status'] === 'approved' ? '已批准' : '已拒绝') ?>
                                                </span>
                                            </div>
                                            
                                            <div class="application-reason">
                                                <strong>申请理由:</strong> <?= nl2br(htmlspecialchars($app['reason'])) ?>
                                            </div>
                                            
                                            <div class="application-meta">
                                                <span><i class="bi bi-calendar"></i> <?= $app['created_at'] ?></span>
                                                
                                                <?php if ($app['status'] !== 'pending'): ?>
                                                    <?php $admin = getUser($app['processed_by']); ?>
                                                    <span><i class="bi bi-person-check"></i> 处理人: <?= $admin ? htmlspecialchars($admin['username']) : '系统' ?></span>
                                                    <span><i class="bi bi-clock"></i> <?= $app['processed_at'] ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="no-applications">
                                <i class="bi bi-clock-history"></i>
                                <p>暂无申请记录</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- 底部导航栏 -->
    <nav class="bottom-nav">
        <div class="nav-items">
            <a href="index.php" class="nav-item">
                <i class="bi bi-house"></i>
                <span>主页</span>
            </a>
            <a href="create_post.php" class="nav-item">
                <i class="bi bi-plus-circle"></i>
                <span>发帖</span>
            </a>
            <a href="profile.php" class="nav-item active">
                <i class="bi bi-person"></i>
                <span>我的</span>
            </a>
            <a href="search.php" class="nav-item">
                <i class="bi bi-search"></i>
                <span>搜索</span>
            </a>
        </div>
    </nav>

    <footer>
        <div class="container">
            <p>Copyright © <?= date('Y') ?> <?= htmlspecialchars(getSettings()['site_title']) ?> - 分享二次元的快乐</p>
        </div>
    </footer>

    <script>
        // 移动端菜单切换
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        const searchBox = document.getElementById('searchBox');
        
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            searchBox.classList.toggle('active');
            
            // 切换图标
            const icon = this.querySelector('i');
            if (mainNav.classList.contains('active')) {
                icon.classList.remove('bi-list');
                icon.classList.add('bi-x');
            } else {
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        });
        
        // 头像预览功能
        document.getElementById('avatar')?.addEventListener('change', function(e) {
            if (this.files && this.files[0]) {
                const file = this.files[0];
                const maxSize = 500 * 1024; // 500KB
                
                if (file.size > maxSize) {
                    alert('图片大小不能超过500KB');
                    this.value = '';
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.querySelector('.profile-avatar img').src = e.target.result;
                }
                reader.readAsDataURL(file);
                
                // 自动提交表单
                this.form.submit();
            }
        });
        
        // 帖子卡片点击事件
        document.querySelectorAll('.post-card').forEach(card => {
            card.addEventListener('click', function(e) {
                if (e.target.tagName !== 'A') {
                    window.location.href = this.querySelector('a').href;
                }
            });
        });
        
        // 表单提交动画
        document.querySelector('form')?.addEventListener('submit', function(e) {
            const btn = this.querySelector('button[type="submit"]');
            if (btn) {
                btn.innerHTML = '<i class="bi bi-arrow-repeat"></i> 保存中...';
                btn.disabled = true;
            }
        });
        
        // 底部导航激活状态切换
        document.querySelectorAll('.bottom-nav .nav-item').forEach(item => {
            item.addEventListener('click', function() {
                document.querySelectorAll('.bottom-nav .nav-item').forEach(i => {
                    i.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
        
        // 添加页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            document.body.style.opacity = '0';
            setTimeout(() => {
                document.body.style.transition = 'opacity 0.3s ease';
                document.body.style.opacity = '1';
            }, 100);
        });
        
        // 个人简介字数统计
        const bioTextarea = document.getElementById('bio');
        const bioCounter = document.getElementById('bioCounter');
        
        if (bioTextarea && bioCounter) {
            bioTextarea.addEventListener('input', function() {
                const length = this.value.length;
                bioCounter.textContent = `已输入 ${length}/500 字`;
                
                if (length > 500) {
                    bioCounter.classList.add('warning');
                } else {
                    bioCounter.classList.remove('warning');
                }
            });
        }
        
        // 头衔名称输入时实时预览
        const badgeNameInput = document.getElementById('badge_name');
        const badgePreview = document.createElement('div');
        badgePreview.className = 'badge-preview';
        badgePreview.style.margin = '0.5rem 0';
        badgePreview.style.display = 'none';

        if (badgeNameInput) {
            badgeNameInput.insertAdjacentElement('afterend', badgePreview);
            
            badgeNameInput.addEventListener('input', function() {
                if (this.value.trim()) {
                    badgePreview.style.display = 'block';
                    
                    // 简单的颜色生成函数
                    const hash = Array.from(this.value).reduce((hash, char) => {
                        const chr = char.charCodeAt(0);
                        let hashVal = ((hash << 5) - hash) + chr;
                        return hashVal & hashVal;
                    }, 0).toString(16).padStart(8, '0');
                    
                    const color1 = hash.substring(0, 6);
                    const color2 = hash.substring(2, 8);
                    
                    badgePreview.innerHTML = `
                        <span class="badge" style="background: linear-gradient(135deg, #${color1} 0%, #${color2} 100%);">
                            ${this.value}
                        </span>
                        <small class="text-muted">预览效果</small>
                    `;
                } else {
                    badgePreview.style.display = 'none';
                }
            });
        }
        
        // 根据屏幕宽度自动调整布局
        function handleResponsive() {
            if (window.innerWidth > 768) {
                mainNav.classList.remove('active');
                searchBox.classList.remove('active');
                const icon = mobileMenuBtn.querySelector('i');
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        }
        
        window.addEventListener('resize', handleResponsive);
        handleResponsive();
    </script>
</body>
</html>