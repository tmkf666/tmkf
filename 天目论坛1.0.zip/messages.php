<?php
// 社交中心完整实现 - 优化版

// 数据文件定义
define('USERS_FILE', 'tm/users.txt');
define('POSTS_FILE', 'data/posts.dat');
define('COMMENTS_FILE', 'data/comments.dat');
define('CATEGORIES_FILE', 'data/categories.dat');
define('SETTINGS_FILE', 'data/settings.dat');
define('MESSAGES_FILE', 'data/messages.dat');
define('GROUP_MESSAGES_FILE', 'data/group_messages.dat');
define('GROUPS_FILE', 'data/groups.dat');
define('FRIENDS_FILE', 'data/friends.dat');
define('FRIEND_REQUESTS_FILE', 'data/friend_requests.dat');
define('LOGIN_ATTEMPTS_FILE', 'data/login_attempts.dat');
define('USER_BADGES_FILE', 'data/user_badges.dat');
define('UPLOAD_DIR', 'uploads/'); // 文件上传目录

// 会话启动和基础检查
session_start();

/**
 * 生成CSRF令牌
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * 验证CSRF令牌
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * 读取数据文件
 */
function readData($file) {
    if (!file_exists($file)) {
        // 创建目录
        $dir = dirname($file);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        return [];
    }
    
    $content = file_get_contents($file);
    return $content ? unserialize($content) : [];
}

/**
 * 写入数据文件
 */
function writeData($file, $data) {
    $dir = dirname($file);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    file_put_contents($file, serialize($data));
}

/**
 * 获取系统设置
 */
function getSettings() {
    $settings = readData(SETTINGS_FILE);
    
    // 默认设置
    $defaultSettings = [
        'site_title' => '天目论坛',
        'password_min_length' => 8,
        'password_complexity' => 'medium',
        'max_login_attempts' => 5,
        'login_ban_time' => 30,
        'require_email_verification' => false,
        'enable_2fa' => false,
        'default_user_role' => 'member',
        'max_upload_size' => 5 * 1024 * 1024, // 5MB
        'allowed_file_types' => ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'txt', 'doc', 'docx']
    ];
    
    return array_merge($defaultSettings, $settings);
}

/**
 * 获取所有用户
 */
function getUsers() {
    return readData(USERS_FILE);
}

/**
 * 获取用户信息
 */
function getUser($id) {
    $users = getUsers();
    foreach ($users as $user) {
        if ($user['id'] == $id) {
            // 获取用户头衔
            $user['badges'] = getUserBadges($id);
            return $user;
        }
    }
    return null;
}

/**
 * 获取用户头衔
 */
function getUserBadges($userId) {
    $userBadges = readData(USER_BADGES_FILE);
    return isset($userBadges[$userId]) ? $userBadges[$userId] : [];
}

/**
 * 通过用户名获取用户
 */
function getUserByUsername($username) {
    $users = getUsers();
    foreach ($users as $user) {
        if ($user['username'] === $username) {
            // 获取用户头衔
            $user['badges'] = getUserBadges($user['id']);
            return $user;
        }
    }
    return null;
}

/**
 * 获取当前用户
 */
function getCurrentUser() {
    if (isset($_SESSION['user_id'])) {
        return getUser($_SESSION['user_id']);
    }
    return null;
}

/**
 * 检查是否登录
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && getUser($_SESSION['user_id']);
}

/**
 * 检查是否是管理员
 */
function isAdmin($userId) {
    $user = getUser($userId);
    return $user && isset($user['is_admin']) && $user['is_admin'];
}

/**
 * 获取未读消息数量
 */
function getUnreadCount($userId) {
    $messages = readData(MESSAGES_FILE);
    $count = 0;
    
    foreach ($messages as $message) {
        if ($message['receiver_id'] == $userId && !$message['is_read']) {
            $count++;
        }
    }
    
    return $count;
}

/**
 * 标记消息为已读
 */
function markMessagesAsRead($currentUserId, $chatUserId) {
    $messages = readData(MESSAGES_FILE);
    $updated = false;
    
    foreach ($messages as &$message) {
        if ($message['receiver_id'] == $currentUserId && 
            $message['sender_id'] == $chatUserId && 
            !$message['is_read']) {
            $message['is_read'] = true;
            $message['read_at'] = date('Y-m-d H:i:s');
            $updated = true;
        }
    }
    
    if ($updated) {
        writeData(MESSAGES_FILE, $messages);
    }
    
    return $updated;
}

// 好友管理功能

/**
 * 获取好友列表
 */
function getFriends($userId) {
    $friends = readData(FRIENDS_FILE);
    $userFriends = [];
    
    foreach ($friends as $friend) {
        if ($friend['user_id1'] == $userId || $friend['user_id2'] == $userId) {
            $friendId = ($friend['user_id1'] == $userId) ? $friend['user_id2'] : $friend['user_id1'];
            $friendData = getUser($friendId);
            if ($friendData) {
                $userFriends[] = $friendData;
            }
        }
    }
    
    return $userFriends;
}

/**
 * 检查两人是否是好友
 */
function isFriend($userId1, $userId2) {
    $friends = readData(FRIENDS_FILE);
    
    foreach ($friends as $friendship) {
        if (($friendship['user_id1'] == $userId1 && $friendship['user_id2'] == $userId2) ||
            ($friendship['user_id1'] == $userId2 && $friendship['user_id2'] == $userId1)) {
            return true;
        }
    }
    
    return false;
}

/**
 * 获取好友请求列表
 */
function getFriendRequests($userId) {
    $requests = readData(FRIEND_REQUESTS_FILE);
    $userRequests = [];
    
    foreach ($requests as $request) {
        if ($request['receiver_id'] == $userId && $request['status'] == 'pending') {
            $userRequests[] = $request;
        }
    }
    
    return $userRequests;
}

/**
 * 发送好友请求
 */
function sendFriendRequest($senderId, $receiverId) {
    $requests = readData(FRIEND_REQUESTS_FILE);
    
    // 检查是否已存在请求
    foreach ($requests as $request) {
        if ($request['sender_id'] == $senderId && $request['receiver_id'] == $receiverId && $request['status'] == 'pending') {
            return false; // 请求已存在
        }
    }
    
    $ids = array_column($requests, 'id');
    $newId = $ids ? max($ids) + 1 : 1;
    
    $request = [
        'id' => $newId,
        'sender_id' => $senderId,
        'receiver_id' => $receiverId,
        'status' => 'pending',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    $requests[] = $request;
    writeData(FRIEND_REQUESTS_FILE, $requests);
    return true;
}

/**
 * 接受好友请求
 */
function acceptFriendRequest($requestId) {
    $requests = readData(FRIEND_REQUESTS_FILE);
    $friends = readData(FRIENDS_FILE);
    
    foreach ($requests as &$request) {
        if ($request['id'] == $requestId) {
            $request['status'] = 'accepted';
            
            // 添加好友关系
            $friendIds = [$request['sender_id'], $request['receiver_id']];
            sort($friendIds);
            
            $friends[] = [
                'user_id1' => $friendIds[0],
                'user_id2' => $friendIds[1],
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            writeData(FRIENDS_FILE, $friends);
            break;
        }
    }
    
    writeData(FRIEND_REQUESTS_FILE, $requests);
    return true;
}

/**
 * 拒绝好友请求
 */
function rejectFriendRequest($requestId) {
    $requests = readData(FRIEND_REQUESTS_FILE);
    
    foreach ($requests as &$request) {
        if ($request['id'] == $requestId) {
            $request['status'] = 'rejected';
            break;
        }
    }
    
    writeData(FRIEND_REQUESTS_FILE, $requests);
    return true;
}

// 消息功能

/**
 * 获取私信（分页）
 */
function getMessages($currentUserId, $chatUserId, $page = 1, $perPage = 50) {
    $messages = readData(MESSAGES_FILE);
    $filtered = [];
    
    foreach ($messages as $message) {
        if (($message['sender_id'] == $currentUserId && $message['receiver_id'] == $chatUserId) ||
            ($message['sender_id'] == $chatUserId && $message['receiver_id'] == $currentUserId)) {
            $filtered[] = $message;
        }
    }
    
    // 按时间排序
    usort($filtered, function($a, $b) {
        return strtotime($a['created_at']) - strtotime($b['created_at']);
    });
    
    $total = count($filtered);
    $offset = ($page - 1) * $perPage;
    $paginatedMessages = array_slice($filtered, $offset, $perPage);
    
    return [
        'messages' => $paginatedMessages,
        'total' => $total,
        'page' => $page,
        'per_page' => $perPage,
        'total_pages' => ceil($total / $perPage)
    ];
}

/**
 * 发送私信
 */
function sendMessage($senderId, $receiverId, $content, $attachment = null) {
    $messages = readData(MESSAGES_FILE);
    $ids = array_column($messages, 'id');
    $newId = $ids ? max($ids) + 1 : 1;
    
    $message = [
        'id' => $newId,
        'sender_id' => $senderId,
        'receiver_id' => $receiverId,
        'content' => $content,
        'created_at' => date('Y-m-d H:i:s'),
        'is_read' => false,
        'attachment' => $attachment
    ];
    
    $messages[] = $message;
    writeData(MESSAGES_FILE, $messages);
    return $newId;
}

/**
 * 处理文件上传
 */
function handleFileUpload($file, $userId) {
    $settings = getSettings();
    $allowedTypes = $settings['allowed_file_types'];
    $maxSize = $settings['max_upload_size'];
    
    // 检查文件类型
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($fileExtension, $allowedTypes)) {
        throw new Exception('文件类型不支持，仅支持: ' . implode(', ', $allowedTypes));
    }
    
    // 检查文件大小
    if ($file['size'] > $maxSize) {
        throw new Exception('文件大小超过限制，最大允许: ' . ($maxSize / 1024 / 1024) . 'MB');
    }
    
    // 创建用户目录
    $userDir = UPLOAD_DIR . $userId . '/';
    if (!is_dir($userDir)) {
        mkdir($userDir, 0755, true);
    }
    
    // 生成唯一文件名
    $filename = uniqid() . '_' . time() . '.' . $fileExtension;
    $filepath = $userDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return [
            'filename' => $file['name'],
            'filepath' => $filepath,
            'size' => $file['size'],
            'type' => $file['type']
        ];
    }
    
    throw new Exception('文件上传失败');
}

// 群组功能

/**
 * 获取群组列表
 */
function getGroups($userId) {
    $groups = readData(GROUPS_FILE);
    $userGroups = [];
    
    foreach ($groups as $group) {
        if (in_array($userId, $group['members'])) {
            $userGroups[] = $group;
        }
    }
    
    return $userGroups;
}

/**
 * 获取群组信息
 */
function getGroup($id) {
    $groups = readData(GROUPS_FILE);
    foreach ($groups as $group) {
        if ($group['id'] == $id) {
            return $group;
        }
    }
    return null;
}

/**
 * 获取群组消息
 */
function getGroupMessages($groupId, $page = 1, $perPage = 50) {
    $messages = readData(GROUP_MESSAGES_FILE);
    $filtered = array_filter($messages, function($message) use ($groupId) {
        return $message['group_id'] == $groupId;
    });
    
    // 按时间排序
    usort($filtered, function($a, $b) {
        return strtotime($a['created_at']) - strtotime($b['created_at']);
    });
    
    $total = count($filtered);
    $offset = ($page - 1) * $perPage;
    $paginatedMessages = array_slice($filtered, $offset, $perPage);
    
    return [
        'messages' => $paginatedMessages,
        'total' => $total,
        'page' => $page,
        'per_page' => $perPage,
        'total_pages' => ceil($total / $perPage)
    ];
}

/**
 * 创建群组
 */
function createGroup($creatorId, $groupName, $memberIds) {
    $groups = readData(GROUPS_FILE);
    $ids = array_column($groups, 'id');
    $newId = $ids ? max($ids) + 1 : 1;
    
    // 确保创建者也在成员中
    if (!in_array($creatorId, $memberIds)) {
        $memberIds[] = $creatorId;
    }
    
    $group = [
        'id' => $newId,
        'name' => $groupName,
        'creator_id' => $creatorId,
        'created_at' => date('Y-m-d H:i:s'),
        'members' => $memberIds
    ];
    
    $groups[] = $group;
    writeData(GROUPS_FILE, $groups);
    return $newId;
}

/**
 * 发送群组消息
 */
function sendGroupMessage($groupId, $senderId, $content, $attachment = null) {
    $messages = readData(GROUP_MESSAGES_FILE);
    $ids = array_column($messages, 'id');
    $newId = $ids ? max($ids) + 1 : 1;
    
    $message = [
        'id' => $newId,
        'group_id' => $groupId,
        'sender_id' => $senderId,
        'content' => $content,
        'created_at' => date('Y-m-d H:i:s'),
        'attachment' => $attachment
    ];
    
    $messages[] = $message;
    writeData(GROUP_MESSAGES_FILE, $messages);
    return $newId;
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
    
    $currentUser = getCurrentUser();
    
    // 验证CSRF令牌
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $_SESSION['error'] = "安全令牌验证失败";
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }
    
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'send_message':
                $recipientId = intval($_POST['recipient_id']);
                $message = trim($_POST['message']);
                $attachment = null;
                
                // 处理文件上传
                if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                    try {
                        $attachment = handleFileUpload($_FILES['attachment'], $currentUser['id']);
                    } catch (Exception $e) {
                        $_SESSION['error'] = $e->getMessage();
                        break;
                    }
                }
                
                if ((!empty($message) || $attachment) && $recipientId > 0) {
                    sendMessage($currentUser['id'], $recipientId, $message, $attachment);
                }
                break;
                
            case 'send_group_message':
                $groupId = intval($_POST['group_id']);
                $message = trim($_POST['message']);
                $attachment = null;
                
                // 处理文件上传
                if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                    try {
                        $attachment = handleFileUpload($_FILES['attachment'], $currentUser['id']);
                    } catch (Exception $e) {
                        $_SESSION['error'] = $e->getMessage();
                        break;
                    }
                }
                
                if ((!empty($message) || $attachment) && $groupId > 0) {
                    sendGroupMessage($groupId, $currentUser['id'], $message, $attachment);
                }
                break;
                
            case 'create_group':
                $groupName = trim($_POST['group_name']);
                $selectedFriends = isset($_POST['friends']) ? array_map('intval', $_POST['friends']) : [];
                
                if (!empty($groupName) && count($selectedFriends) >= 2) {
                    createGroup($currentUser['id'], $groupName, $selectedFriends);
                    $_SESSION['success'] = "群组创建成功";
                } else {
                    $_SESSION['error'] = "群组名称不能为空且需要选择至少2个好友";
                }
                break;
                
            case 'add_friend':
                $friendId = intval($_POST['friend_id']);
                if ($friendId > 0) {
                    if (sendFriendRequest($currentUser['id'], $friendId)) {
                        $_SESSION['success'] = "好友请求已发送";
                    } else {
                        $_SESSION['error'] = "请求发送失败，可能已存在待处理请求";
                    }
                }
                break;
                
            case 'accept_request':
                $requestId = intval($_POST['request_id']);
                if ($requestId > 0) {
                    if (acceptFriendRequest($requestId)) {
                        $_SESSION['success'] = "好友请求已接受";
                    } else {
                        $_SESSION['error'] = "操作失败";
                    }
                }
                break;
                
            case 'reject_request':
                $requestId = intval($_POST['request_id']);
                if ($requestId > 0) {
                    if (rejectFriendRequest($requestId)) {
                        $_SESSION['success'] = "好友请求已拒绝";
                    } else {
                        $_SESSION['error'] = "操作失败";
                    }
                }
                break;
                
            case 'mark_as_read':
                $chatUserId = intval($_POST['chat_user_id']);
                if ($chatUserId > 0) {
                    markMessagesAsRead($currentUser['id'], $chatUserId);
                }
                break;
        }
    }
    
    // 重定向以避免重复提交
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// 获取当前用户和聊天信息
$currentUser = getCurrentUser();
$chatUserId = isset($_GET['chat']) ? intval($_GET['chat']) : null;
$chatGroupId = isset($_GET['group']) ? intval($_GET['group']) : null;
$action = isset($_GET['action']) ? $_GET['action'] : 'messages';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

// 获取相关数据
$friends = $currentUser ? getFriends($currentUser['id']) : [];
$groups = $currentUser ? getGroups($currentUser['id']) : [];
$friendRequests = $currentUser ? getFriendRequests($currentUser['id']) : [];
$allUsers = getUsers();
$unreadCount = $currentUser ? getUnreadCount($currentUser['id']) : 0;

// 初始化聊天相关变量
$chatUser = null;
$chatGroup = null;
$messagesData = ['messages' => [], 'total' => 0, 'page' => 1, 'per_page' => 50, 'total_pages' => 0];

// 获取聊天记录
if ($chatUserId) {
    $chatUser = getUser($chatUserId);
    if ($chatUser) {
        $messagesData = getMessages($currentUser['id'], $chatUserId, $page);
        // 标记消息为已读
        markMessagesAsRead($currentUser['id'], $chatUserId);
    }
} elseif ($chatGroupId) {
    $chatGroup = getGroup($chatGroupId);
    if ($chatGroup) {
        $messagesData = getGroupMessages($chatGroupId, $page);
    }
}

// 处理搜索
$searchResults = [];
$searchTerm = '';
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = trim($_GET['search']);
    foreach ($allUsers as $user) {
        if ($currentUser && $user['id'] != $currentUser['id'] && 
            (stripos($user['username'], $searchTerm) !== false || 
             stripos($user['email'], $searchTerm) !== false)) {
            $searchResults[] = $user;
        }
    }
}

// 确保搜索页面被激活
if (isset($_GET['search']) && $action !== 'search') {
    $action = 'search';
}

// 生成CSRF令牌
$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>社交中心 - <?= htmlspecialchars(getSettings()['site_title']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #ff85a2;
            --primary-light: #ffb6c1;
            --primary-dark: #e75480;
            --secondary: #9b5de5;
            --accent: #00bbf9;
            --light: #fff9fb;
            --dark: #4a4a4a;
            --gray: #a0a0a0;
            --success: #00f5d4;
            --danger: #f72585;
            --warning: #ffd166;
            --border-radius: 16px;
            --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15);
            --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
            min-height: 100vh;
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 1rem;
        }
        
        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 1.5rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            box-shadow: var(--box-shadow);
        }
        
        .tabs {
            display: flex;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
            overflow-x: auto;
            padding-bottom: 0.5rem;
        }
        
        .tab {
            position: relative;
            padding: 0.75rem 1.5rem;
            background: white;
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
            white-space: nowrap;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .tab:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }
        
        .tab.active {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.3);
        }
        
        .badge-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            font-weight: bold;
        }
        
        .content-section {
            display: none;
        }
        
        .content-section.active {
            display: block;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .card {
            background: white;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--box-shadow);
            border: 1px solid rgba(255, 133, 162, 0.1);
        }
        
        /* 消息样式 */
        .message-container {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            height: 400px;
            overflow-y: auto;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.8);
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
        }
        
        .message {
            max-width: 80%;
            padding: 0.75rem 1rem;
            border-radius: var(--border-radius);
            position: relative;
            word-wrap: break-word;
        }
        
        .message.sent {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            margin-left: auto;
            border-bottom-right-radius: 0;
        }
        
        .message.received {
            background: #f5f5f5;
            margin-right: auto;
            border-bottom-left-radius: 0;
        }
        
        .message-time {
            font-size: 0.75rem;
            color: var(--gray);
            margin-top: 0.25rem;
            text-align: right;
        }
        
        .message-status {
            font-size: 0.7rem;
            margin-top: 0.25rem;
            opacity: 0.8;
        }
        
        .attachment {
            margin-top: 0.5rem;
            padding: 0.5rem;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .attachment img {
            max-width: 200px;
            max-height: 150px;
            border-radius: 8px;
        }
        
        .attachment-info {
            flex: 1;
        }
        
        .attachment-name {
            font-weight: 500;
            margin-bottom: 0.25rem;
        }
        
        .attachment-size {
            font-size: 0.8rem;
            color: var(--gray);
        }
        
        /* 用户列表样式 */
        .user-list {
            display: grid;
            gap: 0.75rem;
        }
        
        .user-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            transition: var(--transition);
            border: 1px solid rgba(255, 133, 162, 0.1);
        }
        
        .user-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            border-color: rgba(255, 133, 162, 0.3);
        }
        
        .user-item.active {
            border-left: 4px solid var(--primary);
        }
        
        .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.25rem;
            flex-shrink: 0;
        }
        
        .user-info {
            flex: 1;
            min-width: 0;
        }
        
        .user-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .user-meta {
            font-size: 0.85rem;
            color: var(--gray);
        }
        
        /* 头衔样式 */
        .badges {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 500;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
        }
        
        .badge.admin {
            background: linear-gradient(135deg, var(--success) 0%, #00cc99 100%);
        }
        
        .badge.moderator {
            background: linear-gradient(135deg, var(--accent) 0%, #0099cc 100%);
        }
        
        /* 按钮样式 */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            gap: 0.5rem;
            font-size: 0.9rem;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.3);
        }
        
        .btn-success {
            background: linear-gradient(135deg, var(--success) 0%, #00cc99 100%);
            color: white;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, var(--danger) 0%, #e01a4f 100%);
            color: white;
        }
        
        /* 表单样式 */
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        
        input, textarea, select {
            width: 100%;
            padding: 0.75rem 1.25rem;
            border: 1px solid #e0e0e0;
            border-radius: var(--border-radius);
            font-family: inherit;
            font-size: 1rem;
            transition: var(--transition);
        }
        
        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 133, 162, 0.2);
        }
        
        textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        .file-input {
            padding: 0.5rem;
            border: 2px dashed #e0e0e0;
            border-radius: var(--border-radius);
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .file-input:hover {
            border-color: var(--primary);
            background: rgba(255, 133, 162, 0.05);
        }
        
        .file-input i {
            font-size: 2rem;
            color: var(--primary);
            margin-bottom: 0.5rem;
        }
        
        /* 提示信息 */
        .alert {
            padding: 1rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .alert-success {
            background: rgba(0, 245, 212, 0.1);
            color: var(--success);
            border-left: 4px solid var(--success);
        }
        
        .alert-error {
            background: rgba(247, 37, 133, 0.1);
            color: var(--danger);
            border-left: 4px solid var(--danger);
        }
        
        /* 搜索样式 */
        .search-form {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .search-form input {
            flex: 1;
        }
        
        .search-results {
            background: white;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            box-shadow: var(--box-shadow);
        }
        
        .search-title {
            margin-bottom: 1rem;
            color: var(--dark);
            font-size: 1.25rem;
            font-weight: 600;
        }
        
        .no-results {
            text-align: center;
            padding: 2rem;
            color: var(--gray);
        }
        
        .no-results i {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }
        
        /* 分页样式 */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 1.5rem;
        }
        
        .pagination a, .pagination span {
            padding: 0.5rem 1rem;
            border-radius: var(--border-radius);
            text-decoration: none;
            color: var(--dark);
            background: white;
            border: 1px solid #e0e0e0;
            transition: var(--transition);
        }
        
        .pagination a:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        
        .pagination .current {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        
        /* 底部导航栏 - 移动端 */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 133, 162, 0.2);
            padding: 0.75rem 0;
            display: none;
            z-index: 1000;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .nav-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .nav-item {
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
            padding: 0.5rem;
            border-radius: 50px;
            transition: var(--transition);
            color: var(--gray);
            text-decoration: none;
        }
        
        .nav-item.active {
            color: var(--primary);
        }
        
        .nav-item i {
            font-size: 1.25rem;
            background: rgba(255, 133, 162, 0.1);
            width: 2.5rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .nav-item.active i {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 10px rgba(255, 133, 162, 0.3);
        }
        
        .nav-item span {
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .nav-badge {
            position: absolute;
            top: 0;
            right: 0;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            font-weight: bold;
        }
        
        /* 响应式设计 */
        @media (min-width: 768px) {
            .chat-container {
                display: grid;
                grid-template-columns: 300px 1fr;
                gap: 1.5rem;
            }
            
            .user-list-container {
                height: 600px;
                overflow-y: auto;
            }
            
            .message-container {
                height: 600px;
            }
        }
        
        @media (max-width: 767px) {
            .container {
                padding-bottom: 5rem; /* 为底部导航留出空间 */
            }
            
            /* 显示底部导航 */
            .bottom-nav {
                display: block;
            }
            
            .message {
                max-width: 90%;
            }
            
            .user-item {
                padding: 0.75rem;
            }
            
            .avatar {
                width: 40px;
                height: 40px;
                font-size: 1rem;
            }
            
            .btn {
                padding: 0.5rem 1rem;
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>社交中心</h1>
            <p>与好友聊天，管理关系</p>
        </header>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <i class="bi bi-check-circle"></i> <?= $_SESSION['success'] ?>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <i class="bi bi-exclamation-circle"></i> <?= $_SESSION['error'] ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <?php if (!isLoggedIn()): ?>
            <div class="card">
                <p>请先 <a href="login.php">登录</a> 以使用社交功能</p>
            </div>
        <?php else: ?>
            <div class="tabs">
                <div class="tab <?= $action === 'messages' ? 'active' : '' ?>" onclick="showSection('messages')">
                    <i class="bi bi-chat-left-text"></i> 消息
                    <?php if ($unreadCount > 0): ?>
                        <span class="badge-count"><?= $unreadCount ?></span>
                    <?php endif; ?>
                </div>
                <div class="tab <?= $action === 'friends' ? 'active' : '' ?>" onclick="showSection('friends')">
                    <i class="bi bi-people"></i> 好友
                </div>
                <div class="tab <?= $action === 'requests' ? 'active' : '' ?>" onclick="showSection('requests')">
                    <i class="bi bi-envelope"></i> 好友请求
                    <?php if (count($friendRequests) > 0): ?>
                        <span class="badge-count"><?= count($friendRequests) ?></span>
                    <?php endif; ?>
                </div>
                <div class="tab <?= $action === 'groups' ? 'active' : '' ?>" onclick="showSection('groups')">
                    <i class="bi bi-collection"></i> 群组
                </div>
                <div class="tab <?= $action === 'search' ? 'active' : '' ?>" onclick="showSection('search')">
                    <i class="bi bi-search"></i> 搜索用户
                </div>
            </div>
            
            <!-- 消息页面 -->
            <div id="messages" class="content-section <?= $action === 'messages' ? 'active' : '' ?>">
                <div class="card">
                    <h2><i class="bi bi-chat-left-text"></i> 消息中心</h2>
                    
                    <div class="chat-container">
                        <!-- 联系人列表 -->
                        <div class="user-list-container">
                            <h3><i class="bi bi-people"></i> 好友列表</h3>
                            <div class="user-list">
                                <?php if (!empty($friends)): ?>
                                    <?php foreach ($friends as $friend): ?>
                                        <a href="?action=messages&chat=<?= $friend['id'] ?>" style="text-decoration: none;">
                                            <div class="user-item <?= $chatUserId == $friend['id'] ? 'active' : '' ?>">
                                                <div class="avatar"><?= mb_substr($friend['username'], 0, 1) ?></div>
                                                <div class="user-info">
                                                    <div class="user-name"><?= htmlspecialchars($friend['username']) ?></div>
                                                    <div class="user-meta">
                                                        <small>最后活跃: 刚刚</small>
                                                    </div>
                                                    <?php if (!empty($friend['badges'])): ?>
                                                        <div class="badges">
                                                            <?php foreach ($friend['badges'] as $badge): ?>
                                                                <span class="badge"><?= htmlspecialchars($badge['name']) ?></span>
                                                            <?php endforeach; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </a>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="no-results">
                                        <i class="bi bi-people"></i>
                                        <p>暂无好友</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <h3 style="margin-top: 1.5rem;"><i class="bi bi-collection"></i> 群组列表</h3>
                            <div class="user-list">
                                <?php if (!empty($groups)): ?>
                                    <?php foreach ($groups as $group): ?>
                                        <a href="?action=messages&group=<?= $group['id'] ?>" style="text-decoration: none;">
                                            <div class="user-item <?= $chatGroupId == $group['id'] ? 'active' : '' ?>">
                                                <div class="avatar">群</div>
                                                <div class="user-info">
                                                    <div class="user-name"><?= htmlspecialchars($group['name']) ?></div>
                                                    <div class="user-meta">
                                                        <small><?= count($group['members']) ?> 名成员</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="no-results">
                                        <i class="bi bi-collection"></i>
                                        <p>暂无群组</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- 聊天区域 -->
                        <div>
                            <?php if ($chatUser || $chatGroup): ?>
                                <div class="card">
                                    <h3>
                                        <?php if ($chatUser): ?>
                                            <i class="bi bi-person"></i> 与 <?= htmlspecialchars($chatUser['username']) ?> 的对话
                                        <?php elseif ($chatGroup): ?>
                                            <i class="bi bi-collection"></i> 群组: <?= htmlspecialchars($chatGroup['name']) ?>
                                        <?php endif; ?>
                                    </h3>
                                    
                                    <!-- 分页导航 -->
                                    <?php if ($messagesData['total_pages'] > 1): ?>
                                        <div class="pagination">
                                            <?php if ($page > 1): ?>
                                                <a href="?action=<?= $action ?>&<?= $chatUser ? 'chat='.$chatUser['id'] : 'group='.$chatGroup['id'] ?>&page=<?= $page-1 ?>">上一页</a>
                                            <?php endif; ?>
                                            
                                            <?php for ($i = 1; $i <= $messagesData['total_pages']; $i++): ?>
                                                <?php if ($i == $page): ?>
                                                    <span class="current"><?= $i ?></span>
                                                <?php else: ?>
                                                    <a href="?action=<?= $action ?>&<?= $chatUser ? 'chat='.$chatUser['id'] : 'group='.$chatGroup['id'] ?>&page=<?= $i ?>"><?= $i ?></a>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                            
                                            <?php if ($page < $messagesData['total_pages']): ?>
                                                <a href="?action=<?= $action ?>&<?= $chatUser ? 'chat='.$chatUser['id'] : 'group='.$chatGroup['id'] ?>&page=<?= $page+1 ?>">下一页</a>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="message-container">
                                        <?php if (!empty($messagesData['messages'])): ?>
                                            <?php foreach ($messagesData['messages'] as $message): ?>
                                                <div class="message <?= $message['sender_id'] == $currentUser['id'] ? 'sent' : 'received' ?>">
                                                    <div><?= htmlspecialchars($message['content']) ?></div>
                                                    
                                                    <!-- 附件显示 -->
                                                    <?php if (!empty($message['attachment'])): ?>
                                                        <div class="attachment">
                                                            <?php
                                                            $attachment = $message['attachment'];
                                                            $fileExtension = strtolower(pathinfo($attachment['filename'], PATHINFO_EXTENSION));
                                                            ?>
                                                            <?php if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                                                <img src="<?= htmlspecialchars($attachment['filepath']) ?>" alt="<?= htmlspecialchars($attachment['filename']) ?>">
                                                            <?php else: ?>
                                                                <i class="bi bi-file-earmark"></i>
                                                            <?php endif; ?>
                                                            <div class="attachment-info">
                                                                <div class="attachment-name">
                                                                    <a href="<?= htmlspecialchars($attachment['filepath']) ?>" download="<?= htmlspecialchars($attachment['filename']) ?>">
                                                                        <?= htmlspecialchars($attachment['filename']) ?>
                                                                    </a>
                                                                </div>
                                                                <div class="attachment-size"><?= formatFileSize($attachment['size']) ?></div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                    <div class="message-time">
                                                        <?= date('H:i', strtotime($message['created_at'])) ?>
                                                        <?php if ($message['sender_id'] == $currentUser['id'] && isset($message['is_read']) && $message['is_read']): ?>
                                                            <div class="message-status">已读</div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <div class="no-results">
                                                <i class="bi bi-chat-left"></i>
                                                <p>还没有消息，开始聊天吧</p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <form method="post" enctype="multipart/form-data">
                                        <input type="hidden" name="action" value="<?= $chatUserId ? 'send_message' : 'send_group_message' ?>">
                                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                                        <?php if ($chatUserId): ?>
                                            <input type="hidden" name="recipient_id" value="<?= $chatUserId ?>">
                                        <?php else: ?>
                                            <input type="hidden" name="group_id" value="<?= $chatGroupId ?>">
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <textarea name="message" placeholder="输入消息..." rows="2"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="attachment">添加附件 (可选)</label>
                                            <div class="file-input" onclick="document.getElementById('attachment').click()">
                                                <i class="bi bi-cloud-arrow-up"></i>
                                                <div>点击选择文件或拖放文件到这里</div>
                                                <input type="file" id="attachment" name="attachment" style="display: none;" onchange="updateFileName()">
                                                <div id="file-name" style="margin-top: 0.5rem; font-size: 0.9rem; color: var(--gray);"></div>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="bi bi-send"></i> 发送
                                        </button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <div class="no-results">
                                    <i class="bi bi-chat-left-text"></i>
                                    <p>选择好友或群组开始聊天</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 好友页面 -->
            <div id="friends" class="content-section <?= $action === 'friends' ? 'active' : '' ?>">
                <div class="card">
                    <h2><i class="bi bi-people"></i> 好友列表</h2>
                    <div class="user-list">
                        <?php if (!empty($friends)): ?>
                            <?php foreach ($friends as $friend): ?>
                                <div class="user-item">
                                    <div class="avatar"><?= mb_substr($friend['username'], 0, 1) ?></div>
                                    <div class="user-info">
                                        <div class="user-name"><?= htmlspecialchars($friend['username']) ?></div>
                                        <div class="user-meta"><?= htmlspecialchars($friend['email']) ?></div>
                                        <?php if (!empty($friend['badges'])): ?>
                                            <div class="badges">
                                                <?php foreach ($friend['badges'] as $badge): ?>
                                                    <span class="badge"><?= htmlspecialchars($badge['name']) ?></span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <a href="?action=messages&chat=<?= $friend['id'] ?>" class="btn btn-primary">
                                        <i class="bi bi-chat-left-text"></i> 聊天
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="no-results">
                                <i class="bi bi-people"></i>
                                <p>暂无好友</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- 好友请求页面 -->
            <div id="requests" class="content-section <?= $action === 'requests' ? 'active' : '' ?>">
                <div class="card">
                    <h2><i class="bi bi-envelope"></i> 好友请求</h2>
                    
                    <?php if (!empty($friendRequests)): ?>
                        <?php foreach ($friendRequests as $request): ?>
                            <?php $sender = getUser($request['sender_id']); ?>
                            <?php if ($sender): ?>
                                <div class="user-item">
                                    <div class="avatar"><?= mb_substr($sender['username'], 0, 1) ?></div>
                                    <div class="user-info">
                                        <div class="user-name"><?= htmlspecialchars($sender['username']) ?></div>
                                        <div class="user-meta">请求时间: <?= $request['created_at'] ?></div>
                                        <?php if (!empty($sender['badges'])): ?>
                                            <div class="badges">
                                                <?php foreach ($sender['badges'] as $badge): ?>
                                                    <span class="badge"><?= htmlspecialchars($badge['name']) ?></span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="action" value="accept_request">
                                        <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                                        <button type="submit" class="btn btn-success">
                                            <i class="bi bi-check-circle"></i> 接受
                                        </button>
                                    </form>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="action" value="reject_request">
                                        <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                                        <button type="submit" class="btn btn-danger">
                                            <i class="bi bi-x-circle"></i> 拒绝
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-results">
                            <i class="bi bi-envelope"></i>
                            <p>暂无好友请求</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- 群组页面 -->
            <div id="groups" class="content-section <?= $action === 'groups' ? 'active' : '' ?>">
                <div class="card">
                    <h2><i class="bi bi-collection"></i> 群组管理</h2>
                    
                    <h3><i class="bi bi-people"></i> 我的群组</h3>
                    <div class="user-list">
                        <?php if (!empty($groups)): ?>
                            <?php foreach ($groups as $group): ?>
                                <div class="user-item">
                                    <div class="avatar">群</div>
                                    <div class="user-info">
                                        <div class="user-name"><?= htmlspecialchars($group['name']) ?></div>
                                        <div class="user-meta"><?= count($group['members']) ?> 名成员</div>
                                    </div>
                                    <a href="?action=messages&group=<?= $group['id'] ?>" class="btn btn-primary">
                                        <i class="bi bi-chat-left-text"></i> 进入聊天
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="no-results">
                                <i class="bi bi-people"></i>
                                <p>暂无群组</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <h3 style="margin-top: 1.5rem;"><i class="bi bi-plus-circle"></i> 创建新群组</h3>
                    <form method="post">
                        <input type="hidden" name="action" value="create_group">
                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                        <div class="form-group">
                            <label>群组名称</label>
                            <input type="text" name="group_name" required>
                        </div>
                        <div class="form-group">
                            <label>选择好友（至少选择2个）</label>
                            <div style="max-height: 200px; overflow-y: auto; padding: 1rem; border: 1px solid #e0e0e0; border-radius: var(--border-radius);">
                                <?php foreach ($friends as $friend): ?>
                                    <label style="display: block; margin: 0.5rem 0;">
                                        <input type="checkbox" name="friends[]" value="<?= $friend['id'] ?>">
                                        <?= htmlspecialchars($friend['username']) ?>
                                        <?php if (!empty($friend['badges'])): ?>
                                            <span style="font-size: 0.75rem; color: var(--gray);">
                                                (<?= implode(', ', array_column($friend['badges'], 'name')) ?>)
                                            </span>
                                        <?php endif; ?>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-plus-circle"></i> 创建群组
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- 搜索用户页面 -->
            <div id="search" class="content-section <?= $action === 'search' ? 'active' : '' ?>">
                <div class="card">
                    <h2><i class="bi bi-search"></i> 搜索用户</h2>
                    
                    <form method="get" class="search-form">
                        <input type="hidden" name="action" value="search">
                        <div class="form-group" style="flex: 1;">
                            <input type="text" name="search" placeholder="输入用户名或邮箱" 
                                   value="<?= htmlspecialchars($searchTerm) ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search"></i> 搜索
                        </button>
                    </form>
                    
                    <?php if (!empty($searchTerm)): ?>
                        <div class="search-results">
                            <h3 class="search-title">搜索结果</h3>
                            <div class="user-list">
                                <?php if (!empty($searchResults)): ?>
                                    <?php foreach ($searchResults as $user): ?>
                                        <div class="user-item">
                                            <div class="avatar"><?= mb_substr($user['username'], 0, 1) ?></div>
                                            <div class="user-info">
                                                <div class="user-name"><?= htmlspecialchars($user['username']) ?></div>
                                                <div class="user-meta"><?= htmlspecialchars($user['email']) ?></div>
                                                <?php if (!empty($user['badges'])): ?>
                                                    <div class="badges">
                                                        <?php foreach ($user['badges'] as $badge): ?>
                                                            <span class="badge"><?= htmlspecialchars($badge['name']) ?></span>
                                                        <?php endforeach; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <?php if (!isFriend($currentUser['id'], $user['id'])): ?>
                                                <form method="post">
                                                    <input type="hidden" name="action" value="add_friend">
                                                    <input type="hidden" name="friend_id" value="<?= $user['id'] ?>">
                                                    <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class="bi bi-person-plus"></i> 添加好友
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <span>已是好友</span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="no-results">
                                        <i class="bi bi-search"></i>
                                        <p>未找到匹配的用户</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- 底部导航栏 -->
    <nav class="bottom-nav">
        <div class="nav-items">
            <a href="?action=messages" class="nav-item <?= $action === 'messages' ? 'active' : '' ?>">
                <i class="bi bi-chat-left-text"></i>
                <span>消息</span>
                <?php if ($unreadCount > 0): ?>
                    <span class="nav-badge"><?= $unreadCount > 9 ? '9+' : $unreadCount ?></span>
                <?php endif; ?>
            </a>
            <a href="?action=friends" class="nav-item <?= $action === 'friends' ? 'active' : '' ?>">
                <i class="bi bi-people"></i>
                <span>好友</span>
            </a>
            <a href="?action=groups" class="nav-item <?= $action === 'groups' ? 'active' : '' ?>">
                <i class="bi bi-collection"></i>
                <span>群组</span>
            </a>
            <a href="?action=search" class="nav-item <?= $action === 'search' ? 'active' : '' ?>">
                <i class="bi bi-search"></i>
                <span>搜索</span>
            </a>
            <a href="profile.php" class="nav-item">
                <i class="bi bi-person"></i>
                <span>我的</span>
            </a>
        </div>
    </nav>

    <script>
        function showSection(sectionId) {
            // 隐藏所有内容区域
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.remove('active');
            });
            
            // 显示选中的内容区域
            document.getElementById(sectionId).classList.add('active');
            
            // 更新标签状态
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            event.currentTarget.classList.add('active');
            
            // 更新URL
            const url = new URL(window.location);
            url.searchParams.set('action', sectionId);
            window.history.pushState({}, '', url);
        }
        
        // 自动滚动到消息底部
        const messageContainer = document.querySelector('.message-container');
        if (messageContainer) {
            messageContainer.scrollTop = messageContainer.scrollHeight;
        }
        
        // 更新文件名显示
        function updateFileName() {
            const fileInput = document.getElementById('attachment');
            const fileNameDisplay = document.getElementById('file-name');
            
            if (fileInput.files.length > 0) {
                fileNameDisplay.textContent = `已选择: ${fileInput.files[0].name}`;
            } else {
                fileNameDisplay.textContent = '';
            }
        }
        
        // 拖放文件支持
        document.addEventListener('DOMContentLoaded', function() {
            const fileInput = document.querySelector('.file-input');
            
            fileInput.addEventListener('dragover', function(e) {
                e.preventDefault();
                this.style.borderColor = 'var(--primary)';
                this.style.background = 'rgba(255, 133, 162, 0.1)';
            });
            
            fileInput.addEventListener('dragleave', function(e) {
                e.preventDefault();
                this.style.borderColor = '#e0e0e0';
                this.style.background = '';
            });
            
            fileInput.addEventListener('drop', function(e) {
                e.preventDefault();
                this.style.borderColor = '#e0e0e0';
                this.style.background = '';
                
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    document.getElementById('attachment').files = files;
                    updateFileName();
                }
            });
        });
        
        // 页面加载时初始化
        document.addEventListener('DOMContentLoaded', function() {
            // 如果URL中有搜索参数，自动激活搜索页面
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('action') === 'search') {
                showSection('search');
            }
            
            // 检测屏幕宽度，调整布局
            function checkScreenSize() {
                if (window.innerWidth < 768) {
                    document.body.classList.add('mobile');
                } else {
                    document.body.classList.remove('mobile');
                }
            }
            
            // 初始检查
            checkScreenSize();
            
            // 窗口大小变化时检查
            window.addEventListener('resize', checkScreenSize);
        });
    </script>
</body>
</html>

<?php
/**
 * 格式化文件大小
 */
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}
?>