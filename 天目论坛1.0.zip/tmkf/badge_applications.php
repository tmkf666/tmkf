<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// 检查管理员权限
if (!isAdmin(getCurrentUserId())) {
    header('HTTP/1.0 403 Forbidden');
    exit('无权访问');
}

$currentUser = getCurrentUser();
$applications = getPendingBadgeApplications();
$error = '';
$success = '';

// 处理申请
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $applicationId = $_POST['application_id'];
    $action = $_POST['action'];
    
    if (processBadgeApplication($applicationId, $action, $currentUser['id'])) {
        $success = '申请已处理';
        $applications = getPendingBadgeApplications(); // 刷新列表
    } else {
        $error = '处理申请时出错';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>头衔申请审核 - <?= htmlspecialchars(getSettings()['site_title']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        /* 使用与主站相同的CSS变量和基础样式 */
        :root {
            --primary: #ff85a2;
            --secondary: #9b5de5;
            --success: #00f5d4;
            --danger: #f72585;
            --warning: #ffd166;
            --light: #fff9fb;
            --dark: #4a4a4a;
            --gray: #a0a0a0;
            --border-radius: 16px;
            --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15);
            --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }
        
        body {
            font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
            min-height: 100vh;
            padding: 2rem;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 2rem;
            border: 1px solid rgba(255, 133, 162, 0.1);
        }
        
        h1 {
            color: var(--primary);
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .application-card {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--warning);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        
        .application-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .user-avatar img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255, 133, 162, 0.3);
        }
        
        .user-name {
            font-weight: 600;
        }
        
        .badge-name {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--primary);
        }
        
        .application-content {
            margin: 1.5rem 0;
        }
        
        .application-reason {
            background-color: rgba(255, 255, 255, 0.5);
            padding: 1rem;
            border-radius: var(--border-radius);
            margin-top: 1rem;
        }
        
        .application-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            gap: 0.5rem;
            font-size: 0.9rem;
        }
        
        .btn-approve {
            background: linear-gradient(135deg, var(--success) 0%, #00cc99 100%);
            color: white;
        }
        
        .btn-reject {
            background: linear-gradient(135deg, var(--danger) 0%, #e01a4f 100%);
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        
        .no-applications {
            text-align: center;
            padding: 3rem;
            color: var(--gray);
        }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .alert.error {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--danger);
        }
        
        .alert.success {
            background-color: rgba(0, 245, 212, 0.1);
            color: var(--success);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1><i class="bi bi-award"></i> 头衔申请审核</h1>
        
        <?php if ($error): ?>
            <div class="alert error">
                <i class="bi bi-exclamation-circle"></i> <?= $error ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert success">
                <i class="bi bi-check-circle"></i> <?= $success ?>
            </div>
        <?php endif; ?>
        
        <?php if ($applications): ?>
            <?php foreach ($applications as $app): ?>
                <?php $user = getUser($app['user_id']); ?>
                <div class="application-card">
                    <div class="application-header">
                        <div class="user-info">
                            <div class="user-avatar">
                                <img src="../images/<?= $user['avatar'] ?>" alt="<?= $user['username'] ?>">
                            </div>
                            <div class="user-name"><?= htmlspecialchars($user['username']) ?></div>
                        </div>
                        
                        <div class="badge-name"><?= htmlspecialchars($app['badge_name']) ?></div>
                    </div>
                    
                    <div class="application-content">
                        <div><strong>申请时间:</strong> <?= $app['created_at'] ?></div>
                        
                        <div class="application-reason">
                            <strong>申请理由:</strong>
                            <p><?= nl2br(htmlspecialchars($app['reason'])) ?></p>
                        </div>
                    </div>
                    
                    <div class="application-actions">
                        <form action="" method="post">
                            <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                            <input type="hidden" name="action" value="approved">
                            <button type="submit" class="btn btn-approve">
                                <i class="bi bi-check-circle"></i> 批准
                            </button>
                        </form>
                        
                        <form action="" method="post">
                            <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                            <input type="hidden" name="action" value="rejected">
                            <button type="submit" class="btn btn-reject">
                                <i class="bi bi-x-circle"></i> 拒绝
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="no-applications">
                <i class="bi bi-check2-circle" style="font-size: 3rem; color: var(--success);"></i>
                <p>没有待处理的头衔申请</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>