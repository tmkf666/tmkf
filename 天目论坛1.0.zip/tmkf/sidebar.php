<?php
// admin/sidebar.php
$currentPage = basename($_SERVER['PHP_SELF']);
$unapprovedPosts = count(array_filter(readData(POSTS_FILE), fn($post) => isset($post['is_approved']) && !$post['is_approved']));
$unapprovedComments = count(array_filter(readData(COMMENTS_FILE), fn($comment) => isset($comment['is_hidden']) && $comment['is_hidden']));
?>
<div class="container-fluid">
    <div class="row">
        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse">
            <div class="position-sticky pt-3">
                <div class="sidebar-header">
                    <div class="logo">
                        <i class="bi bi-chat-square-heart"></i>
                        <span><?= htmlspecialchars(getSettings()['site_title']) ?></span>
                    </div>
                    <p class="welcome">欢迎回来，管理员</p>
                </div>
                
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage === 'index.php' ? 'active' : '' ?>" href="index.php">
                            <div class="nav-icon">
                                <i class="bi bi-speedometer2"></i>
                            </div>
                            <span class="nav-text">控制面板</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage === 'posts.php' ? 'active' : '' ?>" href="posts.php">
                            <div class="nav-icon">
                                <i class="bi bi-file-earmark-text"></i>
                                <?php if ($unapprovedPosts > 0): ?>
                                <span class="badge"><?= $unapprovedPosts ?></span>
                                <?php endif; ?>
                            </div>
                            <span class="nav-text">帖子管理</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage === 'comments.php' ? 'active' : '' ?>" href="comments.php">
                            <div class="nav-icon">
                                <i class="bi bi-chat-left-text"></i>
                                <?php if ($unapprovedComments > 0): ?>
                                <span class="badge"><?= $unapprovedComments ?></span>
                                <?php endif; ?>
                            </div>
                            <span class="nav-text">评论管理</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage === 'users.php' ? 'active' : '' ?>" href="users.php">
                            <div class="nav-icon">
                                <i class="bi bi-people"></i>
                            </div>
                            <span class="nav-text">用户管理</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage === 'categories.php' ? 'active' : '' ?>" href="categories.php">
                            <div class="nav-icon">
                                <i class="bi bi-tags"></i>
                            </div>
                            <span class="nav-text">板块管理</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage === 'settings.php' ? 'active' : '' ?>" href="settings.php">
                            <div class="nav-icon">
                                <i class="bi bi-gear"></i>
                            </div>
                            <span class="nav-text">系统设置</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage === 'maintenance.php' ? 'active' : '' ?>" href="maintenance.php">
                            <div class="nav-icon">
                                <i class="bi bi-tools"></i>
                                <?php if (getMaintenanceSettings()['enabled']): ?>
                                <span class="badge warning">
                                    <i class="bi bi-exclamation-triangle"></i>
                                </span>
                                <?php endif; ?>
                            </div>
                            <span class="nav-text">系统维护</span>
                        </a>
                    </li>
                </ul>

                <div class="quick-actions">
                    <h6 class="section-title">快捷操作</h6>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="posts.php?action=create">
                                <div class="nav-icon">
                                    <i class="bi bi-plus-circle"></i>
                                </div>
                                <span class="nav-text">新建帖子</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="users.php?action=create">
                                <div class="nav-icon">
                                    <i class="bi bi-person-plus"></i>
                                </div>
                                <span class="nav-text">添加用户</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="categories.php?action=create">
                                <div class="nav-icon">
                                    <i class="bi bi-plus-square"></i>
                                </div>
                                <span class="nav-text">新增板块</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        
        <style>
            /* 侧边栏样式 - 动漫风格 */
            #sidebarMenu {
                background: linear-gradient(135deg, #ffffff 0%, #fff9fb 100%);
                box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15);
                border-right: 1px solid rgba(255, 133, 162, 0.1);
                min-height: 100vh;
                padding: 1rem;
                position: relative;
                overflow: hidden;
            }
            
            #sidebarMenu::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                width: 4px;
                height: 100%;
                background: linear-gradient(to bottom, #ff85a2 0%, #9b5de5 100%);
            }
            
            .sidebar-header {
                padding: 1rem 0 1.5rem;
                border-bottom: 1px solid rgba(255, 133, 162, 0.1);
                margin-bottom: 1rem;
            }
            
            .sidebar-header .logo {
                display: flex;
                align-items: center;
                gap: 0.75rem;
                font-size: 1.25rem;
                font-weight: 600;
                color: #4a4a4a;
            }
            
            .sidebar-header .logo i {
                font-size: 1.5rem;
                color: #ff85a2;
                background: rgba(255, 133, 162, 0.1);
                padding: 0.5rem;
                border-radius: 50%;
            }
            
            .sidebar-header .welcome {
                color: #a0a0a0;
                font-size: 0.9rem;
                margin-top: 0.5rem;
                padding-left: 2.5rem;
            }
            
            .nav {
                margin-bottom: 1.5rem;
            }
            
            .nav-item {
                margin-bottom: 0.5rem;
            }
            
            .nav-link {
                display: flex;
                align-items: center;
                padding: 0.75rem 1rem;
                border-radius: 12px;
                color: #4a4a4a;
                transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                position: relative;
                overflow: hidden;
            }
            
            .nav-link:hover:not(.active) {
                background: rgba(255, 133, 162, 0.1);
                transform: translateX(5px);
            }
            
            .nav-link.active {
                background: linear-gradient(135deg, #ff85a2 0%, #9b5de5 100%);
                color: white;
                box-shadow: 0 4px 10px rgba(155, 93, 229, 0.3);
            }
            
            .nav-icon {
                width: 36px;
                height: 36px;
                display: flex;
                align-items: center;
                justify-content: center;
                background: rgba(255, 133, 162, 0.1);
                border-radius: 50%;
                margin-right: 0.75rem;
                position: relative;
            }
            
            .nav-link.active .nav-icon {
                background: rgba(255, 255, 255, 0.2);
            }
            
            .nav-icon i {
                font-size: 1.1rem;
                color: #ff85a2;
            }
            
            .nav-link.active .nav-icon i {
                color: white;
            }
            
            .nav-text {
                font-weight: 500;
            }
            
            .badge {
                position: absolute;
                top: -8px;
                right: -8px;
                width: 20px;
                height: 20px;
                border-radius: 50%;
                background: #f72585;
                color: white;
                font-size: 0.7rem;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: bold;
            }
            
            .badge.warning {
                background: #ffd166;
                color: #4a4a4a;
                width: 24px;
                height: 24px;
                font-size: 0.8rem;
            }
            
            .quick-actions {
                margin-top: 1.5rem;
                padding-top: 1.5rem;
                border-top: 1px solid rgba(255, 133, 162, 0.1);
            }
            
            .section-title {
                font-size: 0.85rem;
                text-transform: uppercase;
                letter-spacing: 1px;
                color: #9b5de5;
                margin-bottom: 1rem;
                padding: 0 1rem;
                font-weight: 600;
            }
            
            /* 响应式设计 */
            @media (max-width: 768px) {
                #sidebarMenu {
                    min-height: auto;
                    padding: 1rem 0.5rem;
                }
                
                .sidebar-header {
                    padding: 0.5rem 0 1rem;
                }
                
                .sidebar-header .logo {
                    font-size: 1.1rem;
                }
                
                .nav-link {
                    padding: 0.6rem 0.8rem;
                }
                
                .nav-icon {
                    width: 32px;
                    height: 32px;
                    margin-right: 0.5rem;
                }
            }
        </style>
