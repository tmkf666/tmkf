<?php
// 自动检测配置文件路径 - 修复open_basedir限制问题
function findConfigFile() {
    $possible_paths = [
        __DIR__ . '/includes/config.php',
        __DIR__ . '/../includes/config.php',
        __DIR__ . '/../../includes/config.php',
        './includes/config.php',
        '../includes/config.php',
        '../../includes/config.php'
    ];
    
    foreach ($possible_paths as $path) {
        // 将路径转换为绝对路径并检查是否在允许的目录内
        $realPath = realpath($path);
        if ($realPath !== false && file_exists($realPath)) {
            // 检查路径是否在允许的目录内
            $allowedDirs = ['/www/wwwroot/mnbt.7062184a5/', '/tmp/'];
            foreach ($allowedDirs as $allowedDir) {
                if (strpos($realPath, $allowedDir) === 0) {
                    return $realPath;
                }
            }
        }
    }
    
    // 尝试使用DOCUMENT_ROOT作为备选
    if (isset($_SERVER['DOCUMENT_ROOT'])) {
        $docRootPath = $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
        if (file_exists($docRootPath)) {
            return $docRootPath;
        }
    }
    
    return null;
}

$config_path = findConfigFile();
if ($config_path === null) {
    die('错误：找不到配置文件 config.php，请检查文件路径');
}

require_once $config_path;

// 引入其他必要文件
$base_dir = dirname($config_path);
require_once $base_dir . '/auth.php';
require_once $base_dir . '/functions.php';

// 检查用户是否登录且是管理员
if (!isLoggedIn() || !isAdmin(getCurrentUserId())) {
    header('Location: ../../index.php');
    exit;
}

$currentUser = getCurrentUser();
$users = getUsers();
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;

// 分页
$total = count($users);
$offset = ($page - 1) * $perPage;
$users = array_slice($users, $offset, $perPage);
$totalPages = ceil($total / $perPage);

// 处理用户操作
if (isset($_GET['action']) && isset($_GET['user_id'])) {
    $userId = intval($_GET['user_id']);
    
    // 防止当前用户修改自己的权限
    if ($userId === $currentUser['id']) {
        $_SESSION['error_message'] = '不能修改自己的权限状态';
        header('Location: users.php');
        exit;
    }
    
    switch ($_GET['action']) {
        case 'ban':
            banUser($userId);
            $_SESSION['success_message'] = '用户已封禁';
            break;
        case 'unban':
            unbanUser($userId);
            $_SESSION['success_message'] = '用户已解封';
            break;
        case 'make_admin':
            setAdmin($userId, true);
            $_SESSION['success_message'] = '用户已设为管理员';
            break;
        case 'remove_admin':
            setAdmin($userId, false);
            $_SESSION['success_message'] = '用户已取消管理员权限';
            break;
    }
    
    header('Location: users.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户管理 - <?= htmlspecialchars(getSettings()['site_title']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #ff85a2; /* 粉色主色调 */
            --primary-light: #ffb6c1; /* 浅粉色 */
            --primary-dark: #e75480; /* 深粉色 */
            --secondary: #9b5de5; /* 紫色 */
            --accent: #00bbf9; /* 蓝色 */
            --light: #fff9fb; /* 浅粉色背景 */
            --dark: #4a4a4a; /* 深灰色 */
            --gray: #a0a0a0; /* 灰色 */
            --success: #00f5d4; /* 青色 */
            --danger: #f72585; /* 红色 */
            --warning: #ffd166; /* 黄色 */
            --border-radius: 16px; /* 更大的圆角 */
            --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15); /* 柔和阴影 */
            --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94); /* 平滑过渡 */
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .container {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        
        /* 头部样式 - 动漫风格 */
        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1.5rem;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .logo i {
            font-size: 1.75rem;
            color: #fff;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem;
            border-radius: 50%;
        }
        
        nav ul {
            display: flex;
            gap: 0.5rem;
            list-style: none;
        }
        
        nav ul li a {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        nav ul li a:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        
        nav ul li a.active {
            background: rgba(255, 255, 255, 0.3);
            box-shadow: 0 4px 10px rgba(155, 93, 229, 0.3);
        }
        
        nav ul li a i {
            font-size: 1.1rem;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        main {
            flex: 1;
            padding: 1.5rem 0;
        }
        
        /* 管理面板卡片 - 动漫风格 */
        .admin-content {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            border: 1px solid rgba(255, 133, 162, 0.1);
            position: relative;
        }
        
        .admin-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 50%, var(--accent) 100%);
        }
        
        .admin-header {
            padding: 2rem;
        }
        
        .admin-header h2 {
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .no-data {
            padding: 3rem;
            text-align: center;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            border: 1px solid rgba(255, 133, 162, 0.1);
            background-color: white;
            margin: 2rem;
        }
        
        .no-data i {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }
        
        .no-data p {
            color: var(--gray);
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
        }
        
        .admin-table {
            padding: 0 2rem 2rem;
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 10px;
            font-size: 0.95rem;
        }
        
        thead th {
            background-color: rgba(255, 133, 162, 0.1);
            padding: 1rem 1.25rem;
            text-align: left;
            font-weight: 600;
            color: var(--dark);
            white-space: nowrap;
            border-bottom: 2px solid var(--primary);
        }
        
        tbody tr {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: var(--transition);
            cursor: pointer;
            border: 1px solid rgba(255, 133, 162, 0.1);
            position: relative;
        }
        
        tbody tr::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary) 0%, var(--secondary) 100%);
            border-radius: var(--border-radius) 0 0 var(--border-radius);
        }
        
        tbody tr:hover {
            border-color: rgba(255, 133, 162, 0.3);
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(255, 133, 162, 0.15);
        }
        
        td {
            padding: 1rem 1.25rem;
            text-align: left;
            border-bottom: none;
            vertical-align: middle;
        }
        
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.85rem;
            font-weight: 500;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .badge.admin {
            background: linear-gradient(135deg, var(--success) 0%, #00cc99 100%);
            color: white;
        }
        
        .badge.banned {
            background: linear-gradient(135deg, var(--danger) 0%, #e01a4f 100%);
            color: white;
        }
        
        .current-user {
            color: var(--gray);
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .actions {
            display: flex;
            gap: 0.5rem;
            white-space: nowrap;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem 1rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border: none;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            gap: 0.5rem;
            font-size: 0.9rem;
            box-shadow: 0 4px 10px rgba(155, 93, 229, 0.3);
            text-decoration: none;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn-small {
            padding: 0.4rem 0.8rem;
            font-size: 0.85rem;
        }
        
        .btn-view {
            background: linear-gradient(135deg, var(--accent) 0%, #0099cc 100%);
        }
        
        .btn-delete {
            background: linear-gradient(135deg, var(--danger) 0%, #e01a4f 100%);
        }
        
        .btn-warning {
            background: linear-gradient(135deg, var(--warning) 0%, #ffb700 100%);
            color: var(--dark);
        }
        
        .btn-success {
            background: linear-gradient(135deg, var(--success) 0%, #00cc99 100%);
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }
        
        .pagination a {
            padding: 0.75rem 1.25rem;
            background-color: white;
            border: 1px solid #e0e0e0;
            border-radius: var(--border-radius);
            color: var(--primary);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            text-decoration: none;
        }
        
        .pagination a.active {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border-color: transparent;
        }
        
        .pagination a:hover:not(.active) {
            background-color: #f8f9fa;
            transform: translateY(-2px);
        }
        
        footer {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            text-align: center;
            padding: 2rem 0;
            margin-top: 3rem;
            border-top: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        footer p {
            opacity: 0.9;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        }
        
        /* 消息提示 */
        .alert {
            padding: 1rem;
            margin: 1rem 2rem;
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            gap: 1rem;
            box-shadow: var(--box-shadow);
        }
        
        .alert-success {
            background: linear-gradient(135deg, var(--success) 0%, #00cc99 100%);
            color: white;
        }
        
        .alert-error {
            background: linear-gradient(135deg, var(--danger) 0%, #e01a4f 100%);
            color: white;
        }
        
        .alert i {
            font-size: 1.5rem;
        }
        
        /* 底部导航栏 - 移动端 */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 133, 162, 0.2);
            padding: 0.75rem 0;
            display: none;
            z-index: 1000;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .nav-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
            padding: 0.5rem;
            border-radius: 50px;
            transition: var(--transition);
            color: var(--gray);
        }
        
        .nav-item.active {
            color: var(--primary);
        }
        
        .nav-item i {
            font-size: 1.25rem;
            background: rgba(255, 133, 162, 0.1);
            width: 2.5rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .nav-item.active i {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 10px rgba(255, 133, 162, 0.3);
        }
        
        .nav-item span {
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        /* 响应式设计 */
        @media (max-width: 992px) {
            .admin-table {
                padding: 0 1.5rem 1.5rem;
            }
            
            table {
                min-width: 800px;
            }
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: row;
                align-items: center;
                flex-wrap: wrap;
            }
            
            .logo {
                order: 1;
                flex: 1;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            .mobile-menu-btn {
                display: block;
                order: 2;
            }
            
            nav {
                order: 4;
                width: 100%;
                display: none;
                margin-top: 1rem;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .admin-header {
                padding: 1.5rem;
            }
            
            .admin-header h2 {
                font-size: 1.5rem;
            }
            
            .admin-table {
                padding: 0 1rem 1rem;
            }
            
            .actions {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            /* 显示底部导航 */
            .bottom-nav {
                display: block;
            }
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 0 1rem;
            }
            
            .admin-header {
                padding: 1.25rem;
            }
            
            .pagination a {
                padding: 0.6rem 1rem;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <a href="../../index.php" class="logo">
                    <i class="bi bi-chat-square-heart"></i>
                    <span><?= htmlspecialchars(getSettings()['site_title']) ?></span>
                </a>
                
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="bi bi-list"></i>
                </button>
                
                <nav id="mainNav">
                    <ul>
                        <li><a href="../../index.php"><i class="bi bi-house"></i> 返回论坛</a></li>
                        <li><a href="index.php"><i class="bi bi-speedometer2"></i> 管理首页</a></li>
                        <li><a href="users.php" class="active"><i class="bi bi-people"></i> 用户管理</a></li>
                        <li><a href="posts.php"><i class="bi bi-file-text"></i> 帖子管理</a></li>
                        <li><a href="comments.php"><i class="bi bi-chat-left-text"></i> 评论管理</a></li>
                        <li><a href="../logout.php"><i class="bi bi-box-arrow-right"></i> 退出</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="admin-content">
            <div class="admin-header">
                <h2><i class="bi bi-people"></i> 用户管理</h2>
                <p>共 <?= $total ?> 位用户，当前显示第 <?= $offset + 1 ?> - <?= min($offset + $perPage, $total) ?> 位</p>
            </div>
            
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <i class="bi bi-check-circle"></i>
                    <p><?= $_SESSION['success_message'] ?></p>
                </div>
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-error">
                    <i class="bi bi-exclamation-circle"></i>
                    <p><?= $_SESSION['error_message'] ?></p>
                </div>
                <?php unset($_SESSION['error_message']); ?>
            <?php endif; ?>
            
            <?php if (empty($users)): ?>
                <div class="no-data">
                    <i class="bi bi-person-x"></i>
                    <p>暂无用户数据</p>
                </div>
            <?php else: ?>
                <div class="admin-table">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>用户名</th>
                                <th>邮箱</th>
                                <th>注册时间</th>
                                <th>状态</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?= $user['id'] ?></td>
                                    <td>
                                        <a href="../../profile.php?username=<?= urlencode($user['username']) ?>" class="text-link">
                                            <?= htmlspecialchars($user['username']) ?>
                                        </a>
                                    </td>
                                    <td><?= htmlspecialchars($user['email']) ?></td>
                                    <td><?= $user['created_at'] ?></td>
                                    <td>
                                        <?php if ($user['is_admin']): ?>
                                            <span class="badge admin"><i class="bi bi-shield-check"></i> 管理员</span>
                                        <?php endif; ?>
                                        <?php if ($user['is_banned']): ?>
                                            <span class="badge banned"><i class="bi bi-slash-circle"></i> 已封禁</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="actions">
                                        <?php if ($user['id'] != $currentUser['id']): ?>
                                            <?php if ($user['is_banned']): ?>
                                                <a href="users.php?action=unban&user_id=<?= $user['id'] ?>" class="btn btn-small btn-success">
                                                    <i class="bi bi-unlock"></i> 解封
                                                </a>
                                            <?php else: ?>
                                                <a href="users.php?action=ban&user_id=<?= $user['id'] ?>" class="btn btn-small btn-delete">
                                                    <i class="bi bi-lock"></i> 封禁
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if ($user['is_admin']): ?>
                                                <a href="users.php?action=remove_admin&user_id=<?= $user['id'] ?>" class="btn btn-small btn-warning">
                                                    <i class="bi bi-person-dash"></i> 取消管理员
                                                </a>
                                            <?php else: ?>
                                                <a href="users.php?action=make_admin&user_id=<?= $user['id'] ?>" class="btn btn-small btn-success">
                                                    <i class="bi bi-person-plus"></i> 设为管理员
                                                </a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="current-user"><i class="bi bi-person-check"></i> 当前用户</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php if ($totalPages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?= $page - 1 ?>">
                                <i class="bi bi-chevron-left"></i> 上一页
                            </a>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <a href="?page=<?= $i ?>" <?= $i == $page ? 'class="active"' : '' ?>>
                                <?= $i ?>
                            </a>
                        <?php endfor; ?>
                        
                        <?php if ($page < $totalPages): ?>
                            <a href="?page=<?= $page + 1 ?>">
                                下一页 <i class="bi bi-chevron-right"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </main>

    <!-- 底部导航栏 -->
    <nav class="bottom-nav">
        <div class="nav-items">
            <a href="../../index.php" class="nav-item">
                <i class="bi bi-house"></i>
                <span>论坛</span>
            </a>
            <a href="index.php" class="nav-item">
                <i class="bi bi-speedometer2"></i>
                <span>管理</span>
            </a>
            <a href="users.php" class="nav-item active">
                <i class="bi bi-people"></i>
                <span>用户</span>
            </a>
            <a href="posts.php" class="nav-item">
                <i class="bi bi-file-text"></i>
                <span>帖子</span>
            </a>
        </div>
    </nav>

    <footer>
        <div class="container">
            <p>Copyright © <?= date('Y') ?> <?= htmlspecialchars(getSettings()['site_title']) ?> - 二次元管理后台</p>
        </div>
    </footer>

    <script>
        // 移动端菜单切换
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            
            // 切换图标
            const icon = this.querySelector('i');
            if (mainNav.classList.contains('active')) {
                icon.classList.remove('bi-list');
                icon.classList.add('bi-x');
            } else {
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        });
        
        // 用户行点击事件
        document.querySelectorAll('tbody tr').forEach(row => {
            row.addEventListener('click', function(e) {
                // 如果点击的是操作按钮，则不处理
                if (e.target.closest('.actions')) return;
                
                // 否则跳转到用户详情页
                const userId = this.querySelector('td:first-child').textContent;
                window.location.href = `../../profile.php?user_id=${userId}`;
            });
        });
        
        // 操作确认对话框
        document.querySelectorAll('.btn-delete, .btn-warning').forEach(btn => {
            btn.addEventListener('click', function(e) {
                const action = this.textContent.trim();
                if (!confirm(`确定要${action}该用户吗？此操作无法撤销！`)) {
                    e.preventDefault();
                }
            });
        });
        
        // 添加页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            document.body.style.opacity = '0';
            setTimeout(() => {
                document.body.style.transition = 'opacity 0.3s ease';
                document.body.style.opacity = '1';
            }, 100);
        });
        
        // 根据屏幕宽度自动调整布局
        function handleResponsive() {
            if (window.innerWidth > 768) {
                mainNav.classList.remove('active');
                const icon = mobileMenuBtn.querySelector('i');
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        }
        
        window.addEventListener('resize', handleResponsive);
        handleResponsive();
    </script>
</body>
</html>
