<?php
// 设置根目录路径
$rootPath = dirname(dirname(__FILE__));

// 检查并引入文件
$required_files = [
    $rootPath . '/includes/config.php',
    $rootPath . '/includes/auth.php',
    $rootPath . '/includes/functions.php'
];

foreach ($required_files as $file) {
    if (!file_exists($file)) {
        die("<h2>系统文件缺失</h2><p>找不到文件: " . basename($file) . "</p>");
    }
    require_once $file;
}

// 检查用户是否登录且是管理员
if (!isLoggedIn()) {
    header('Location: ' . $rootPath . '/login.php');
    exit;
}

if (!isAdmin(getCurrentUserId())) {
    die("<script>alert('您没有管理员权限！');history.back();</script>");
}

$currentUser = getCurrentUser();

// 获取统计数据
$userCount = count(getUsers());
$postCount = count(readData(POSTS_FILE));
$commentCount = count(readData(COMMENTS_FILE));
$today = date('Y-m-d');
$todayPosts = count(array_filter(readData(POSTS_FILE), function($post) use ($today) {
    return substr($post['created_at'], 0, 10) === $today;
}));
$todayComments = count(array_filter(readData(COMMENTS_FILE), function($comment) use ($today) {
    return substr($comment['created_at'], 0, 10) === $today;
}));
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 - <?= htmlspecialchars(getSettings()['site_title']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #ff85a2; /* 粉色主色调 */
            --primary-light: #ffb6c1; /* 浅粉色 */
            --primary-dark: #e75480; /* 深粉色 */
            --secondary: #9b5de5; /* 紫色 */
            --accent: #00bbf9; /* 蓝色 */
            --light: #fff9fb; /* 浅粉色背景 */
            --dark: #4a4a4a; /* 深灰色 */
            --gray: #a0a0a0; /* 灰色 */
            --success: #00f5d4; /* 青色 */
            --danger: #f72585; /* 红色 */
            --warning: #ffd166; /* 黄色 */
            --border-radius: 16px; /* 更大的圆角 */
            --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15); /* 柔和阴影 */
            --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94); /* 平滑过渡 */
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .container {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        
        /* 头部样式 - 动漫风格 */
        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1.5rem;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .logo i {
            font-size: 1.75rem;
            color: #fff;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem;
            border-radius: 50%;
        }
        
        nav ul {
            display: flex;
            gap: 0.5rem;
            list-style: none;
        }
        
        nav ul li a {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        nav ul li a:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        
        nav ul li a.active {
            background: rgba(255, 255, 255, 0.3);
            box-shadow: 0 4px 10px rgba(155, 93, 229, 0.3);
        }
        
        nav ul li a i {
            font-size: 1.1rem;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        main {
            flex: 1;
            padding: 1.5rem 0;
        }
        
        /* 管理面板卡片 - 动漫风格 */
        .admin-dashboard {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            border: 1px solid rgba(255, 133, 162, 0.1);
            position: relative;
        }
        
        .admin-dashboard::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 50%, var(--accent) 100%);
        }
        
        .dashboard-header {
            padding: 2rem;
        }
        
        .dashboard-header h2 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .welcome-message {
            color: var(--gray);
            font-size: 1.1rem;
        }
        
        .admin-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 0 2rem 2rem;
        }
        
        .stat-card {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            transition: var(--transition);
            cursor: pointer;
            border: 1px solid rgba(255, 133, 162, 0.1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary) 0%, var(--secondary) 100%);
            border-radius: var(--border-radius) 0 0 var(--border-radius);
        }
        
        .stat-card:hover {
            border-color: rgba(255, 133, 162, 0.3);
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(255, 133, 162, 0.15);
        }
        
        .stat-card h3 {
            font-size: 1rem;
            color: var(--gray);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .stat-card .stat-value {
            font-size: 2.2rem;
            font-weight: bold;
            color: var(--dark);
            margin-bottom: 0.5rem;
        }
        
        .stat-card .stat-change {
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .stat-card .stat-change.positive {
            color: var(--success);
        }
        
        .stat-card .stat-change.negative {
            color: var(--danger);
        }
        
        .admin-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            padding: 0 2rem 2rem;
        }
        
        .action-card {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            transition: var(--transition);
            text-align: center;
            border: 1px solid rgba(255, 133, 162, 0.1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: relative;
        }
        
        .action-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 100%);
        }
        
        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(255, 133, 162, 0.15);
        }
        
        .action-card i {
            font-size: 2.5rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 1rem;
        }
        
        .action-card h3 {
            margin-bottom: 0.75rem;
            font-size: 1.25rem;
            color: var(--dark);
        }
        
        .action-card p {
            color: var(--gray);
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.75rem 1.5rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border: none;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            gap: 0.5rem;
            font-size: 1rem;
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.3);
            position: relative;
            overflow: hidden;
            text-decoration: none;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(155, 93, 229, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn-small {
            padding: 0.5rem 1.25rem;
            font-size: 0.9rem;
        }
        
        footer {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            text-align: center;
            padding: 2rem 0;
            margin-top: 3rem;
            border-top: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        footer p {
            opacity: 0.9;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        }
        
        /* 底部导航栏 - 移动端 */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 133, 162, 0.2);
            padding: 0.75rem 0;
            display: none;
            z-index: 1000;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .nav-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
            padding: 0.5rem;
            border-radius: 50px;
            transition: var(--transition);
            color: var(--gray);
        }
        
        .nav-item.active {
            color: var(--primary);
        }
        
        .nav-item i {
            font-size: 1.25rem;
            background: rgba(255, 133, 162, 0.1);
            width: 2.5rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .nav-item.active i {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 10px rgba(255, 133, 162, 0.3);
        }
        
        .nav-item span {
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        /* 响应式设计 */
        @media (max-width: 992px) {
            .admin-stats,
            .admin-actions {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: row;
                align-items: center;
                flex-wrap: wrap;
            }
            
            .logo {
                order: 1;
                flex: 1;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            .mobile-menu-btn {
                display: block;
                order: 2;
            }
            
            nav {
                order: 4;
                width: 100%;
                display: none;
                margin-top: 1rem;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .admin-stats,
            .admin-actions {
                grid-template-columns: 1fr;
            }
            
            .profile-content {
                padding: 1.5rem;
                margin-bottom: 4rem; /* 为底部导航留出空间 */
            }
            
            /* 显示底部导航 */
            .bottom-nav {
                display: block;
            }
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 0 1rem;
            }
            
            .dashboard-header {
                padding: 1.5rem;
            }
            
            .stat-card .stat-value {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <a href="<?= $rootPath ?>/index.php" class="logo">
                    <i class="bi bi-chat-square-heart"></i>
                    <span><?= htmlspecialchars(getSettings()['site_title']) ?></span>
                </a>
                
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="bi bi-list"></i>
                </button>
                
                <nav id="mainNav">
                    <ul>
                        <li><a href="<?= $rootPath ?>/index.php"><i class="bi bi-house"></i> 返回论坛</a></li>
                        <li><a href="index.php" class="active"><i class="bi bi-speedometer2"></i> 管理首页</a></li>
                        <li><a href="users.php"><i class="bi bi-people"></i> 用户管理</a></li>
                        <li><a href="posts.php"><i class="bi bi-file-text"></i> 帖子管理</a></li>
                        <li><a href="comments.php"><i class="bi bi-chat-left-text"></i> 评论管理</a></li>
                        <li><a href="<?= $rootPath ?>/logout.php"><i class="bi bi-box-arrow-right"></i> 退出</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="admin-dashboard">
            <div class="dashboard-header">
                <h2><i class="bi bi-speedometer2"></i> 管理后台</h2>
                <p class="welcome-message">欢迎回来，<?= htmlspecialchars($currentUser['username']) ?>！今天是 <?= date('Y年m月d日') ?></p>
            </div>
            
            <div class="admin-stats">
                <div class="stat-card">
                    <h3><i class="bi bi-people"></i> 用户总数</h3>
                    <div class="stat-value"><?= $userCount ?></div>
                    <div class="stat-change positive">
                        <i class="bi bi-arrow-up-right"></i>
                        <span>较昨日 +5%</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <h3><i class="bi bi-file-text"></i> 帖子总数</h3>
                    <div class="stat-value"><?= $postCount ?></div>
                    <div class="stat-change positive">
                        <i class="bi bi-arrow-up-right"></i>
                        <span>今日新增 <?= $todayPosts ?></span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <h3><i class="bi bi-chat-left-text"></i> 评论总数</h3>
                    <div class="stat-value"><?= $commentCount ?></div>
                    <div class="stat-change positive">
                        <i class="bi bi-arrow-up-right"></i>
                        <span>今日新增 <?= $todayComments ?></span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <h3><i class="bi bi-bar-chart"></i> 活跃度</h3>
                    <div class="stat-value">高</div>
                    <div class="stat-change positive">
                        <i class="bi bi-arrow-up-right"></i>
                        <span>较上周 +15%</span>
                    </div>
                </div>
            </div>
            
            <div class="admin-actions">
                <div class="action-card">
                    <i class="bi bi-people"></i>
                    <h3>用户管理</h3>
                    <p>管理所有注册用户，设置权限和状态</p>
                    <a href="users.php" class="btn btn-small"><i class="bi bi-arrow-right"></i> 进入</a>
                </div>
                
                <div class="action-card">
                    <i class="bi bi-file-text"></i>
                    <h3>帖子管理</h3>
                    <p>查看、编辑或删除论坛帖子</p>
                    <a href="posts.php" class="btn btn-small"><i class="bi bi-arrow-right"></i> 进入</a>
                </div>
                
                <div class="action-card">
                    <i class="bi bi-chat-left-text"></i>
                    <h3>评论管理</h3>
                    <p>管理所有用户评论内容</p>
                    <a href="comments.php" class="btn btn-small"><i class="bi bi-arrow-right"></i> 进入</a>
                </div>
                
                <div class="action-card">
                    <i class="bi bi-gear"></i>
                    <h3>系统设置</h3>
                    <p>配置论坛基本参数和功能</p>
                    <a href="settings.php" class="btn btn-small"><i class="bi bi-arrow-right"></i> 进入</a>
                </div>
            </div>
        </div>
    </main>

    <!-- 底部导航栏 -->
    <nav class="bottom-nav">
        <div class="nav-items">
            <a href="<?= $rootPath ?>/index.php" class="nav-item">
                <i class="bi bi-house"></i>
                <span>论坛</span>
            </a>
            <a href="index.php" class="nav-item active">
                <i class="bi bi-speedometer2"></i>
                <span>管理</span>
            </a>
            <a href="users.php" class="nav-item">
                <i class="bi bi-people"></i>
                <span>用户</span>
            </a>
            <a href="settings.php" class="nav-item">
                <i class="bi bi-gear"></i>
                <span>设置</span>
            </a>
        </div>
    </nav>

    <footer>
        <div class="container">
            <p>Copyright © <?= date('Y') ?> <?= htmlspecialchars(getSettings()['site_title']) ?> - 二次元管理后台</p>
        </div>
    </footer>

    <script>
        // 移动端菜单切换
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            
            // 切换图标
            const icon = this.querySelector('i');
            if (mainNav.classList.contains('active')) {
                icon.classList.remove('bi-list');
                icon.classList.add('bi-x');
            } else {
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        });
        
        // 卡片点击事件
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('click', function() {
                // 根据卡片类型跳转到不同页面
                const title = this.querySelector('h3').textContent;
                if (title.includes('用户')) {
                    window.location.href = 'users.php';
                } else if (title.includes('帖子')) {
                    window.location.href = 'posts.php';
                } else if (title.includes('评论')) {
                    window.location.href = 'comments.php';
                }
            });
        });
        
        // 添加页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            document.body.style.opacity = '0';
            setTimeout(() => {
                document.body.style.transition = 'opacity 0.3s ease';
                document.body.style.opacity = '1';
            }, 100);
        });
        
        // 根据屏幕宽度自动调整布局
        function handleResponsive() {
            if (window.innerWidth > 768) {
                mainNav.classList.remove('active');
                const icon = mobileMenuBtn.querySelector('i');
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        }
        
        window.addEventListener('resize', handleResponsive);
        handleResponsive();
    </script>
</body>
</html>