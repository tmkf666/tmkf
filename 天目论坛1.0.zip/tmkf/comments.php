<?php
// 设置根目录路径
$rootPath = dirname(dirname(__FILE__));

// 检查并引入文件
$required_files = [
    $rootPath . '/includes/config.php',
    $rootPath . '/includes/auth.php',
    $rootPath . '/includes/functions.php'
];

foreach ($required_files as $file) {
    if (!file_exists($file)) {
        die("<h2>系统文件缺失</h2><p>找不到文件: " . basename($file) . "</p>");
    }
    require_once $file;
}

// 检查用户是否登录且是管理员
if (!isLoggedIn() || !isAdmin(getCurrentUserId())) {
    header('Location: ' . $rootPath . '/login.php');
    exit;
}

$currentUser = getCurrentUser();

// 获取所有评论
$comments = readData(COMMENTS_FILE);
$posts = readData(POSTS_FILE);
$users = getUsers();

// 处理分页
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 15;
$total = count($comments);
$offset = ($page - 1) * $perPage;
$totalPages = ceil($total / $perPage);

// 处理评论操作
if (isset($_GET['action']) && isset($_GET['comment_id'])) {
    $commentId = intval($_GET['comment_id']);
    
    switch ($_GET['action']) {
        case 'delete':
            deleteComment($commentId);
            break;
        case 'hide':
            hideComment($commentId);
            break;
        case 'show':
            showComment($commentId);
            break;
    }
    
    header('Location: comments.php');
    exit;
}

// 批量操作
if (isset($_POST['bulk_action']) && isset($_POST['selected_comments'])) {
    $selectedComments = $_POST['selected_comments'];
    
    switch ($_POST['bulk_action']) {
        case 'delete':
            foreach ($selectedComments as $commentId) {
                deleteComment(intval($commentId));
            }
            break;
        case 'hide':
            foreach ($selectedComments as $commentId) {
                hideComment(intval($commentId));
            }
            break;
        case 'show':
            foreach ($selectedComments as $commentId) {
                showComment(intval($commentId));
            }
            break;
    }
    
    header('Location: comments.php');
    exit;
}

// 搜索功能
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
if ($search) {
    $filteredComments = [];
    foreach ($comments as $comment) {
        $content = strtolower($comment['content']);
        $author = strtolower(getUsernameById($comment['user_id']));
        $searchTerm = strtolower($search);
        
        if (strpos($content, $searchTerm) !== false || strpos($author, $searchTerm) !== false) {
            $filteredComments[] = $comment;
        }
    }
    $comments = $filteredComments;
    $total = count($comments);
    $totalPages = ceil($total / $perPage);
}

// 分页切片
$comments = array_slice($comments, $offset, $perPage);

// 辅助函数：通过用户ID获取用户名
function getUsernameById($userId) {
    $user = getUser($userId);
    return $user ? $user['username'] : '未知用户';
}

// 辅助函数：通过帖子ID获取帖子
function getPostById($postId) {
    return getPost($postId);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>评论管理 - <?= htmlspecialchars(getSettings()['site_title']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #ff85a2; /* 粉色主色调 */
            --primary-light: #ffb6c1; /* 浅粉色 */
            --primary-dark: #e75480; /* 深粉色 */
            --secondary: #9b5de5; /* 紫色 */
            --accent: #00bbf9; /* 蓝色 */
            --light: #fff9fb; /* 浅粉色背景 */
            --dark: #4a4a4a; /* 深灰色 */
            --gray: #a0a0a0; /* 灰色 */
            --success: #00f5d4; /* 青色 */
            --danger: #f72585; /* 红色 */
            --warning: #ffd166; /* 黄色 */
            --border-radius: 16px; /* 更大的圆角 */
            --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15); /* 柔和阴影 */
            --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94); /* 平滑过渡 */
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .container {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        
        /* 头部样式 - 动漫风格 */
        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1.5rem;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .logo i {
            font-size: 1.75rem;
            color: #fff;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem;
            border-radius: 50%;
        }
        
        nav ul {
            display: flex;
            gap: 0.5rem;
            list-style: none;
        }
        
        nav ul li a {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        nav ul li a:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        
        nav ul li a.active {
            background: rgba(255, 255, 255, 0.3);
            box-shadow: 0 4px 10px rgba(155, 93, 229, 0.3);
        }
        
        nav ul li a i {
            font-size: 1.1rem;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        main {
            flex: 1;
            padding: 1.5rem 0;
        }
        
        /* 管理面板卡片 - 动漫风格 */
        .admin-content {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            border: 1px solid rgba(255, 133, 162, 0.1);
            position: relative;
        }
        
        .admin-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 50%, var(--accent) 100%);
        }
        
        .admin-header {
            padding: 2rem;
        }
        
        .admin-header h2 {
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .admin-header p {
            color: var(--gray);
            font-size: 1rem;
        }
        
        .stats-info {
            background: rgba(255, 133, 162, 0.1);
            padding: 1rem;
            border-radius: var(--border-radius);
            margin: 0 2rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 0.95rem;
        }
        
        .stats-info i {
            font-size: 1.2rem;
            color: var(--primary);
        }
        
        .admin-toolbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 0 2rem 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .search-box {
            display: flex;
            gap: 0.75rem;
            flex: 1;
            max-width: 600px;
        }
        
        .search-box input {
            flex: 1;
            padding: 0.75rem 1.25rem;
            border: 1px solid #ddd;
            border-radius: 50px;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.8);
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .search-box button {
            padding: 0.75rem 1.5rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 4px 10px rgba(155, 93, 229, 0.3);
            transition: var(--transition);
        }
        
        .search-box button:hover {
            background: linear-gradient(135deg, var(--primary-dark) 0%, #8a4ad9 100%);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.4);
        }
        
        .bulk-actions {
            display: flex;
            gap: 0.75rem;
            align-items: center;
        }
        
        .bulk-actions select {
            padding: 0.75rem 1.25rem;
            border: 1px solid #ddd;
            border-radius: 50px;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.8);
        }
        
        .bulk-actions button {
            padding: 0.75rem 1.5rem;
            background: linear-gradient(135deg, var(--danger) 0%, #e01a4f 100%);
            color: white;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 4px 10px rgba(247, 37, 133, 0.3);
        }
        
        .bulk-actions button:hover {
            background: linear-gradient(135deg, #e01a4f 0%, #c4163d 100%);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(247, 37, 133, 0.4);
        }
        
        .admin-table {
            padding: 0 2rem 2rem;
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 10px;
            font-size: 0.95rem;
        }
        
        thead th {
            background-color: rgba(255, 133, 162, 0.1);
            padding: 1rem 1.25rem;
            text-align: left;
            font-weight: 600;
            color: var(--dark);
            white-space: nowrap;
            border-bottom: 2px solid var(--primary);
        }
        
        tbody tr {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: var(--transition);
            cursor: pointer;
            border: 1px solid rgba(255, 133, 162, 0.1);
            position: relative;
        }
        
        tbody tr::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary) 0%, var(--secondary) 100%);
            border-radius: var(--border-radius) 0 0 var(--border-radius);
        }
        
        tbody tr:hover {
            border-color: rgba(255, 133, 162, 0.3);
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(255, 133, 162, 0.15);
        }
        
        td {
            padding: 1rem 1.25rem;
            text-align: left;
            border-bottom: none;
            vertical-align: middle;
        }
        
        .comment-content {
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .comment-content:hover {
            color: var(--primary);
        }
        
        .comment-content.expanded {
            white-space: normal;
            overflow: visible;
            max-width: none;
        }
        
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.85rem;
            font-weight: 500;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .badge.hidden {
            background: linear-gradient(135deg, var(--warning) 0%, #ffb700 100%);
            color: var(--dark);
        }
        
        .badge.visible {
            background: linear-gradient(135deg, var(--success) 0%, #00cc99 100%);
            color: white;
        }
        
        .badge.deleted {
            background: linear-gradient(135deg, var(--danger) 0%, #e01a4f 100%);
            color: white;
        }
        
        .actions {
            display: flex;
            gap: 0.5rem;
            white-space: nowrap;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem 1rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border: none;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            gap: 0.5rem;
            font-size: 0.9rem;
            box-shadow: 0 4px 10px rgba(155, 93, 229, 0.3);
            text-decoration: none;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn-small {
            padding: 0.4rem 0.8rem;
            font-size: 0.85rem;
        }
        
        .btn-view {
            background: linear-gradient(135deg, var(--accent) 0%, #0099cc 100%);
        }
        
        .btn-delete {
            background: linear-gradient(135deg, var(--danger) 0%, #e01a4f 100%);
        }
        
        .btn-warning {
            background: linear-gradient(135deg, var(--warning) 0%, #ffb700 100%);
            color: var(--dark);
        }
        
        .btn-success {
            background: linear-gradient(135deg, var(--success) 0%, #00cc99 100%);
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }
        
        .pagination a {
            padding: 0.75rem 1.25rem;
            background-color: white;
            border: 1px solid #e0e0e0;
            border-radius: var(--border-radius);
            color: var(--primary);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            text-decoration: none;
        }
        
        .pagination a.active {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border-color: transparent;
        }
        
        .pagination a:hover:not(.active) {
            background-color: #f8f9fa;
            transform: translateY(-2px);
        }
        
        .no-data {
            padding: 3rem;
            text-align: center;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            border: 1px solid rgba(255, 133, 162, 0.1);
            background-color: white;
            margin: 2rem;
        }
        
        .no-data i {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }
        
        .no-data p {
            color: var(--gray);
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
        }
        
        footer {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            text-align: center;
            padding: 2rem 0;
            margin-top: 3rem;
            border-top: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        footer p {
            opacity: 0.9;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        }
        
        /* 底部导航栏 - 移动端 */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 133, 162, 0.2);
            padding: 0.75rem 0;
            display: none;
            z-index: 1000;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .nav-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
            padding: 0.5rem;
            border-radius: 50px;
            transition: var(--transition);
            color: var(--gray);
        }
        
        .nav-item.active {
            color: var(--primary);
        }
        
        .nav-item i {
            font-size: 1.25rem;
            background: rgba(255, 133, 162, 0.1);
            width: 2.5rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .nav-item.active i {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 10px rgba(255, 133, 162, 0.3);
        }
        
        .nav-item span {
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        /* 响应式设计 */
        @media (max-width: 992px) {
            .admin-table {
                padding: 0 1.5rem 1.5rem;
            }
            
            table {
                min-width: 800px;
            }
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: row;
                align-items: center;
                flex-wrap: wrap;
            }
            
            .logo {
                order: 1;
                flex: 1;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            .mobile-menu-btn {
                display: block;
                order: 2;
            }
            
            nav {
                order: 4;
                width: 100%;
                display: none;
                margin-top: 1rem;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .admin-header {
                padding: 1.5rem;
            }
            
            .admin-header h2 {
                font-size: 1.5rem;
            }
            
            .admin-toolbar {
                flex-direction: column;
                align-items: stretch;
                margin: 0 1rem 1rem;
            }
            
            .admin-table {
                padding: 0 1rem 1rem;
            }
            
            .actions {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            /* 显示底部导航 */
            .bottom-nav {
                display: block;
            }
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 0 1rem;
            }
            
            .admin-header {
                padding: 1.25rem;
            }
            
            .pagination a {
                padding: 0.6rem 1rem;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <a href="../../index.php" class="logo">
                    <i class="bi bi-chat-square-heart"></i>
                    <span><?= htmlspecialchars(getSettings()['site_title']) ?></span>
                </a>
                
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="bi bi-list"></i>
                </button>
                
                <nav id="mainNav">
                    <ul>
                        <li><a href="../../index.php"><i class="bi bi-house"></i> 返回论坛</a></li>
                        <li><a href="index.php"><i class="bi bi-speedometer2"></i> 管理首页</a></li>
                        <li><a href="users.php"><i class="bi bi-people"></i> 用户管理</a></li>
                        <li><a href="posts.php"><i class="bi bi-file-text"></i> 帖子管理</a></li>
                        <li><a href="comments.php" class="active"><i class="bi bi-chat-left-text"></i> 评论管理</a></li>
                        <li><a href="../logout.php"><i class="bi bi-box-arrow-right"></i> 退出</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="admin-content">
            <div class="admin-header">
                <h2><i class="bi bi-chat-left-text"></i> 评论管理</h2>
                <p>共找到 <?= $total ?> 条评论，当前显示第 <?= min($offset + 1, $total) ?> - <?= min($offset + count($comments), $total) ?> 条</p>
            </div>
            
            <div class="stats-info">
                <i class="bi bi-info-circle"></i>
                <span>您可以查看、隐藏或删除用户评论，批量操作可提高效率</span>
            </div>
            
            <form method="get" class="admin-toolbar">
                <div class="search-box">
                    <input type="text" name="search" placeholder="搜索评论内容或作者..." value="<?= htmlspecialchars($search) ?>">
                    <button type="submit"><i class="bi bi-search"></i> 搜索</button>
                    <?php if ($search): ?>
                        <a href="comments.php" class="btn btn-view"><i class="bi bi-x-circle"></i> 清除搜索</a>
                    <?php endif; ?>
                </div>
            </form>
            
            <form method="post" class="admin-toolbar">
                <div class="bulk-actions">
                    <select name="bulk_action">
                        <option value="">批量操作</option>
                        <option value="delete">删除选中</option>
                        <option value="hide">隐藏选中</option>
                        <option value="show">显示选中</option>
                    </select>
                    <button type="submit" onclick="return confirm('确定执行批量操作吗？')"><i class="bi bi-check-circle"></i> 执行</button>
                </div>
            </form>
            
            <div class="admin-table">
                <table>
                    <thead>
                        <tr>
                            <th width="30"><input type="checkbox" id="select-all"></th>
                            <th width="60">ID</th>
                            <th width="150">作者</th>
                            <th>评论内容</th>
                            <th width="120">所属帖子</th>
                            <th width="150">评论时间</th>
                            <th width="100">状态</th>
                            <th width="200">操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($comments)): ?>
                            <tr>
                                <td colspan="8">
                                    <div class="no-data">
                                        <i class="bi bi-chat-square"></i>
                                        <p><?= $search ? '没有找到匹配的评论' : '暂无评论数据' ?></p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($comments as $comment): ?>
                                <?php
                                $post = getPostById($comment['post_id']);
                                $author = getUsernameById($comment['user_id']);
                                ?>
                                <tr>
                                    <td><input type="checkbox" name="selected_comments[]" value="<?= $comment['id'] ?>"></td>
                                    <td><?= $comment['id'] ?></td>
                                    <td><?= htmlspecialchars($author) ?></td>
                                    <td>
                                        <div class="comment-content" title="<?= htmlspecialchars($comment['content']) ?>">
                                            <?= htmlspecialchars(mb_substr($comment['content'], 0, 50)) ?>
                                            <?= mb_strlen($comment['content']) > 50 ? '...' : '' ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($post): ?>
                                            <a href="<?= $rootPath ?>/post.php?id=<?= $post['id'] ?>" target="_blank" class="text-link">
                                                <?= htmlspecialchars(mb_substr($post['title'], 0, 15)) ?>
                                                <?= mb_strlen($post['title']) > 15 ? '...' : '' ?>
                                            </a>
                                        <?php else: ?>
                                            <span style="color: var(--gray);">帖子已删除</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= $comment['created_at'] ?></td>
                                    <td>
                                        <?php if (isset($comment['is_hidden']) && $comment['is_hidden']): ?>
                                            <span class="badge hidden"><i class="bi bi-eye-slash"></i> 已隐藏</span>
                                        <?php else: ?>
                                            <span class="badge visible"><i class="bi bi-eye"></i> 正常</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="actions">
                                        <a href="<?= $rootPath ?>/post.php?id=<?= $comment['post_id'] ?>#comment-<?= $comment['id'] ?>" 
                                           class="btn btn-small btn-view" target="_blank"><i class="bi bi-eye"></i> 查看</a>
                                        
                                        <?php if (isset($comment['is_hidden']) && $comment['is_hidden']): ?>
                                            <a href="comments.php?action=show&comment_id=<?= $comment['id'] ?>" 
                                               class="btn btn-small btn-success"><i class="bi bi-eye"></i> 显示</a>
                                        <?php else: ?>
                                            <a href="comments.php?action=hide&comment_id=<?= $comment['id'] ?>" 
                                               class="btn btn-small btn-warning"><i class="bi bi-eye-slash"></i> 隐藏</a>
                                        <?php endif; ?>
                                        
                                        <a href="comments.php?action=delete&comment_id=<?= $comment['id'] ?>" 
                                           class="btn btn-small btn-delete" 
                                           onclick="return confirm('确定删除这条评论吗？')"><i class="bi bi-trash"></i> 删除</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>"><i class="bi bi-chevron-left"></i> 上一页</a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>" <?= $i == $page ? 'class="active"' : '' ?>><?= $i ?></a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>">下一页 <i class="bi bi-chevron-right"></i></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- 底部导航栏 -->
    <nav class="bottom-nav">
        <div class="nav-items">
            <a href="../../index.php" class="nav-item">
                <i class="bi bi-house"></i>
                <span>论坛</span>
            </a>
            <a href="index.php" class="nav-item">
                <i class="bi bi-speedometer2"></i>
                <span>管理</span>
            </a>
            <a href="comments.php" class="nav-item active">
                <i class="bi bi-chat-left-text"></i>
                <span>评论</span>
            </a>
            <a href="users.php" class="nav-item">
                <i class="bi bi-people"></i>
                <span>用户</span>
            </a>
        </div>
    </nav>

    <footer>
        <div class="container">
            <p>Copyright © <?= date('Y') ?> <?= htmlspecialchars(getSettings()['site_title']) ?> - 二次元管理后台</p>
        </div>
    </footer>

    <script>
        // 移动端菜单切换
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            
            // 切换图标
            const icon = this.querySelector('i');
            if (mainNav.classList.contains('active')) {
                icon.classList.remove('bi-list');
                icon.classList.add('bi-x');
            } else {
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        });
        
        // 评论内容点击展开
        document.querySelectorAll('.comment-content').forEach(content => {
            content.addEventListener('click', function() {
                this.classList.toggle('expanded');
            });
        });
        
        // 全选/全不选
        document.getElementById('select-all').addEventListener('click', function() {
            const checkboxes = document.querySelectorAll('input[name="selected_comments[]"]');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
        
        // 操作确认对话框
        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click', function(e) {
                if (!confirm('确定要删除这条评论吗？此操作无法撤销！')) {
                    e.preventDefault();
                }
            });
        });
        
        // 添加页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            document.body.style.opacity = '0';
            setTimeout(() => {
                document.body.style.transition = 'opacity 0.3s ease';
                document.body.style.opacity = '1';
            }, 100);
        });
        
        // 根据屏幕宽度自动调整布局
        function handleResponsive() {
            if (window.innerWidth > 768) {
                mainNav.classList.remove('active');
                const icon = mobileMenuBtn.querySelector('i');
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        }
        
        window.addEventListener('resize', handleResponsive);
        handleResponsive();
    </script>
</body>
</html>