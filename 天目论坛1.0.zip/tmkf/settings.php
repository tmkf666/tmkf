<?php
// admin/settings.php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!isAdmin($_SESSION['user_id'] ?? null)) {
    header('Location: ../index.php');
    exit;
}

// 定义维护配置文件路径
define('MAINTENANCE_FILE', '../maintenance_config.txt');

/**
 * 从txt文件读取维护设置
 */
function getMaintenanceSettingsFromFile() {
    $defaultSettings = [
        'enabled' => false,
        'message' => '网站正在维护中，请稍后再访问。',
        'allowed_ips' => [],
        'start_time' => null,
        'end_time' => null,
        'reason' => '常规维护'
    ];
    
    if (!file_exists(MAINTENANCE_FILE)) {
        return $defaultSettings;
    }
    
    $content = file_get_contents(MAINTENANCE_FILE);
    $lines = explode("\n", $content);
    $settings = $defaultSettings;
    
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line) || strpos($line, '#') === 0) continue;
        
        $parts = explode('=', $line, 2);
        if (count($parts) === 2) {
            $key = trim($parts[0]);
            $value = trim($parts[1]);
            
            switch ($key) {
                case 'enabled':
                    $settings[$key] = ($value === 'true');
                    break;
                case 'allowed_ips':
                    $settings[$key] = array_filter(array_map('trim', explode(',', $value)));
                    break;
                case 'start_time':
                case 'end_time':
                case 'message':
                case 'reason':
                    $settings[$key] = $value;
                    break;
            }
        }
    }
    
    return $settings;
}

/**
 * 更新维护设置到txt文件
 */
function updateMaintenanceSettingsToFile($newSettings) {
    $content = "# 网站维护配置文件\n";
    $content .= "# 格式：键=值\n";
    $content .= "# 启用维护模式 (true/false)\n";
    $content .= "enabled=" . ($newSettings['enabled'] ? 'true' : 'false') . "\n";
    $content .= "# 维护消息\n";
    $content .= "message=" . $newSettings['message'] . "\n";
    $content .= "# 维护原因\n";
    $content .= "reason=" . ($newSettings['reason'] ?? '常规维护') . "\n";
    $content .= "# 允许访问的IP (逗号分隔)\n";
    $content .= "allowed_ips=" . implode(',', $newSettings['allowed_ips']) . "\n";
    $content .= "# 维护开始时间 (YYYY-MM-DD HH:MM:SS)\n";
    $content .= "start_time=" . ($newSettings['start_time'] ?? '') . "\n";
    $content .= "# 维护结束时间 (YYYY-MM-DD HH:MM:SS)\n";
    $content .= "end_time=" . ($newSettings['end_time'] ?? '') . "\n";
    
    file_put_contents(MAINTENANCE_FILE, $content);
}

// 获取当前设置
$settings = getMaintenanceSettingsFromFile();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('无效的CSRF令牌');
    }
    
    $newMaintenance = [
        'enabled' => isset($_POST['enabled']),
        'message' => htmlspecialchars($_POST['message'] ?? ''),
        'reason' => htmlspecialchars($_POST['reason'] ?? '常规维护'),
        'allowed_ips' => array_filter(array_map('trim', explode(',', $_POST['allowed_ips'] ?? ''))),
        'start_time' => $_POST['start_time'] ?? null,
        'end_time' => $_POST['end_time'] ?? null
    ];
    
    updateMaintenanceSettingsToFile($newMaintenance);
    
    $_SESSION['flash_message'] = [
        'type' => 'success',
        'message' => '维护设置已更新'
    ];
    header('Location: settings.php');
    exit;
}

$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

// 获取服务器配置信息
$serverInfo = [
    'software' => $_SERVER['SERVER_SOFTWARE'] ?? '未知',
    'php_version' => phpversion(),
    'os' => php_uname('s') . ' ' . php_uname('r'),
    'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? '未知',
    'data_dir' => DATA_DIR,
    'free_space' => round(disk_free_space(DATA_DIR) / (1024 * 1024 * 1024), 2) . ' GB',
    'upload_max' => ini_get('upload_max_filesize'),
    'max_execution' => ini_get('max_execution_time') . ' 秒',
    'memory_limit' => ini_get('memory_limit'),
    'safe_mode' => ini_get('safe_mode') ? '开启' : '关闭',
    'openssl' => extension_loaded('openssl') ? '已启用' : '未启用',
    'https' => isset($_SERVER['HTTPS']) ? '已启用' : '未启用'
];
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>维护设置 - <?= htmlspecialchars(getSettings()['site_title']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #ff85a2; /* 粉色主色调 */
            --primary-light: #ffb6c1; /* 浅粉色 */
            --primary-dark: #e75480; /* 深粉色 */
            --secondary: #9b5de5; /* 紫色 */
            --accent: #00bbf9; /* 蓝色 */
            --light: #fff9fb; /* 浅粉色背景 */
            --dark: #4a4a4a; /* 深灰色 */
            --gray: #a0a0a0; /* 灰色 */
            --success: #00f5d4; /* 青色 */
            --danger: #f72585; /* 红色 */
            --warning: #ffd166; /* 黄色 */
            --border-radius: 16px; /* 更大的圆角 */
            --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15); /* 柔和阴影 */
            --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94); /* 平滑过渡 */
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .container {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        
        /* 头部样式 - 动漫风格 */
        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1.5rem;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .logo i {
            font-size: 1.75rem;
            color: #fff;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem;
            border-radius: 50%;
        }
        
        nav ul {
            display: flex;
            gap: 0.5rem;
            list-style: none;
        }
        
        nav ul li a {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        nav ul li a:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        
        nav ul li a.active {
            background: rgba(255, 255, 255, 0.3);
            box-shadow: 0 4px 10px rgba(155, 93, 229, 0.3);
        }
        
        nav ul li a i {
            font-size: 1.1rem;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        main {
            flex: 1;
            padding: 1.5rem 0;
        }
        
        /* 管理面板卡片 - 动漫风格 */
        .admin-content {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            border: 1px solid rgba(255, 133, 162, 0.1);
            position: relative;
        }
        
        .admin-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 50%, var(--accent) 100%);
        }
        
        .admin-header {
            padding: 2rem;
            border-bottom: 1px solid rgba(255, 133, 162, 0.1);
        }
        
        .admin-header h1 {
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .admin-header p {
            color: var(--gray);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 2rem;
        }
        
        .stat-card {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            transition: var(--transition);
            border: 1px solid rgba(255, 133, 162, 0.1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary) 0%, var(--secondary) 100%);
            border-radius: var(--border-radius) 0 0 var(--border-radius);
        }
        
        .stat-card:hover {
            border-color: rgba(255, 133, 162, 0.3);
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(255, 133, 162, 0.15);
        }
        
        .stat-card h3 {
            font-size: 1rem;
            color: var(--gray);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .stat-card .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--dark);
            margin-bottom: 0.5rem;
        }
        
        .stat-card.status-card {
            background: linear-gradient(135deg, 
                <?= $settings['enabled'] ? 'var(--danger)' : 'var(--success)' ?> 0%, 
                <?= $settings['enabled'] ? '#e01a4f' : '#00cc99' ?> 100%);
            color: white;
        }
        
        .stat-card.status-card::before {
            display: none;
        }
        
        .stat-card.status-card h3,
        .stat-card.status-card .stat-value {
            color: white;
        }
        
        /* 服务器信息卡片样式 */
        .server-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            padding: 0 2rem 2rem;
        }
        
        .server-info-card {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            border: 1px solid rgba(255, 133, 162, 0.1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
        }
        
        .server-info-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, var(--accent) 0%, #0099cc 100%);
            border-radius: var(--border-radius) 0 0 var(--border-radius);
        }
        
        .server-info-card h3 {
            font-size: 1.1rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--dark);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            padding-bottom: 0.5rem;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.75rem;
            padding: 0.5rem;
            border-radius: var(--border-radius);
            background: rgba(255, 255, 255, 0.5);
            transition: var(--transition);
        }
        
        .info-item:hover {
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .info-label {
            font-weight: 500;
            color: var(--dark);
            flex: 1;
        }
        
        .info-value {
            font-weight: 600;
            color: var(--secondary);
            text-align: right;
            flex: 1;
        }
        
        .settings-card {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 2rem;
            margin: 0 2rem 2rem;
            border: 1px solid rgba(255, 133, 162, 0.1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        
        .settings-card h2 {
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.75rem;
            font-weight: 600;
            color: var(--dark);
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 1rem 1.25rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-family: inherit;
            font-size: 1rem;
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.8);
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 133, 162, 0.2);
            background: white;
        }
        
        .form-check {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }
        
        .form-check-input {
            width: 2.5rem;
            height: 1.5rem;
            border-radius: 1rem;
            background-color: #ddd;
            position: relative;
            transition: var(--transition);
            cursor: pointer;
            appearance: none;
            -webkit-appearance: none;
        }
        
        .form-check-input:checked {
            background-color: var(--primary);
        }
        
        .form-check-input::before {
            content: '';
            position: absolute;
            top: 0.25rem;
            left: 0.25rem;
            width: 1rem;
            height: 1rem;
            background-color: white;
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .form-check-input:checked::before {
            transform: translateX(1rem);
        }
        
        .form-check-label {
            font-weight: 600;
            color: var(--dark);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 1rem 2rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border: none;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            gap: 0.5rem;
            font-size: 1rem;
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.3);
            position: relative;
            overflow: hidden;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(155, 93, 229, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .alert {
            padding: 1.25rem;
            margin-bottom: 1.5rem;
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            border-left: 4px solid;
        }
        
        .alert-success {
            background-color: rgba(0, 245, 212, 0.1);
            color: var(--success);
            border-left-color: var(--success);
        }
        
        .alert-error {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--danger);
            border-left-color: var(--danger);
        }
        
        .modal-content {
            border-radius: var(--border-radius);
            border: none;
            box-shadow: var(--box-shadow);
        }
        
        .modal-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
            padding: 1.5rem;
        }
        
        .modal-title {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .modal-body {
            padding: 1.5rem;
        }
        
        .modal-footer {
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            padding: 1rem 1.5rem;
            border-radius: 0 0 var(--border-radius) var(--border-radius);
        }
        
        footer {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            text-align: center;
            padding: 2rem 0;
            margin-top: 3rem;
            border-top: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        footer p {
            opacity: 0.9;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        }
        
        /* 底部导航栏 - 移动端 */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 133, 162, 0.2);
            padding: 0.75rem 0;
            display: none;
            z-index: 1000;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .nav-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
            padding: 0.5rem;
            border-radius: 50px;
            transition: var(--transition);
            color: var(--gray);
        }
        
        .nav-item.active {
            color: var(--primary);
        }
        
        .nav-item i {
            font-size: 1.25rem;
            background: rgba(255, 133, 162, 0.1);
            width: 2.5rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .nav-item.active i {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 10px rgba(255, 133, 162, 0.3);
        }
        
        .nav-item span {
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        /* 响应式设计 */
        @media (max-width: 992px) {
            .stats-grid,
            .server-info-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: row;
                align-items: center;
                flex-wrap: wrap;
            }
            
            .logo {
                order: 1;
                flex: 1;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            .mobile-menu-btn {
                display: block;
                order: 2;
            }
            
            nav {
                order: 4;
                width: 100%;
                display: none;
                margin-top: 1rem;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .stats-grid,
            .server-info-grid {
                grid-template-columns: 1fr;
                padding: 1.5rem;
            }
            
            .settings-card {
                margin: 0 1.5rem 1.5rem;
                padding: 1.5rem;
            }
            
            .admin-header {
                padding: 1.5rem;
            }
            
            /* 显示底部导航 */
            .bottom-nav {
                display: block;
            }
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 0 1rem;
            }
            
            .admin-header h1 {
                font-size: 1.5rem;
            }
            
            .settings-card {
                padding: 1.25rem;
                margin: 0 1rem 1rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="bi bi-chat-square-heart"></i>
                    <span><?= htmlspecialchars(getSettings()['site_title']) ?></span>
                </a>
                
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="bi bi-list"></i>
                </button>
                
                <nav id="mainNav">
                    <ul>
                        <li><a href="../index.php"><i class="bi bi-house"></i> 返回论坛</a></li>
                        <li><a href="index.php"><i class="bi bi-speedometer2"></i> 管理首页</a></li>
                        <li><a href="users.php"><i class="bi bi-people"></i> 用户管理</a></li>
                        <li><a href="posts.php"><i class="bi bi-file-text"></i> 帖子管理</a></li>
                        <li><a href="settings.php" class="active"><i class="bi bi-gear"></i> 系统设置</a></li>
                        <li><a href="../logout.php"><i class="bi bi-box-arrow-right"></i> 退出</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="admin-content">
            <div class="admin-header">
                <h1><i class="bi bi-tools"></i> 系统维护设置</h1>
                <p>配置网站的维护模式和访问限制</p>
            </div>
            
            <?php if (isset($_SESSION['flash_message'])): ?>
            <div class="alert <?= $_SESSION['flash_message']['type'] === 'success' ? 'alert-success' : 'alert-error' ?>">
                <i class="bi <?= $_SESSION['flash_message']['type'] === 'success' ? 'bi-check-circle' : 'bi-exclamation-circle' ?>"></i>
                <?= $_SESSION['flash_message']['message'] ?>
            </div>
            <?php unset($_SESSION['flash_message']); endif; ?>
            
            <div class="stats-grid">
                <div class="stat-card status-card">
                    <h3><i class="bi <?= $settings['enabled'] ? 'bi-exclamation-triangle' : 'bi-check-circle' ?>"></i> 维护状态</h3>
                    <div class="stat-value">
                        <?= $settings['enabled'] ? '已启用' : '未启用' ?>
                    </div>
                </div>
                
                <div class="stat-card">
                    <h3><i class="bi bi-people"></i> 允许IP数</h3>
                    <div class="stat-value">
                        <?= count($settings['allowed_ips']) ?>
                    </div>
                </div>
                
                <div class="stat-card">
                    <h3><i class="bi bi-clock-history"></i> 最后更新</h3>
                    <div class="stat-value">
                        <?= file_exists(MAINTENANCE_FILE) ? date('Y-m-d H:i:s', filemtime(MAINTENANCE_FILE)) : '从未更新' ?>
                    </div>
                </div>
                
                <div class="stat-card">
                    <h3><i class="bi bi-info-circle"></i> 维护原因</h3>
                    <div class="stat-value">
                        <?= $settings['reason'] ?>
                    </div>
                </div>
            </div>
            
            <!-- 服务器配置信息卡片 -->
            <div class="settings-card">
                <h2><i class="bi bi-server"></i> 服务器配置信息</h2>
                
                <div class="server-info-grid">
                    <div class="server-info-card">
                        <h3><i class="bi bi-cpu"></i> 服务器环境</h3>
                        <div class="info-item">
                            <span class="info-label">服务器软件:</span>
                            <span class="info-value"><?= $serverInfo['software'] ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">PHP版本:</span>
                            <span class="info-value"><?= $serverInfo['php_version'] ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">操作系统:</span>
                            <span class="info-value"><?= $serverInfo['os'] ?></span>
                        </div>
                    </div>
                    
                    <div class="server-info-card">
                        <h3><i class="bi bi-hdd"></i> 存储信息</h3>
                        <div class="info-item">
                            <span class="info-label">根目录:</span>
                            <span class="info-value"><?= $serverInfo['document_root'] ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">数据目录:</span>
                            <span class="info-value"><?= $serverInfo['data_dir'] ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">可用空间:</span>
                            <span class="info-value"><?= $serverInfo['free_space'] ?></span>
                        </div>
                    </div>
                    
                    <div class="server-info-card">
                        <h3><i class="bi bi-gear"></i> PHP配置</h3>
                        <div class="info-item">
                            <span class="info-label">最大上传文件:</span>
                            <span class="info-value"><?= $serverInfo['upload_max'] ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">最大执行时间:</span>
                            <span class="info-value"><?= $serverInfo['max_execution'] ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">内存限制:</span>
                            <span class="info-value"><?= $serverInfo['memory_limit'] ?></span>
                        </div>
                    </div>
                    
                    <div class="server-info-card">
                        <h3><i class="bi bi-shield"></i> 安全设置</h3>
                        <div class="info-item">
                            <span class="info-label">安全模式:</span>
                            <span class="info-value"><?= $serverInfo['safe_mode'] ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">OpenSSL:</span>
                            <span class="info-value"><?= $serverInfo['openssl'] ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">HTTPS:</span>
                            <span class="info-value"><?= $serverInfo['https'] ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="settings-card">
                <h2><i class="bi bi-gear"></i> 维护设置</h2>
                
                <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="enabled" name="enabled" 
                            <?= $settings['enabled'] ? 'checked' : '' ?>>
                        <label class="form-check-label" for="enabled">启用维护模式</label>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="reason">维护原因</label>
                                <select class="form-select" id="reason" name="reason">
                                    <option value="常规维护" <?= $settings['reason'] === '常规维护' ? 'selected' : '' ?>>常规维护</option>
                                    <option value="系统升级" <?= $settings['reason'] === '系统升级' ? 'selected' : '' ?>>系统升级</option>
                                    <option value="安全更新" <?= $settings['reason'] === '安全更新' ? 'selected' : '' ?>>安全更新</option>
                                    <option value="紧急修复" <?= $settings['reason'] === '紧急修复' ? 'selected' : '' ?>>紧急修复</option>
                                    <option value="其他" <?= $settings['reason'] === '其他' ? 'selected' : '' ?>>其他</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="message">维护消息</label>
                                <textarea class="form-control" id="message" name="message" rows="3" required><?= 
                                    htmlspecialchars($settings['message']) 
                                ?></textarea>
                                <div class="form-text">用户访问时将看到此消息</div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="allowed_ips">允许访问的IP地址</label>
                                <textarea class="form-control" id="allowed_ips" name="allowed_ips" rows="3"><?= 
                                    htmlspecialchars(implode(', ', $settings['allowed_ips'])) 
                                ?></textarea>
                                <div class="form-text">多个IP用逗号或换行分隔</div>
                            </div>
                            
                            <div class="form-group">
                                <label for="start_time">计划开始时间</label>
                                <input type="datetime-local" class="form-control" id="start_time" name="start_time" 
                                    value="<?= $settings['start_time'] ?? '' ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="end_time">计划结束时间</label>
                                <input type="datetime-local" class="form-control" id="end_time" name="end_time" 
                                    value="<?= $settings['end_time'] ?? '' ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-outline me-2" data-bs-toggle="modal" data-bs-target="#helpModal">
                            <i class="bi bi-question-circle"></i> 帮助
                        </button>
                        <button type="submit" class="btn">
                            <i class="bi bi-save"></i> 保存设置
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <!-- 帮助模态框 -->
    <div class="modal fade" id="helpModal" tabindex="-1" aria-labelledby="helpModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="helpModalLabel">
                        <i class="bi bi-question-circle-fill"></i> 维护系统帮助
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h6>维护模式说明：</h6>
                    <ul>
                        <li>所有设置保存在 <code><?= MAINTENANCE_FILE ?></code> 文件中</li>
                        <li>启用后普通用户将无法访问网站</li>
                        <li>管理员和指定IP仍可正常访问</li>
                        <li>可以设置计划维护时间</li>
                    </ul>
                    <h6 class="mt-3">IP白名单：</h6>
                    <p>输入允许访问的IP地址，多个IP用逗号分隔。例如：192.168.1.1, 10.0.0.1</p>
                    <h6 class="mt-3">维护原因：</h6>
                    <p>选择维护原因有助于后续追踪和分析维护记录</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> 关闭
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- 底部导航栏 -->
    <nav class="bottom-nav">
        <div class="nav-items">
            <a href="../index.php" class="nav-item">
                <i class="bi bi-house"></i>
                <span>论坛</span>
            </a>
            <a href="index.php" class="nav-item">
                <i class="bi bi-speedometer2"></i>
                <span>管理</span>
            </a>
            <a href="posts.php" class="nav-item">
                <i class="bi bi-file-text"></i>
                <span>帖子</span>
            </a>
            <a href="settings.php" class="nav-item active">
                <i class="bi bi-gear"></i>
                <span>设置</span>
            </a>
        </div>
    </nav>

    <footer>
        <div class="container">
            <p>Copyright © <?= date('Y') ?> <?= htmlspecialchars(getSettings()['site_title']) ?> - 二次元管理后台</p>
        </div>
    </footer>

    <script>
        // 移动端菜单切换
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            
            // 切换图标
            const icon = this.querySelector('i');
            if (mainNav.classList.contains('active')) {
                icon.classList.remove('bi-list');
                icon.classList.add('bi-x');
            } else {
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        });
        
        // 添加页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            document.body.style.opacity = '0';
            setTimeout(() => {
                document.body.style.transition = 'opacity 0.3s ease';
                document.body.style.opacity = '1';
            }, 100);
        });
        
        // 根据屏幕宽度自动调整布局
        function handleResponsive() {
            if (window.innerWidth > 768) {
                mainNav.classList.remove('active');
                const icon = mobileMenuBtn.querySelector('i');
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        }
        
        window.addEventListener('resize', handleResponsive);
        handleResponsive();
        
        // 初始化模态框
        const helpModal = new bootstrap.Modal(document.getElementById('helpModal'));
    </script>
</body>
</html>