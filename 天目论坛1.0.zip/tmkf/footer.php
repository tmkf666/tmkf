<?php
// admin/footer.php
?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            // 自动设置时间选择器的默认值
            document.addEventListener('DOMContentLoaded', function() {
                const timeInputs = document.querySelectorAll('input[type="datetime-local"]');
                const now = new Date();
                
                timeInputs.forEach(input => {
                    if (!input.value) {
                        if (input.id === 'end_time') {
                            const endTime = new Date(now);
                            endTime.setHours(now.getHours() + 1);
                            input.value = endTime.toISOString().slice(0, 16);
                        } else {
                            input.value = now.toISOString().slice(0, 16);
                        }
                    }
                });

                // 表单提交确认
                const forms = document.querySelectorAll('form[data-confirm]');
                forms.forEach(form => {
                    form.addEventListener('submit', function(e) {
                        if (!confirm(this.getAttribute('data-confirm'))) {
                            e.preventDefault();
                        }
                    });
                });
            });
        </script>
    </body>
</html>
