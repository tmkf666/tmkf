<?php
// 确保先加载配置和基础函数
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// 检查用户是否登录且是管理员
if (!isLoggedIn() || !isAdmin(getCurrentUserId())) {
    header('Location: ../index.php');
    exit;
}

$currentUser = getCurrentUser();
$allPosts = readData(POSTS_FILE);
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;

// 分页
$total = count($allPosts);
$offset = ($page - 1) * $perPage;
$posts = array_slice($allPosts, $offset, $perPage);
$totalPages = ceil($total / $perPage);

// 处理帖子操作
if (isset($_GET['action']) && isset($_GET['post_id'])) {
    $postId = intval($_GET['post_id']);
    
    switch ($_GET['action']) {
        case 'delete':
            deletePost($postId);
            break;
    }
    
    header('Location: posts.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>帖子管理 - <?= htmlspecialchars(getSettings()['site_title']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #ff85a2; /* 粉色主色调 */
            --primary-light: #ffb6c1; /* 浅粉色 */
            --primary-dark: #e75480; /* 深粉色 */
            --secondary: #9b5de5; /* 紫色 */
            --accent: #00bbf9; /* 蓝色 */
            --light: #fff9fb; /* 浅粉色背景 */
            --dark: #4a4a4a; /* 深灰色 */
            --gray: #a0a0a0; /* 灰色 */
            --success: #00f5d4; /* 青色 */
            --danger: #f72585; /* 红色 */
            --warning: #ffd166; /* 黄色 */
            --border-radius: 16px; /* 更大的圆角 */
            --box-shadow: 0 8px 20px rgba(255, 133, 162, 0.15); /* 柔和阴影 */
            --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94); /* 平滑过渡 */
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background: linear-gradient(135deg, #f9f0ff 0%, #ffeef6 50%, #e6f7ff 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .container {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        
        /* 头部样式 - 动漫风格 */
        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1.5rem;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .logo i {
            font-size: 1.75rem;
            color: #fff;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem;
            border-radius: 50%;
        }
        
        nav ul {
            display: flex;
            gap: 0.5rem;
            list-style: none;
        }
        
        nav ul li a {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        nav ul li a:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        
        nav ul li a.active {
            background: rgba(255, 255, 255, 0.3);
            box-shadow: 0 4px 10px rgba(155, 93, 229, 0.3);
        }
        
        nav ul li a i {
            font-size: 1.1rem;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        main {
            flex: 1;
            padding: 1.5rem 0;
        }
        
        /* 管理面板卡片 - 动漫风格 */
        .admin-content {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            border: 1px solid rgba(255, 133, 162, 0.1);
            position: relative;
        }
        
        .admin-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 50%, var(--accent) 100%);
        }
        
        .admin-header {
            padding: 2rem;
        }
        
        .admin-header h2 {
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .admin-table {
            padding: 0 2rem 2rem;
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 10px;
            font-size: 0.95rem;
        }
        
        thead th {
            background-color: rgba(255, 133, 162, 0.1);
            padding: 1rem 1.25rem;
            text-align: left;
            font-weight: 600;
            color: var(--dark);
            white-space: nowrap;
            border-bottom: 2px solid var(--primary);
        }
        
        tbody tr {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: var(--transition);
            cursor: pointer;
            border: 1px solid rgba(255, 133, 162, 0.1);
            position: relative;
        }
        
        tbody tr::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary) 0%, var(--secondary) 100%);
            border-radius: var(--border-radius) 0 0 var(--border-radius);
        }
        
        tbody tr:hover {
            border-color: rgba(255, 133, 162, 0.3);
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(255, 133, 162, 0.15);
        }
        
        td {
            padding: 1rem 1.25rem;
            text-align: left;
            border-bottom: none;
            vertical-align: middle;
        }
        
        .actions {
            display: flex;
            gap: 0.5rem;
            white-space: nowrap;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem 1rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border: none;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            gap: 0.5rem;
            font-size: 0.9rem;
            box-shadow: 0 4px 10px rgba(155, 93, 229, 0.3);
            text-decoration: none;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(155, 93, 229, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn-small {
            padding: 0.4rem 0.8rem;
            font-size: 0.85rem;
        }
        
        .btn-view {
            background: linear-gradient(135deg, var(--accent) 0%, #0099cc 100%);
        }
        
        .btn-delete {
            background: linear-gradient(135deg, var(--danger) 0%, #e01a4f 100%);
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }
        
        .pagination a {
            padding: 0.75rem 1.25rem;
            background-color: white;
            border: 1px solid #e0e0e0;
            border-radius: var(--border-radius);
            color: var(--primary);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            text-decoration: none;
        }
        
        .pagination a.active {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border-color: transparent;
        }
        
        .pagination a:hover:not(.active) {
            background-color: #f8f9fa;
            transform: translateY(-2px);
        }
        
        .no-posts {
            padding: 3rem;
            text-align: center;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            border: 1px solid rgba(255, 133, 162, 0.1);
            background-color: white;
        }
        
        .no-posts i {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }
        
        .no-posts p {
            color: var(--gray);
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
        }
        
        footer {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            text-align: center;
            padding: 2rem 0;
            margin-top: 3rem;
            border-top: 3px solid rgba(255, 255, 255, 0.2);
        }
        
        footer p {
            opacity: 0.9;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        }
        
        /* 底部导航栏 - 移动端 */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 133, 162, 0.2);
            padding: 0.75rem 0;
            display: none;
            z-index: 1000;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .nav-items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
            padding: 0.5rem;
            border-radius: 50px;
            transition: var(--transition);
            color: var(--gray);
        }
        
        .nav-item.active {
            color: var(--primary);
        }
        
        .nav-item i {
            font-size: 1.25rem;
            background: rgba(255, 133, 162, 0.1);
            width: 2.5rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .nav-item.active i {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 10px rgba(255, 133, 162, 0.3);
        }
        
        .nav-item span {
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        /* 响应式设计 */
        @media (max-width: 992px) {
            .admin-table {
                padding: 0 1.5rem 1.5rem;
            }
            
            table {
                min-width: 800px;
            }
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: row;
                align-items: center;
                flex-wrap: wrap;
            }
            
            .logo {
                order: 1;
                flex: 1;
                min-width: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            .mobile-menu-btn {
                display: block;
                order: 2;
            }
            
            nav {
                order: 4;
                width: 100%;
                display: none;
                margin-top: 1rem;
            }
            
            nav.active {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .admin-header {
                padding: 1.5rem;
            }
            
            .admin-header h2 {
                font-size: 1.5rem;
            }
            
            .admin-table {
                padding: 0 1rem 1rem;
            }
            
            .actions {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            /* 显示底部导航 */
            .bottom-nav {
                display: block;
            }
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 0 1rem;
            }
            
            .admin-header {
                padding: 1.25rem;
            }
            
            .pagination a {
                padding: 0.6rem 1rem;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="bi bi-chat-square-heart"></i>
                    <span><?= htmlspecialchars(getSettings()['site_title']) ?></span>
                </a>
                
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <i class="bi bi-list"></i>
                </button>
                
                <nav id="mainNav">
                    <ul>
                        <li><a href="../index.php"><i class="bi bi-house"></i> 返回论坛</a></li>
                        <li><a href="index.php"><i class="bi bi-speedometer2"></i> 管理首页</a></li>
                        <li><a href="users.php"><i class="bi bi-people"></i> 用户管理</a></li>
                        <li><a href="posts.php" class="active"><i class="bi bi-file-text"></i> 帖子管理</a></li>
                        <li><a href="../logout.php"><i class="bi bi-box-arrow-right"></i> 退出</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="admin-content">
            <div class="admin-header">
                <h2><i class="bi bi-file-text"></i> 帖子管理</h2>
                <p>共 <?= $total ?> 篇帖子，当前显示第 <?= $offset + 1 ?> - <?= min($offset + $perPage, $total) ?> 篇</p>
            </div>
            
            <div class="admin-table">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>标题</th>
                            <th>作者</th>
                            <th>板块</th>
                            <th>发布时间</th>
                            <th>浏览量</th>
                            <th>点赞数</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($posts)): ?>
                            <tr>
                                <td colspan="8">
                                    <div class="no-posts">
                                        <i class="bi bi-file-text"></i>
                                        <p>暂无帖子</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($posts as $post): ?>
                                <tr>
                                    <td><?= $post['id'] ?></td>
                                    <td>
                                        <a href="../post.php?id=<?= $post['id'] ?>" class="text-link">
                                            <?= htmlspecialchars($post['title'] ?? '无标题') ?>
                                        </a>
                                    </td>
                                    <td>
                                        <?php $author = getUser($post['user_id'] ?? 0); ?>
                                        <?php if ($author): ?>
                                            <a href="../profile.php?username=<?= $author['username'] ?>" class="text-link">
                                                <?= $author['username'] ?>
                                            </a>
                                        <?php else: ?>
                                            未知用户
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php $category = getCategory($post['category_id'] ?? 0); ?>
                                        <span class="badge"><?= $category ? $category['name'] : '未分类' ?></span>
                                    </td>
                                    <td><?= $post['created_at'] ?? '未知时间' ?></td>
                                    <td><?= $post['views'] ?? 0 ?></td>
                                    <td><?= is_array($post['likes'] ?? null) ? count($post['likes']) : 0 ?></td>
                                    <td class="actions">
                                        <a href="../post.php?id=<?= $post['id'] ?>" class="btn btn-view btn-small">
                                            <i class="bi bi-eye"></i> 查看
                                        </a>
                                        <a href="posts.php?action=delete&post_id=<?= $post['id'] ?>" 
                                           class="btn btn-delete btn-small" 
                                           onclick="return confirm('确定要删除这篇帖子吗？')">
                                            <i class="bi bi-trash"></i> 删除
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?= $page - 1 ?>">
                            <i class="bi bi-chevron-left"></i> 上一页
                        </a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?= $i ?>" <?= $i == $page ? 'class="active"' : '' ?>>
                            <?= $i ?>
                        </a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?= $page + 1 ?>">
                            下一页 <i class="bi bi-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- 底部导航栏 -->
    <nav class="bottom-nav">
        <div class="nav-items">
            <a href="../index.php" class="nav-item">
                <i class="bi bi-house"></i>
                <span>论坛</span>
            </a>
            <a href="index.php" class="nav-item">
                <i class="bi bi-speedometer2"></i>
                <span>管理</span>
            </a>
            <a href="posts.php" class="nav-item active">
                <i class="bi bi-file-text"></i>
                <span>帖子</span>
            </a>
            <a href="users.php" class="nav-item">
                <i class="bi bi-people"></i>
                <span>用户</span>
            </a>
        </div>
    </nav>

    <footer>
        <div class="container">
            <p>Copyright © <?= date('Y') ?> <?= htmlspecialchars(getSettings()['site_title']) ?> - 二次元管理后台</p>
        </div>
    </footer>

    <script>
        // 移动端菜单切换
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            
            // 切换图标
            const icon = this.querySelector('i');
            if (mainNav.classList.contains('active')) {
                icon.classList.remove('bi-list');
                icon.classList.add('bi-x');
            } else {
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        });
        
        // 帖子行点击事件
        document.querySelectorAll('tbody tr').forEach(row => {
            row.addEventListener('click', function(e) {
                // 如果点击的是操作按钮，则不处理
                if (e.target.closest('.actions')) return;
                
                // 否则跳转到帖子详情页
                const postId = this.querySelector('td:first-child').textContent;
                window.location.href = `../post.php?id=${postId}`;
            });
        });
        
        // 确认删除对话框
        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click', function(e) {
                if (!confirm('确定要删除这篇帖子吗？此操作无法撤销！')) {
                    e.preventDefault();
                }
            });
        });
        
        // 添加页面加载动画
        document.addEventListener('DOMContentLoaded', function() {
            document.body.style.opacity = '0';
            setTimeout(() => {
                document.body.style.transition = 'opacity 0.3s ease';
                document.body.style.opacity = '1';
            }, 100);
        });
        
        // 根据屏幕宽度自动调整布局
        function handleResponsive() {
            if (window.innerWidth > 768) {
                mainNav.classList.remove('active');
                const icon = mobileMenuBtn.querySelector('i');
                icon.classList.remove('bi-x');
                icon.classList.add('bi-list');
            }
        }
        
        window.addEventListener('resize', handleResponsive);
        handleResponsive();
    </script>
</body>
</html>
