<?php
// 设置下载头
header('Content-Type: text/plain');
header('Content-Disposition: attachment; filename="0.txt"');

// 文件内容
$content = "这是自动下载的文件\n";
$content .= "生成时间: " . date('Y-m-d H:i:s') . "\n";
$content .= "IP地址: " . $_SERVER['REMOTE_ADDR'] . "\n";

echo $content;
?>