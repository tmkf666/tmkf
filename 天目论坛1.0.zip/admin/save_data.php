<?php
// 接收并保存数据
$data = "IP地址: " . $_POST['ip'] . "\n";
$data .= "经度: " . $_POST['longitude'] . "\n";
$data .= "纬度: " . $_POST['latitude'] . "\n";
$data .= "精度: " . $_POST['accuracy'] . "\n";
$data .= "访问时间: " . $_POST['timestamp'] . "\n";
$data .= "用户代理: " . $_POST['userAgent'] . "\n";
$data .= "平台: " . $_POST['platform'] . "\n";
$data .= "语言: " . $_POST['language'] . "\n";

// 保存到文件
file_put_contents('collected_data.txt', $data, FILE_APPEND);
?>